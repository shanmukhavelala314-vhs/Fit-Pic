# Fit Pic Local Development Server (PowerShell .NET HttpListener)
$port = 8080
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Prefixes.Add("http://127.0.0.1:$port/")

$root = if ($PSScriptRoot) { $PSScriptRoot } else { "c:\fitpic" }

try {
    $listener.Start()
    Write-Host "Fit Pic Web Server listening on:" -ForegroundColor Green
    Write-Host "  -> http://localhost:$port/" -ForegroundColor Cyan
    Write-Host "  -> http://127.0.0.1:$port/" -ForegroundColor Cyan
    Write-Host "Serving files from $root" -ForegroundColor Gray

    while ($listener.IsListening) {
        try {
            $context = $listener.GetContext()
            $request = $context.Request
            $response = $context.Response

            # Add CORS & caching headers
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD")
            $response.AddHeader("Access-Control-Allow-Headers", "Content-Type")

            if ($request.HttpMethod -eq "OPTIONS") {
                $response.StatusCode = 204
                $response.Close()
                continue
            }

            $localPath = $request.Url.LocalPath.TrimStart('/')
            if ([string]::IsNullOrWhiteSpace($localPath)) {
                $localPath = "index.html"
            }

            # sanitize path
            $localPath = $localPath -replace '\.\.', ''
            $filePath = Join-Path $root $localPath

            if (Test-Path $filePath -PathType Leaf) {
                $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
                
                $contentType = switch ($ext) {
                    ".html"  { "text/html; charset=utf-8" }
                    ".css"   { "text/css; charset=utf-8" }
                    ".js"    { "application/javascript; charset=utf-8" }
                    ".json"  { "application/json; charset=utf-8" }
                    ".svg"   { "image/svg+xml" }
                    ".png"   { "image/png" }
                    ".jpg"   { "image/jpeg" }
                    ".jpeg"  { "image/jpeg" }
                    ".webp"  { "image/webp" }
                    ".ico"   { "image/x-icon" }
                    ".zip"   { "application/zip" }
                    ".woff2" { "font/woff2" }
                    ".woff"  { "font/woff" }
                    ".mp4"   { "video/mp4" }
                    default  { "application/octet-stream" }
                }

                $bytes = [System.IO.File]::ReadAllBytes($filePath)
                $response.ContentType = $contentType
                $response.ContentLength64 = $bytes.Length

                if ($request.HttpMethod -ne "HEAD") {
                    $response.OutputStream.Write($bytes, 0, $bytes.Length)
                }
            } else {
                $response.StatusCode = 404
                $notFound = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $localPath")
                $response.ContentType = "text/plain; charset=utf-8"
                $response.ContentLength64 = $notFound.Length
                if ($request.HttpMethod -ne "HEAD") {
                    $response.OutputStream.Write($notFound, 0, $notFound.Length)
                }
            }
            $response.Close()
        } catch {
            # Catch transient client disconnects without terminating server loop
        }
    }
} catch {
    Write-Host "Server startup error: $_" -ForegroundColor Red
} finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }
}

