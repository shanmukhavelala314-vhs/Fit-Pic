import glob

def check_balanced(filename):
    text = open(filename, encoding='utf-8').read()
    in_str = False
    str_char = ''
    stack = []
    escape = False
    in_comment_single = False
    in_comment_multi = False
    i = 0
    while i < len(text):
        c = text[i]
        if in_comment_single:
            if c == '\n': in_comment_single = False
        elif in_comment_multi:
            if c == '*' and i + 1 < len(text) and text[i+1] == '/':
                in_comment_multi = False
                i += 1
        elif in_str:
            if escape:
                escape = False
            elif c == '\\':
                escape = True
            elif c == str_char:
                in_str = False
        else:
            if c == '/' and i + 1 < len(text) and text[i+1] == '/':
                in_comment_single = True
                i += 1
            elif c == '/' and i + 1 < len(text) and text[i+1] == '*':
                in_comment_multi = True
                i += 1
            elif c in ('"', "'", '`'):
                in_str = True
                str_char = c
            elif c in '({[':
                stack.append((c, i))
            elif c in ')}]':
                if not stack:
                    return f'Extra closing {c} at {i}'
                last, _ = stack.pop()
                if (c == ')' and last != '(') or (c == '}' and last != '{') or (c == ']' and last != '['):
                    return f'Mismatched {last} and {c} at {i}'
        i += 1
    if stack:
        return f'Unclosed {stack[-1][0]} at {stack[-1][1]}'
    return 'OK'

for f in sorted(glob.glob('js/**/*.js', recursive=True)):
    res = check_balanced(f)
    print(f, ':', res)
