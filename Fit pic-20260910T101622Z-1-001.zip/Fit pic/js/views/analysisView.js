/**
 * FIT PIC — AI ANALYSIS VIEW (HERO DIFFERENTIATING FEATURE)
 * Provides 3 input methods: Device Camera (live/capture), Media Upload,
 * and Social Media / Video Link. Includes animated multi-stage AI scan
 * and comprehensive biomechanical & progress reports.
 */
window.FitPic = window.FitPic || {};
window.FitPic.Views = window.FitPic.Views || {};

(function() {
  class AnalysisView {
    constructor() {
      this.container = null;
      this.currentMode = "camera"; // 'camera', 'upload', 'link'
      this.isAnalyzing = false;
      this.isCameraActive = false;
      this.capturedSnapshot = null;
      this.uploadedFile = null;
      this.uploadedPreviewUrl = null;
      this.currentStep = 0;
      this.currentStepText = "";
      this.videoUrlInput = "";
      this.latestResult = null;
    }

    init(containerEl) {
      this.container = containerEl;
      this.render();
      window.FitPic.State.subscribe("analysisComplete", (report) => {
        this.latestResult = report;
        this.render();
      });
    }

    setMode(mode) {
      this.currentMode = mode;
      if (this.currentMode !== "camera" && this.isCameraActive) {
        this.stopCameraStream();
      }
      this.render();
    }

    async startCameraStream() {
      const videoEl = document.getElementById("ai-camera-video");
      const errorBox = document.getElementById("ai-camera-error");
      if (errorBox) errorBox.style.display = "none";

      try {
        await window.FitPic.AIService.startCamera(videoEl);
        this.isCameraActive = true;
        this.render();
      } catch (err) {
        console.warn("Using simulated camera feed due to browser restrictions:", err);
        // Fallback to simulated high-definition workout feed
        this.isCameraActive = true;
        this.isSimulatedFeed = true;
        this.render();
      }
    }

    stopCameraStream() {
      window.FitPic.AIService.stopCamera();
      this.isCameraActive = false;
      this.isSimulatedFeed = false;
      this.render();
    }

    captureSnapshot() {
      const videoEl = document.getElementById("ai-camera-video");
      const canvasEl = document.getElementById("ai-camera-canvas");
      if (this.isSimulatedFeed) {
        this.capturedSnapshot = "simulated_frame";
      } else if (videoEl && canvasEl) {
        this.capturedSnapshot = window.FitPic.AIService.captureFrame(videoEl, canvasEl);
      }
      this.render();
    }

    handleFileUpload(e) {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      this.uploadedFile = file;
      this.uploadedPreviewUrl = URL.createObjectURL(file);
      this.render();
    }

    selectSampleLink(url, label) {
      this.videoUrlInput = url;
      this.sampleLabel = label;
      const inputEl = document.getElementById("ai-video-url-input");
      if (inputEl) inputEl.value = url;
    }

    async runAnalysis(sourceObj) {
      this.isAnalyzing = true;
      this.latestResult = null;
      this.render();

      try {
        const report = await window.FitPic.AIService.runAnalysisPipeline(sourceObj, (step, total, text) => {
          this.currentStep = step;
          this.currentStepText = text;
          const statusTextEl = document.getElementById("ai-step-status-text");
          const progressBarEl = document.getElementById("ai-step-progress-bar");
          if (statusTextEl) statusTextEl.textContent = text;
          if (progressBarEl) progressBarEl.style.width = `${Math.round((step / total) * 100)}%`;
        });

        this.latestResult = report;
        window.FitPic.State.saveAnalysisReport(report);
      } catch (err) {
        console.error("AI Analysis error:", err);
      } finally {
        this.isAnalyzing = false;
        if (this.isCameraActive) {
          this.stopCameraStream();
        }
        this.render();
      }
    }

    askCoachAboutAnalysis() {
      if (!this.latestResult) return;
      const coachId = window.FitPic.State.getState().selectedCoach;
      const prompt = `Can you break down my recent AI Analysis for ${this.latestResult.exerciseName}? I got ${this.latestResult.repsDetected} reps with ${this.latestResult.confidence}% confidence.`;
      window.FitPic.Views.CoachView.sendPreloadedMessage(prompt);
      window.FitPic.App.navigate("coach");
    }

    render() {
      if (!this.container) return;

      const icons = window.FitPic.Icons;
      const sampleLinks = window.FitPic.AIService.getSampleVideoLinks();

      this.container.innerHTML = `
        <!-- Hero Header -->
        <div class="hero-ai-banner" style="margin-bottom: 16px;">
          <div class="hero-ai-tag">
            ${icons.sparkles(13, "#FFB394")} Hero Feature
          </div>
          <h2 class="hero-ai-title" style="font-size: 23px;">Fit Pic AI Vision Analysis</h2>
          <p class="hero-ai-desc" style="margin-bottom: 0;">
            Real-time exercise detection, form depth scoring, and biomechanical safety recommendations.
          </p>
        </div>

        <!-- 3 Input Method Selector Tabs -->
        <div style="display: flex; gap: 8px; margin-bottom: 16px;">
          <button onclick="window.FitPic.Views.AnalysisView.setMode('camera')"
                  class="btn ${this.currentMode === 'camera' ? 'btn-primary' : 'btn-secondary'}"
                  style="flex: 1; font-size: 12.5px; padding: 10px 6px;">
            ${icons.camera(16, this.currentMode === 'camera' ? '#FFFFFF' : 'currentColor')} Camera
          </button>
          <button onclick="window.FitPic.Views.AnalysisView.setMode('upload')"
                  class="btn ${this.currentMode === 'upload' ? 'btn-primary' : 'btn-secondary'}"
                  style="flex: 1; font-size: 12.5px; padding: 10px 6px;">
            ${icons.upload(16, this.currentMode === 'upload' ? '#FFFFFF' : 'currentColor')} Upload
          </button>
          <button onclick="window.FitPic.Views.AnalysisView.setMode('link')"
                  class="btn ${this.currentMode === 'link' ? 'btn-primary' : 'btn-secondary'}"
                  style="flex: 1; font-size: 12.5px; padding: 10px 6px;">
            ${icons.link(16, this.currentMode === 'link' ? '#FFFFFF' : 'currentColor')} Video Link
          </button>
        </div>

        <!-- ACTIVE PROCESSING STATE (SCANNING PIPELINE) -->
        ${this.isAnalyzing ? `
          <div class="card" style="padding: 24px; text-align: center; border: 2px solid var(--color-orange); box-shadow: var(--shadow-glow);">
            <div style="width: 60px; height: 60px; border-radius: 50%; background: var(--color-orange-soft); display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; color: var(--color-orange);">
              ${icons.sparkles(30, "var(--color-orange)")}
            </div>
            <h3 class="font-heading" style="font-size: 19px; margin: 0 0 6px;">AI Scanning Workout Biomechanics...</h3>
            <p id="ai-step-status-text" style="font-size: 13px; color: var(--text-secondary); margin-bottom: 14px;">
              ${this.currentStepText || "Initializing Fit Pic Neural Vision Engine..."}
            </p>
            <div class="progress-bar-bg" style="height: 10px;">
              <div id="ai-step-progress-bar" class="progress-bar-fill orange" style="width: 25%;"></div>
            </div>
            <p style="font-size: 11px; color: var(--text-muted); margin-top: 10px;">
              Analyzing joint angles, kinetic chain alignment, and repetition cadence
            </p>
          </div>
        ` : ''}

        <!-- OPTION 1: CAMERA WORKFLOW -->
        ${!this.isAnalyzing && this.currentMode === 'camera' ? `
          <div class="card" style="margin-bottom: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <div>
                <h3 class="font-heading" style="font-size: 16px; margin: 0;">Device Camera Analysis</h3>
                <p style="font-size: 12px; color: var(--text-secondary); margin: 2px 0 0;">Position your camera to see your full range of motion.</p>
              </div>
              <span class="chip chip-blue">${this.isCameraActive ? 'Live Active' : 'Camera Ready'}</span>
            </div>

            <div class="camera-viewfinder" style="margin-bottom: 14px;">
              ${this.isCameraActive ? `
                ${this.isSimulatedFeed ? `
                  <!-- Simulated Live Camera Canvas with Pose Skeleton -->
                  <div style="width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #13171F; color: #FFFFFF; position: relative;">
                    <svg viewBox="0 0 200 160" style="width: 65%; height: 65%; opacity: 0.85;">
                      <!-- Head -->
                      <circle cx="100" cy="30" r="10" stroke="#FF5A1F" stroke-width="2.5" fill="rgba(255,90,31,0.2)"/>
                      <!-- Torso -->
                      <line x1="100" y1="40" x2="100" y2="90" stroke="#FF8533" stroke-width="3"/>
                      <!-- Arms & Shoulders -->
                      <line x1="100" y1="48" x2="70" y2="70" stroke="#3E82CF" stroke-width="2.5"/>
                      <line x1="70" y1="70" x2="55" y2="95" stroke="#3E82CF" stroke-width="2.5"/>
                      <line x1="100" y1="48" x2="130" y2="70" stroke="#3E82CF" stroke-width="2.5"/>
                      <line x1="130" y1="70" x2="145" y2="95" stroke="#3E82CF" stroke-width="2.5"/>
                      <!-- Hips & Legs -->
                      <line x1="100" y1="90" x2="80" y2="120" stroke="#48C762" stroke-width="3"/>
                      <line x1="80" y1="120" x2="75" y2="150" stroke="#48C762" stroke-width="3"/>
                      <line x1="100" y1="90" x2="120" y2="120" stroke="#48C762" stroke-width="3"/>
                      <line x1="120" y1="120" x2="125" y2="150" stroke="#48C762" stroke-width="3"/>
                      <!-- Joint Dots -->
                      <circle cx="100" cy="48" r="3" fill="#FFFFFF"/>
                      <circle cx="70" cy="70" r="3" fill="#FFFFFF"/>
                      <circle cx="130" cy="70" r="3" fill="#FFFFFF"/>
                      <circle cx="80" cy="120" r="3" fill="#FFFFFF"/>
                      <circle cx="120" cy="120" r="3" fill="#FFFFFF"/>
                    </svg>
                    <div style="position: absolute; top: 12px; left: 14px; background: rgba(0,0,0,0.6); padding: 4px 8px; border-radius: var(--radius-sm); font-size: 11px; font-weight: 600; color: #48C762; display: flex; align-items: center; gap: 5px;">
                      <span style="width: 7px; height: 7px; border-radius: 50%; background: #48C762; display: inline-block;"></span>
                      POSE TRACKING ACTIVE
                    </div>
                  </div>
                ` : `
                  <video id="ai-camera-video" class="camera-video" autoplay playsinline muted></video>
                `}
                <div class="scan-line"></div>
                <div class="scan-hud">
                  <div class="scan-hud-corners"></div>
                </div>
              ` : `
                <div style="text-align: center; color: #94A3B8; padding: 24px;">
                  <div style="width: 52px; height: 52px; border-radius: 50%; background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; color: #FFFFFF;">
                    ${icons.camera(26, "#FFFFFF")}
                  </div>
                  <p style="font-size: 13.5px; font-weight: 600; color: #FFFFFF; margin: 0 0 4px;">Camera is Idle</p>
                  <p style="font-size: 11.5px; margin: 0;">Tap Open Camera to enable posture scan</p>
                </div>
              `}
              <canvas id="ai-camera-canvas" style="display: none;"></canvas>
            </div>

            <!-- Camera Controls -->
            <div style="display: flex; gap: 8px;">
              ${!this.isCameraActive ? `
                <button onclick="window.FitPic.Views.AnalysisView.startCameraStream()"
                        class="btn btn-primary btn-block" style="padding: 12px;">
                  ${icons.camera(16, '#FFFFFF')} Open Camera
                </button>
              ` : `
                <button onclick="window.FitPic.Views.AnalysisView.runAnalysis({ type: 'camera', label: 'Live Camera Squat Session' })"
                        class="btn btn-primary" style="flex: 2; padding: 12px;">
                  ${icons.sparkles(16, '#FFFFFF')} Analyze Live Feed
                </button>
                <button onclick="window.FitPic.Views.AnalysisView.stopCameraStream()"
                        class="btn btn-secondary" style="flex: 1; padding: 12px;">
                  Close
                </button>
              `}
            </div>

            <p style="font-size: 11px; color: var(--text-muted); margin-top: 10px; text-align: center;">
              🔒 Camera feeds are processed locally on your device for privacy. No video is uploaded to external servers.
            </p>
          </div>
        ` : ''}

        <!-- OPTION 2: UPLOAD WORKFLOW -->
        ${!this.isAnalyzing && this.currentMode === 'upload' ? `
          <div class="card" style="margin-bottom: 16px;">
            <h3 class="font-heading" style="font-size: 16px; margin: 0 0 4px;">Upload Workout Media</h3>
            <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 14px;">Select a workout clip (MP4/MOV) or pose photo (JPG/PNG).</p>

            <div onclick="document.getElementById('ai-file-input').click()"
                 style="border: 2px dashed var(--border-subtle); border-radius: var(--radius-lg); padding: 26px 16px; text-align: center; cursor: pointer; background: var(--bg-surface-secondary); transition: all var(--trans-fast);">
              <div style="width: 48px; height: 48px; border-radius: 50%; background: #FFFFFF; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; box-shadow: var(--shadow-xs); color: var(--color-orange);">
                ${icons.upload(22, "var(--color-orange)")}
              </div>
              <h4 class="font-heading" style="font-size: 15px; margin: 0 0 2px;">
                ${this.uploadedFile ? this.uploadedFile.name : "Choose File or Drag & Drop"}
              </h4>
              <p style="font-size: 11.5px; color: var(--text-muted); margin: 0;">
                ${this.uploadedFile ? `${(this.uploadedFile.size / (1024 * 1024)).toFixed(2)} MB • Ready for scan` : "Supports MP4, MOV, WebM, JPG, PNG"}
              </p>
              <input id="ai-file-input" type="file" accept="image/*,video/*" style="display: none;" onchange="window.FitPic.Views.AnalysisView.handleFileUpload(event)">
            </div>

            ${this.uploadedFile ? `
              <button onclick="window.FitPic.Views.AnalysisView.runAnalysis({ type: 'upload', filename: '${this.uploadedFile.name}' })"
                      class="btn btn-primary btn-block" style="margin-top: 14px; padding: 12px;">
                ${icons.sparkles(16, '#FFFFFF')} Run AI Analysis on Uploaded File
              </button>
            ` : ''}
          </div>
        ` : ''}

        <!-- OPTION 3: SOCIAL MEDIA / VIDEO LINK WORKFLOW -->
        ${!this.isAnalyzing && this.currentMode === 'link' ? `
          <div class="card" style="margin-bottom: 16px;">
            <h3 class="font-heading" style="font-size: 16px; margin: 0 0 4px;">Paste Workout Video Link</h3>
            <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 12px;">
              Analyze form from YouTube Shorts, Instagram Reels, TikTok, or direct video URLs.
            </p>

            <div style="display: flex; gap: 8px; margin-bottom: 14px;">
              <input id="ai-video-url-input" type="url" class="input-field"
                     placeholder="Paste workout video URL (e.g. YouTube, Reels)..."
                     value="${this.videoUrlInput}"
                     oninput="window.FitPic.Views.AnalysisView.videoUrlInput = this.value">
              <button onclick="window.FitPic.Views.AnalysisView.runAnalysis({ type: 'link', url: document.getElementById('ai-video-url-input').value || 'https://youtube.com/watch?v=squat_demo' })"
                      class="btn btn-primary" style="flex-shrink: 0; padding: 10px 16px;">
                Analyze Video
              </button>
            </div>

            <!-- Quick Preset Sample Links -->
            <span style="display: block; font-size: 11.5px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 8px;">
              Or Try a 1-Click Sample Workout Link:
            </span>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              ${sampleLinks.map(s => `
                <div onclick="window.FitPic.Views.AnalysisView.selectSampleLink('${s.url}', '${s.title}'); window.FitPic.Views.AnalysisView.runAnalysis({ type: 'link', url: '${s.url}', label: '${s.title}' });"
                     style="display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; border-radius: var(--radius-md); border: 1px solid var(--border-light); background: var(--bg-surface-secondary); cursor: pointer; transition: all var(--trans-fast);">
                  <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="width: 32px; height: 32px; border-radius: var(--radius-sm); background: #FFFFFF; display: flex; align-items: center; justify-content: center; color: var(--color-orange);">
                      ${icons.play(14, "var(--color-orange)")}
                    </div>
                    <div>
                      <h4 class="font-heading" style="font-size: 13.5px; margin: 0;">${s.title}</h4>
                      <span style="font-size: 11px; color: var(--text-muted);">${s.platform} • ${s.desc}</span>
                    </div>
                  </div>
                  ${icons.chevronRight(16, "var(--text-muted)")}
                </div>
              `).join("")}
            </div>
          </div>
        ` : ''}

        <!-- ANALYSIS RESULTS REPORT CARD (HERO PRESENTATION) -->
        ${!this.isAnalyzing && this.latestResult ? `
          <div id="ai-result-report" class="card" style="border: 2px solid var(--color-orange-light); box-shadow: var(--shadow-md); margin-bottom: 16px; animation: viewFadeIn 0.3s ease;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
              <div>
                <span class="chip chip-orange" style="font-size: 10px; margin-bottom: 4px;">
                  ${icons.sparkles(11, "var(--color-orange-deep)")} AI Analysis Report
                </span>
                <h3 class="font-heading" style="font-size: 20px; margin: 0;">${this.latestResult.exerciseName}</h3>
                <span style="font-size: 11.5px; color: var(--text-muted);">${this.latestResult.timestamp}</span>
              </div>
              <div style="text-align: right;">
                <span class="chip chip-green" style="font-size: 11px;">${this.latestResult.confidence}% Confidence</span>
                <p style="font-size: 10.5px; color: var(--text-muted); margin: 2px 0 0;">${this.latestResult.dataQuality.split(' ')[0]}</p>
              </div>
            </div>

            <!-- Key Biomechanical Metrics Grid -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 14px;">
              <div style="background: var(--bg-surface-secondary); padding: 10px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; color: var(--text-muted); font-weight: 600;">Repetitions</span>
                <p class="font-heading" style="font-size: 17px; margin: 2px 0 0; color: var(--color-orange);">
                  ${this.latestResult.repsDetected} reps <span style="font-size: 12px; color: var(--color-green);">(${this.latestResult.cleanReps} clean)</span>
                </p>
              </div>
              <div style="background: var(--bg-surface-secondary); padding: 10px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; color: var(--text-muted); font-weight: 600;">Cadence / Tempo</span>
                <p class="font-heading" style="font-size: 17px; margin: 2px 0 0; color: var(--color-blue);">${this.latestResult.cadenceSec}</p>
              </div>
              <div style="background: var(--bg-surface-secondary); padding: 10px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; color: var(--text-muted); font-weight: 600;">Depth & ROM</span>
                <p class="font-heading" style="font-size: 14px; margin: 2px 0 0; color: var(--text-primary);">${this.latestResult.depthAngle}</p>
              </div>
              <div style="background: var(--bg-surface-secondary); padding: 10px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; color: var(--text-muted); font-weight: 600;">Intensity (RPE)</span>
                <p class="font-heading" style="font-size: 14px; margin: 2px 0 0; color: var(--text-primary);">${this.latestResult.intensityRPE}</p>
              </div>
            </div>

            <!-- General Movement Observations -->
            <div style="margin-bottom: 14px; background: #FFFFFF; border: 1px solid var(--border-light); padding: 12px; border-radius: var(--radius-md);">
              <span style="display: block; font-size: 11.5px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 4px;">
                Movement Observations
              </span>
              <p style="font-size: 12.5px; color: var(--text-primary); line-height: 1.5; margin: 0;">
                ${this.latestResult.keyObservations}
              </p>
            </div>

            <!-- Technique & Safety Reminders -->
            <div style="margin-bottom: 14px; background: var(--color-orange-soft); border: 1px solid var(--color-orange-light); padding: 12px; border-radius: var(--radius-md);">
              <span style="display: block; font-size: 11.5px; font-weight: 700; color: var(--color-orange-deep); text-transform: uppercase; margin-bottom: 6px;">
                ⚠️ Safety & Form Reminders
              </span>
              <ul style="margin: 0; padding-left: 18px; font-size: 12px; color: var(--text-primary); line-height: 1.45;">
                ${this.latestResult.safetyTips.map(t => `<li style="margin-bottom: 4px;">${t}</li>`).join("")}
              </ul>
            </div>

            <!-- Areas to Improve -->
            <div style="margin-bottom: 14px; background: var(--color-blue-soft); border: 1px solid var(--color-blue-light); padding: 12px; border-radius: var(--radius-md);">
              <span style="display: block; font-size: 11.5px; font-weight: 700; color: var(--color-blue-deep); text-transform: uppercase; margin-bottom: 6px;">
                📈 Actionable Improvements
              </span>
              <ul style="margin: 0; padding-left: 18px; font-size: 12px; color: var(--text-primary); line-height: 1.45;">
                ${this.latestResult.improvementAreas.map(i => `<li style="margin-bottom: 4px;">${i}</li>`).join("")}
              </ul>
            </div>

            <!-- Goal, Diet & Workout Integration Cards -->
            <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px;">
              <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Suggested Goal</span>
                <p style="font-size: 12.5px; margin: 2px 0 0; font-weight: 600; color: var(--color-blue);">${this.latestResult.suggestedGoal}</p>
              </div>
              <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Diet Recommendation</span>
                <p style="font-size: 12px; margin: 2px 0 0; color: var(--text-primary);">${this.latestResult.dietRecommendations[0]}</p>
              </div>
              <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md);">
                <span style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Weekly Trajectory</span>
                <p style="font-size: 12px; margin: 2px 0 0; color: var(--text-primary);">${this.latestResult.progressInsight}</p>
              </div>
            </div>

            <!-- Action Buttons -->
            <div style="display: flex; gap: 8px;">
              <button onclick="window.FitPic.Views.AnalysisView.askCoachAboutAnalysis()"
                      class="btn btn-green" style="flex: 1; font-size: 12.5px; padding: 11px;">
                ${icons.messageCircle(15, '#FFFFFF')} Ask Coach About This
              </button>
              <button onclick="alert('Analysis report saved to your FitPic student history!')"
                      class="btn btn-secondary" style="flex: 1; font-size: 12.5px; padding: 11px;">
                ${icons.check(15, 'currentColor')} Save to History
              </button>
            </div>
          </div>
        ` : ''}

        <!-- Required Medical & Wellness Disclaimer -->
        <div class="disclaimer-box">
          ${icons.alertCircle(16, "var(--text-muted)")}
          <span>AI-generated fitness insights are estimates for general wellness and educational purposes and are not medical diagnoses. Consult a qualified fitness or healthcare professional when appropriate.</span>
        </div>
      `;
    }
  }

  window.FitPic.Views.AnalysisView = new AnalysisView();
})();
