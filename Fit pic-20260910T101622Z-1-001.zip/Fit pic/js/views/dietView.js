/**
 * FIT PIC — DIET & NUTRITION VIEW
 * Displays BMI calculation, Fitness Goal switcher, Veg/Non-Veg toggle,
 * and 7-day personalized Indian meal plan with macro breakdowns.
 */
window.FitPic = window.FitPic || {};
window.FitPic.Views = window.FitPic.Views || {};

(function() {
  const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  class DietView {
    constructor() {
      this.container = null;
    }

    init(containerEl) {
      this.container = containerEl;
      this.render();
      window.FitPic.State.subscribe("profileUpdate", () => this.render());
      window.FitPic.State.subscribe("dayChange", () => this.render());
    }

    render() {
      if (!this.container) return;

      const state = window.FitPic.State.getState();
      const profile = state.profile;
      const todayIndex = state.selectedDayIndex;
      const dietService = window.FitPic.DietService;
      const icons = window.FitPic.Icons;

      const bmi = dietService.calculateBMI(profile.height, profile.weight);
      const goals = dietService.getGoals();
      const currentDayPlan = dietService.generateDayMealPlan(profile, todayIndex);

      this.container.innerHTML = `
        <div class="section-header">
          <h2 class="section-title">Personalized Diet & Nutrition</h2>
          <p class="section-desc">Indian-friendly meals tailored to your metrics and student lifestyle.</p>
        </div>

        <!-- BMI Card -->
        <div class="card" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div>
              <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Body Mass Index</span>
              <div style="display: flex; align-items: baseline; gap: 8px; margin: 2px 0;">
                <span class="font-heading" style="font-size: 30px; font-weight: 800; color: var(--text-primary);">${bmi.value}</span>
                <span class="chip chip-${bmi.color}">${bmi.category}</span>
              </div>
            </div>
            <button class="btn btn-secondary btn-sm" onclick="window.FitPic.Views.ProfileView.openEditModal()">
              ${icons.edit(13, "currentColor")} Edit Stats
            </button>
          </div>
          <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.5; margin: 0;">
            ${bmi.explanation}
          </p>
        </div>

        <!-- Fitness Goals Selector (3 Options) -->
        <div class="card" style="margin-bottom: 16px;">
          <span style="display: block; font-size: 12px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 10px;">
            Select Fitness Goal (Updates Diet & Workout)
          </span>
          <div style="display: flex; flex-direction: column; gap: 8px;">
            ${goals.map(g => {
              const active = profile.goal === g.id;
              return `
                <div onclick="window.FitPic.State.setFitnessGoal('${g.id}')"
                     style="padding: 12px 14px; border-radius: var(--radius-md); border: 2px solid ${active ? `var(--color-${g.color})` : 'var(--border-light)'}; background: ${active ? `var(--color-${g.color}-soft)` : '#FFFFFF'}; cursor: pointer; display: flex; align-items: center; justify-content: space-between; transition: all var(--trans-fast);">
                  <div>
                    <div style="display: flex; align-items: center; gap: 6px;">
                      <span class="font-heading" style="font-size: 14.5px; font-weight: 700; color: ${active ? `var(--color-${g.color}-deep)` : 'var(--text-primary)'};">
                        ${g.label}
                      </span>
                      <span class="chip chip-${g.color}" style="font-size: 10px; padding: 2px 7px;">${g.badgeText}</span>
                    </div>
                    <p style="font-size: 11.5px; color: var(--text-secondary); margin: 3px 0 0;">${g.subtitle}</p>
                  </div>
                  <div style="width: 22px; height: 22px; border-radius: 50%; border: 2px solid ${active ? `var(--color-${g.color})` : 'var(--border-subtle)'}; background: ${active ? `var(--color-${g.color})` : 'transparent'}; display: flex; align-items: center; justify-content: center;">
                    ${active ? icons.check(13, '#FFFFFF') : ''}
                  </div>
                </div>
              `;
            }).join("")}
          </div>

          <!-- Diet Preference Toggle (Veg / Non-veg) -->
          <div style="margin-top: 14px; padding-top: 14px; border-top: 1px solid var(--border-light);">
            <span style="display: block; font-size: 11.5px; font-weight: 600; color: var(--text-secondary); margin-bottom: 8px;">Diet Preference</span>
            <div style="display: flex; gap: 8px;">
              <button onclick="window.FitPic.State.setDietPref('veg')"
                      class="btn ${profile.dietPref === 'veg' ? 'btn-green' : 'btn-secondary'}"
                      style="flex: 1; font-size: 13px; padding: 10px;">
                ${icons.leaf(15, profile.dietPref === 'veg' ? '#FFFFFF' : 'var(--color-green)')} Vegetarian
              </button>
              <button onclick="window.FitPic.State.setDietPref('nonveg')"
                      class="btn ${profile.dietPref === 'nonveg' ? 'btn-orange' : 'btn-secondary'}"
                      style="flex: 1; font-size: 13px; padding: 10px; ${profile.dietPref === 'nonveg' ? 'background: var(--color-orange); color: #fff;' : ''}">
                ${icons.drumstick(15, profile.dietPref === 'nonveg' ? '#FFFFFF' : 'var(--color-orange)')} Non-Vegetarian
              </button>
            </div>
          </div>
        </div>

        <!-- 7-Day Day Selector Strip -->
        <div style="margin-bottom: 12px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <h3 class="font-heading" style="font-size: 16px; margin: 0;">7-Day Meal Schedule</h3>
            <span style="font-size: 11.5px; color: var(--color-blue); font-weight: 700;">Viewing: ${DAY_NAMES[todayIndex]}</span>
          </div>
          <div class="day-selector-strip">
            ${DAY_NAMES.map((name, idx) => `
              <button onclick="window.FitPic.State.setSelectedDay(${idx})"
                      class="day-pill ${idx === todayIndex ? 'active' : ''}">
                <span class="day-pill-name">${name.slice(0, 3)}</span>
                <span class="day-pill-status" style="font-size: 10.5px;">${idx + 1}</span>
              </button>
            `).join("")}
          </div>
        </div>

        <!-- Daily Targets Summary Card -->
        <div class="card card-gradient-orange" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <div>
              <p style="font-size: 11px; font-weight: 700; color: var(--color-orange-deep); text-transform: uppercase;">Estimated Daily Energy</p>
              <h3 class="font-heading" style="font-size: 22px; margin: 0; color: var(--color-orange-deep);">${currentDayPlan.targets.targetCalories} kcal</h3>
            </div>
            <span class="chip chip-orange">${profile.dietPref === 'veg' ? 'Pure Vegetarian' : 'Includes Eggs / Meat'}</span>
          </div>

          <!-- Macros Distribution Grid -->
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; background: #FFFFFF; padding: 10px; border-radius: var(--radius-md); border: 1px solid var(--color-orange-light);">
            <div style="text-align: center;">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 600;">Protein</span>
              <p class="font-heading" style="font-size: 16px; margin: 1px 0; color: var(--color-blue);">${currentDayPlan.targets.proteinGrams}g</p>
              <div class="progress-bar-bg" style="height: 4px;"><div class="progress-bar-fill blue" style="width: 100%;"></div></div>
            </div>
            <div style="text-align: center;">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 600;">Carbs</span>
              <p class="font-heading" style="font-size: 16px; margin: 1px 0; color: var(--color-orange);">${currentDayPlan.targets.carbGrams}g</p>
              <div class="progress-bar-bg" style="height: 4px;"><div class="progress-bar-fill orange" style="width: 100%;"></div></div>
            </div>
            <div style="text-align: center;">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 600;">Healthy Fats</span>
              <p class="font-heading" style="font-size: 16px; margin: 1px 0; color: var(--color-green);">${currentDayPlan.targets.fatGrams}g</p>
              <div class="progress-bar-bg" style="height: 4px;"><div class="progress-bar-fill green" style="width: 100%;"></div></div>
            </div>
          </div>
        </div>

        <!-- 5 Meal Slots for Today -->
        <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 16px;">
          ${Object.values(currentDayPlan.meals).map(m => `
            <div class="card" style="padding: 14px; margin-bottom: 0; border-left: 4px solid var(--color-${m.color});">
              <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                  <span style="font-size: 11px; font-weight: 700; color: var(--color-${m.color}-deep); text-transform: uppercase; letter-spacing: 0.04em;">
                    ${m.label}
                  </span>
                  <h4 class="font-heading" style="font-size: 14.5px; margin: 2px 0 0;">${m.name}</h4>
                </div>
                <span class="chip chip-${m.color}" style="font-size: 11.5px; font-weight: 700;">${m.kcal} kcal</span>
              </div>
              <div style="display: flex; gap: 14px; margin-top: 8px; font-size: 11.5px; color: var(--text-secondary);">
                <span>Protein: <strong>${m.protein}g</strong></span>
                <span>Carbs: <strong>${m.carbs}g</strong></span>
                <span>Fats: <strong>${m.fat}g</strong></span>
              </div>
            </div>
          `).join("")}
        </div>

        <!-- Nutritional Wellness Disclaimer -->
        <div class="disclaimer-box">
          ${icons.info(16, "var(--text-muted)")}
          <span>Fit Pic provides general wellness guidance and realistic Indian meal ideas. Nutrition values are estimates and not medical or nutritional prescriptions. It is not a substitute for professional medical or nutritional advice.</span>
        </div>
      `;
    }
  }

  window.FitPic.Views.DietView = new DietView();
})();
