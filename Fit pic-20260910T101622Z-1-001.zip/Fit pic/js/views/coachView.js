/**
 * FIT PIC — AI SMART COACH VIEW
 * Dual AI Coaching System: Coach Maya & Coach Shannu.
 * Animated talking states, interactive hand gestures, soundwave visualizers,
 * user profile avatar chat bubbles, and dynamic chatbot responses.
 */
window.FitPic = window.FitPic || {};
window.FitPic.Views = window.FitPic.Views || {};

(function() {
  class CoachView {
    constructor() {
      this.container = null;
      this.isTyping = false;
      this.isTalking = false;
      this.activeGesture = null; // 'wave', 'flex', 'point'
      this.pendingPreloadedMessage = null;
    }

    init(containerEl) {
      this.container = containerEl;
      this.render();
      window.FitPic.State.subscribe("coachChange", () => this.render());
      window.FitPic.State.subscribe("chatMessageAdded", () => {
        this.render();
        this.scrollToBottom();
      });
      window.FitPic.State.subscribe("profileAvatarUpdate", () => this.render());
    }

    sendPreloadedMessage(text) {
      this.pendingPreloadedMessage = text;
      setTimeout(() => {
        const inputEl = document.getElementById("coach-chat-input");
        if (inputEl) {
          inputEl.value = text;
          this.sendMessage();
        }
      }, 150);
    }

    switchCoach(coachId) {
      window.FitPic.State.setSelectedCoach(coachId);
      this.activeGesture = null;
    }

    async triggerGesture(gestureType) {
      if (this.isTyping) return;
      const state = window.FitPic.State.getState();
      const coachId = state.selectedCoach;

      // Trigger animation on coach standee / avatar
      this.activeGesture = gestureType;
      this.isTalking = true;
      this.render();

      try {
        const reaction = await window.FitPic.CoachService.getGestureReaction(coachId, gestureType);
        const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        window.FitPic.State.addChatMessage(coachId, {
          role: "assistant",
          text: reaction,
          time: now
        });
      } catch (err) {
        console.error("Gesture error:", err);
      } finally {
        setTimeout(() => {
          this.isTalking = false;
          this.activeGesture = null;
          this.render();
          this.scrollToBottom();
        }, 1200);
      }
    }

    async sendMessage(promptText) {
      const inputEl = document.getElementById("coach-chat-input");
      const text = (promptText || (inputEl ? inputEl.value : "")).trim();
      if (!text || this.isTyping) return;

      if (inputEl) inputEl.value = "";

      const state = window.FitPic.State.getState();
      const coachId = state.selectedCoach;
      const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      // Add user message
      window.FitPic.State.addChatMessage(coachId, {
        role: "user",
        text,
        time: now
      });

      this.isTyping = true;
      this.isTalking = true; // Coach talking animation triggers
      this.render();
      this.scrollToBottom();

      try {
        const replyText = await window.FitPic.CoachService.getCoachResponse(coachId, text);
        const replyNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        window.FitPic.State.addChatMessage(coachId, {
          role: "assistant",
          text: replyText,
          time: replyNow
        });
      } catch (err) {
        console.error("Coach response error:", err);
      } finally {
        this.isTyping = false;
        // Keep speaking animation for a brief moment after response completes
        setTimeout(() => {
          this.isTalking = false;
          this.render();
          this.scrollToBottom();
        }, 800);
      }
    }

    scrollToBottom() {
      setTimeout(() => {
        const chatMsgs = document.getElementById("coach-chat-messages");
        if (chatMsgs) {
          chatMsgs.scrollTop = chatMsgs.scrollHeight;
        }
      }, 50);
    }

    render() {
      if (!this.container) return;

      const state = window.FitPic.State.getState();
      const coachId = state.selectedCoach;
      const coach = window.FitPic.CoachService.getCoach(coachId);
      const chats = (state.coachChats && state.coachChats[coachId]) || [];
      const quickPrompts = window.FitPic.CoachService.getQuickPrompts();
      const icons = window.FitPic.Icons;
      const profile = state.profile;

      let gestureClass = "";
      if (this.activeGesture === "wave") gestureClass = "coach-gesture-wave";
      else if (this.activeGesture === "flex") gestureClass = "coach-gesture-flex";
      else if (this.activeGesture === "point" || this.activeGesture === "tip") gestureClass = "coach-gesture-point";

      const talkingClass = this.isTalking ? "coach-is-talking" : "";

      this.container.innerHTML = `
        <div class="section-header" style="margin-bottom: 12px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h2 class="section-title">AI Smart Coach</h2>
              <p class="section-desc">Interactive guidance from Coach Maya & Coach Shannu.</p>
            </div>
            <span class="chip chip-blue" style="font-size: 11px;">
              ${icons.dumbbell(13, "#5EBE1A")} Live Coaching
            </span>
          </div>
        </div>

        <!-- Coach Selector Bar (Maya vs Shannu) -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px;">
          <button onclick="window.FitPic.Views.CoachView.switchCoach('maya')"
                  class="btn ${coachId === 'maya' ? 'btn-green' : 'btn-secondary'}"
                  style="display: flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 8px; font-size: 13px;">
            <span style="width: 28px; height: 28px; border-radius: 50%; overflow: hidden; display: inline-flex; border: 1.5px solid #5EBE1A;">
              <img src="assets/maya.png" alt="Maya" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; transform: scale(1.3);">
            </span>
            <span>Coach Maya <small style="display:block; font-size:10px; opacity:0.85;">Nutrition & Fat Loss</small></span>
          </button>
          <button onclick="window.FitPic.Views.CoachView.switchCoach('shannu')"
                  class="btn ${coachId === 'shannu' ? 'btn-blue' : 'btn-secondary'}"
                  style="display: flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 8px; font-size: 13px;">
            <span style="width: 28px; height: 28px; border-radius: 50%; overflow: hidden; display: inline-flex; border: 1.5px solid #5EBE1A;">
              <img src="assets/shannu.png" alt="Shannu" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; transform: scale(1.3);">
            </span>
            <span>Coach Shannu <small style="display:block; font-size:10px; opacity:0.85;">Strength & Dumbbells</small></span>
          </button>
        </div>

        <!-- Active Coach Header Card with Talking & Gesture Animations -->
        <div class="coach-header-card ${talkingClass} ${gestureClass}">
          <div class="coach-avatar-lg ${talkingClass}">
            <img src="${coach.avatarImg}" alt="${coach.name}">
            <div class="coach-status-dot"></div>
          </div>
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; justify-content: space-between;">
              <div style="display: flex; align-items: center; gap: 6px;">
                <h3 class="font-heading" style="font-size: 17px; margin: 0; color: #FFFFFF;">${coach.name}</h3>
                <span class="chip chip-green" style="font-size: 10px;">${coach.title}</span>
              </div>
              ${this.isTalking ? `
                <div style="display: flex; align-items: center; gap: 4px; background: rgba(94, 190, 26, 0.2); padding: 2px 8px; border-radius: var(--radius-full);">
                  ${icons.soundWaves(14, "#5EBE1A")}
                  <span style="font-size: 10px; color: #5EBE1A; font-weight: 700;">Talking</span>
                </div>
              ` : `
                <span style="font-size: 10px; color: #7CA870; font-weight: 600;">● Active</span>
              `}
            </div>
            <p style="font-size: 12px; color: #C5D4BF; margin: 3px 0 0; line-height: 1.35;">
              ${coach.bio}
            </p>
          </div>
        </div>

        <!-- Interactive Coach Gesture Buttons (Hand gestures & animated responses) -->
        <div class="coach-gestures-row">
          <button class="coach-gesture-btn" onclick="window.FitPic.Views.CoachView.triggerGesture('wave')" title="Make coach wave">
            👋 Wave Hello
          </button>
          <button class="coach-gesture-btn" onclick="window.FitPic.Views.CoachView.triggerGesture('flex')" title="Make coach flex biceps">
            💪 Flex Motivation
          </button>
          <button class="coach-gesture-btn" onclick="window.FitPic.Views.CoachView.triggerGesture('tip')" title="Ask coach for form tip">
            🎯 Form & Nutrition Tip
          </button>
          <button class="coach-gesture-btn" onclick="window.FitPic.Views.CoachView.triggerGesture('push')" title="Request high intensity push">
            🔥 Push Me Hard!
          </button>
        </div>

        <!-- Chat Box Container -->
        <div class="chat-box">
          <!-- Messages Scroll Area -->
          <div id="coach-chat-messages" class="chat-messages">
            ${chats.map(m => `
              <div class="chat-message-row ${m.role === 'user' ? 'row-user' : 'row-coach'}">
                ${m.role === 'assistant' ? `
                  <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; border: 1.5px solid #5EBE1A; flex-shrink: 0; background: #11161B;">
                    <img src="${coach.avatarImg}" alt="${coach.name}" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; transform: scale(1.3);">
                  </div>
                ` : ''}

                <div class="chat-bubble ${m.role === 'user' ? 'chat-bubble-user' : 'chat-bubble-coach'}">
                  <div style="white-space: pre-wrap;">${m.text}</div>
                  <div style="font-size: 10px; margin-top: 4px; opacity: 0.65; text-align: ${m.role === 'user' ? 'right' : 'left'};">
                    ${m.time || ''}
                  </div>
                </div>

                ${m.role === 'user' ? `
                  ${icons.userAvatar(32, profile.avatar, true)}
                ` : ''}
              </div>
            `).join("")}

            <!-- Typing Indicator when Coach is Generating Response -->
            ${this.isTyping ? `
              <div class="chat-message-row row-coach">
                <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; border: 1.5px solid #5EBE1A; flex-shrink: 0; background: #11161B;">
                  <img src="${coach.avatarImg}" alt="${coach.name}" class="coach-is-talking" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; transform: scale(1.3);">
                </div>
                <div class="chat-bubble chat-bubble-coach" style="display: flex; align-items: center; gap: 8px; padding: 10px 14px;">
                  <div class="typing-dots">
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                  </div>
                  <span style="font-size: 11.5px; color: var(--text-secondary); font-weight: 600;">
                    ${coach.name} is speaking...
                  </span>
                  ${icons.soundWaves(14, "#5EBE1A")}
                </div>
              </div>
            ` : ''}
          </div>

          <!-- Quick Suggestion Pills -->
          <div class="chat-quick-prompts">
            ${quickPrompts.map(p => `
              <button class="quick-prompt-pill" onclick="window.FitPic.Views.CoachView.sendMessage('${p.query.replace(/'/g, "\\'")}')">
                ${p.label}
              </button>
            `).join("")}
          </div>

          <!-- Chat Input Bar -->
          <form class="chat-input-bar" onsubmit="event.preventDefault(); window.FitPic.Views.CoachView.sendMessage();">
            <input type="text"
                   id="coach-chat-input"
                   class="chat-input"
                   placeholder="Ask ${coach.name} about workouts, fat burn, meals..."
                   autocomplete="off"
                   ${this.isTyping ? 'disabled' : ''}>
            <button type="submit" class="chat-send-btn" title="Send message" ${this.isTyping ? 'disabled' : ''}>
              ${icons.send(18, "#FFFFFF")}
            </button>
          </form>
        </div>
      `;

      // Setup Enter key on input
      const inputEl = document.getElementById("coach-chat-input");
      if (inputEl) {
        inputEl.addEventListener("keydown", (e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            this.sendMessage();
          }
        });
      }
    }
  }

  window.FitPic.Views.CoachView = new CoachView();
})();
