/**
 * FIT PIC — PROFILE & AUTHENTICATION VIEW
 * Manages student user credentials, custom profile photo upload,
 * preset fitness avatars, inclusive gender options (including Transgender),
 * weight loss goals, physical metrics, and account settings.
 */
window.FitPic = window.FitPic || {};
window.FitPic.Views = window.FitPic.Views || {};

(function() {
  class ProfileView {
    constructor() {
      this.container = null;
      this.isEditModalOpen = false;
      this.isAuthModalOpen = false;
      this.authMode = "login"; // 'login' or 'signup'
    }

    init(containerEl) {
      this.container = containerEl;
      this.render();
      window.FitPic.State.subscribe("profileUpdate", () => this.render());
      window.FitPic.State.subscribe("workoutProgressUpdate", () => this.render());
      window.FitPic.State.subscribe("profileAvatarUpdate", () => this.render());
    }

    openEditModal() {
      this.isEditModalOpen = true;
      this.render();
    }

    closeEditModal() {
      this.isEditModalOpen = false;
      this.render();
    }

    openAuthModal(mode = "login") {
      this.authMode = mode;
      this.isAuthModalOpen = true;
      this.render();
    }

    closeAuthModal() {
      this.isAuthModalOpen = false;
      this.render();
    }

    triggerFileInput() {
      const input = document.getElementById("profile-photo-file-input");
      if (input) input.click();
    }

    handlePhotoUpload(e) {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      if (!file.type.startsWith("image/")) {
        alert("Please select a valid image file (JPEG, PNG, WEBP).");
        return;
      }

      // Max 4MB size check
      if (file.size > 4 * 1024 * 1024) {
        alert("Image size is too large. Please select a photo under 4MB.");
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target.result;
        window.FitPic.State.setProfileAvatar(dataUrl);
      };
      reader.readAsDataURL(file);
    }

    selectPresetAvatar(presetId) {
      const preset = window.FitPic.Icons.presetAvatars.find(p => p.id === presetId);
      if (!preset) return;

      const svgString = `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120"><rect width="120" height="120" rx="60" fill="#11161B"/><circle cx="60" cy="60" r="50" fill="${preset.color}" fill-opacity="0.22" stroke="${preset.color}" stroke-width="4"/><text x="60" y="74" font-size="52" text-anchor="middle" dominant-baseline="middle">${preset.icon}</text></svg>`;
      const dataUrl = `data:image/svg+xml;utf8,${encodeURIComponent(svgString)}`;
      window.FitPic.State.setProfileAvatar(dataUrl);
    }

    removePhoto() {
      window.FitPic.State.setProfileAvatar(null);
    }

    saveProfileFromForm(e) {
      if (e) e.preventDefault();
      const name = document.getElementById("edit-name").value.trim() || "Student";
      const email = document.getElementById("edit-email").value.trim() || "student@college.edu";
      const age = parseInt(document.getElementById("edit-age").value, 10) || 21;
      const height = parseFloat(document.getElementById("edit-height").value) || 174;
      const weight = parseFloat(document.getElementById("edit-weight").value) || 72;
      const targetWeight = parseFloat(document.getElementById("edit-target-weight") ? document.getElementById("edit-target-weight").value : 65) || 65;
      const gender = document.getElementById("edit-gender").value || "male";
      const activityLevel = document.getElementById("edit-activity").value || "moderate";
      const goal = document.getElementById("edit-goal").value || "lose";
      const dietPref = document.getElementById("edit-diet").value || "veg";
      const fitnessLevel = document.getElementById("edit-level").value || "intermediate";

      window.FitPic.State.updateProfile({
        name, email, age, height, weight, targetWeight, gender, activityLevel, goal, dietPref, fitnessLevel
      });

      this.closeEditModal();
      alert("Profile updated successfully! Your Diet and Dumbbell Workout plans have been recalculated.");
    }

    handleAuthSubmit(e) {
      if (e) e.preventDefault();
      const email = document.getElementById("auth-email").value.trim();
      const name = (document.getElementById("auth-name") && document.getElementById("auth-name").value.trim()) || "Student";

      window.FitPic.State.updateProfile({
        name,
        email: email || "student@college.edu",
        loggedIn: true
      });

      this.closeAuthModal();
      alert(`Welcome back to Fit Pic, ${name}!`);
    }

    handleLogout() {
      window.FitPic.State.updateProfile({ loggedIn: false });
      alert("You have logged out of Fit Pic.");
      this.render();
    }

    resetDemoData() {
      if (confirm("Reset Fit Pic to initial student demo state?")) {
        window.FitPic.State.resetToDemoDefaults();
        alert("Reset complete! Default profile, avatar, and progress restored.");
      }
    }

    render() {
      if (!this.container) return;

      const state = window.FitPic.State.getState();
      const profile = state.profile;
      const dietService = window.FitPic.DietService;
      const bmi = dietService.calculateBMI(profile.height, profile.weight);
      const targets = dietService.calculateTargets(profile);
      const icons = window.FitPic.Icons;
      const completedCount = Object.values(state.workoutProgress).filter(Boolean).length;
      const presets = icons.presetAvatars;

      let genderLabel = "Male";
      let genderIcon = icons.genderMale(16, "var(--color-primary-deep)");
      if (profile.gender === "female") {
        genderLabel = "Female";
        genderIcon = icons.genderFemale(16, "var(--color-primary-deep)");
      } else if (profile.gender === "transgender") {
        genderLabel = "Transgender 🏳️‍⚧️";
        genderIcon = icons.genderTransgender(16, "var(--color-primary-deep)");
      }

      this.container.innerHTML = `
        <!-- Hidden Image File Input -->
        <input type="file" id="profile-photo-file-input" accept="image/*" style="display: none;" onchange="window.FitPic.Views.ProfileView.handlePhotoUpload(event)">

        <div class="section-header">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h2 class="section-title">Student Profile & Settings</h2>
              <p class="section-desc">Manage your avatar, fitness goals, and physical metrics.</p>
            </div>
            <span class="dumbbell-badge">
              ${icons.dumbbell(14, "#5EBE1A")} Dumbbell Pro
            </span>
          </div>
        </div>

        <!-- Student Profile Card with Avatar Upload Trigger -->
        <div class="card card-gradient-green" style="margin-bottom: 16px; position: relative;">
          <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 16px;">
            <!-- Interactive Avatar with Camera Upload Overlay -->
            <div style="position: relative; cursor: pointer;" onclick="window.FitPic.Views.ProfileView.triggerFileInput()" title="Click to upload profile photo">
              ${icons.userAvatar(72, profile.avatar, true)}
              <div class="avatar-upload-badge" title="Change profile photo">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
                  <circle cx="12" cy="13" r="3"></circle>
                </svg>
              </div>
            </div>

            <div style="flex: 1;">
              <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                <h3 class="font-heading" style="font-size: 20px; margin: 0; color: #11161B;">${profile.name || "Student"}</h3>
                <span class="chip chip-blue" style="font-size: 10px;">Fit Pic Athlete</span>
              </div>
              <p style="font-size: 12px; color: var(--text-secondary); margin: 2px 0 0;">${profile.email}</p>
              <p style="font-size: 11.5px; color: var(--color-primary-deep); font-weight: 700; margin: 2px 0 0;">
                ${profile.college || "Campus Tech University"}
              </p>
            </div>
          </div>

          <!-- Quick Avatar Action Buttons -->
          <div style="display: flex; gap: 8px; margin-bottom: 14px;">
            <button class="btn btn-sm btn-primary" onclick="window.FitPic.Views.ProfileView.triggerFileInput()" style="flex: 1; font-size: 12px; padding: 7px 10px;">
              ${icons.upload(14, "#FFFFFF")} Upload Photo
            </button>
            ${profile.avatar ? `
              <button class="btn btn-sm btn-secondary" onclick="window.FitPic.Views.ProfileView.removePhoto()" style="font-size: 12px; padding: 7px 10px;">
                Reset
              </button>
            ` : ''}
          </div>

          <!-- Preset Avatars Selector Row -->
          <div>
            <span style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.04em; display: block; margin-bottom: 6px;">
              Or Choose Athletic Preset Avatar:
            </span>
            <div class="preset-avatars-grid">
              ${presets.map(p => `
                <button class="preset-avatar-btn" onclick="window.FitPic.Views.ProfileView.selectPresetAvatar('${p.id}')" title="${p.name} — ${p.desc}">
                  ${p.icon}
                </button>
              `).join("")}
            </div>
          </div>

          <div style="margin-top: 14px; border-top: 1px solid var(--border-light); padding-top: 12px;">
            <button onclick="window.FitPic.Views.ProfileView.openEditModal()"
                    class="btn btn-dark btn-block" style="padding: 11px; font-size: 13px;">
              ${icons.edit(15, "#5EBE1A")} Edit Metrics & Fitness Goal
            </button>
          </div>
        </div>

        <!-- Physical Metrics Summary Grid -->
        <div class="card" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 11.5px; font-weight: 800; color: #11161B; text-transform: uppercase; letter-spacing: 0.05em;">
              Current Fitness Metrics
            </span>
            <span class="chip chip-green" style="font-size: 10.5px;">
              ${targets.goalObj.badgeText}
            </span>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Age & Gender</span>
              <p class="font-heading" style="font-size: 15px; margin: 3px 0 0; display: flex; align-items: center; gap: 5px; color: #11161B;">
                ${profile.age} yrs • ${genderIcon} ${genderLabel}
              </p>
            </div>

            <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Height & Weight</span>
              <p class="font-heading" style="font-size: 15px; margin: 3px 0 0; color: #11161B;">
                ${profile.height} cm • ${profile.weight} kg
              </p>
            </div>

            <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Calculated BMI</span>
              <p class="font-heading" style="font-size: 15px; margin: 3px 0 0; color: #5EBE1A;">
                ${bmi.value} <small style="font-size: 11px; font-weight: 600; color: var(--text-secondary);">(${bmi.category})</small>
              </p>
            </div>

            <div style="background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
              <span style="font-size: 10.5px; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Daily Calorie Goal</span>
              <p class="font-heading" style="font-size: 15px; margin: 3px 0 0; color: #5EBE1A;">
                ${targets.targetCalories} kcal
              </p>
            </div>
          </div>

          <!-- Weight Loss Progress Row -->
          ${profile.goal === 'lose' ? `
            <div style="margin-top: 12px; padding: 10px 12px; background: var(--color-primary-soft); border-radius: var(--radius-md); border: 1px solid var(--color-primary-light);">
              <div style="display: flex; justify-content: space-between; font-size: 12px; color: var(--color-primary-deep); font-weight: 700;">
                <span>🔥 Weight Loss Deficit: -450 kcal</span>
                <span>Target: ${profile.targetWeight || 65} kg</span>
              </div>
            </div>
          ` : ''}
        </div>

        <!-- Weekly Fitness Milestones -->
        <div class="card" style="margin-bottom: 16px;">
          <h3 class="font-heading" style="font-size: 16px; margin: 0 0 12px; color: #11161B;">Training Consistency</h3>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-size: 13px; color: var(--text-secondary);">Workouts Completed This Week</span>
            <span class="font-heading" style="font-size: 16px; color: #5EBE1A;">${completedCount} of 7</span>
          </div>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill green" style="width: ${(completedCount / 7) * 100}%;"></div>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; color: var(--text-muted); margin-top: 6px;">
            <span>Current Streak: <strong>${state.streakDays} Days 🔥</strong></span>
            <span>All-time Total: <strong>${state.totalWorkoutsCompleted} Sessions</strong></span>
          </div>
        </div>

        <!-- Account Actions -->
        <div class="card" style="margin-bottom: 20px;">
          <div style="display: flex; flex-direction: column; gap: 8px;">
            <button onclick="window.FitPic.Views.ProfileView.resetDemoData()"
                    class="btn btn-secondary btn-block" style="font-size: 13px; padding: 10px;">
              ${icons.link(14, "currentColor")} Reset Demo Data
            </button>
            <button onclick="window.FitPic.Views.ProfileView.handleLogout()"
                    class="btn btn-secondary btn-block" style="font-size: 13px; padding: 10px; color: #D32F2F;">
              Sign Out of Fit Pic
            </button>
          </div>
        </div>

        <!-- EDIT PROFILE MODAL (Inclusive Transgender & Weight Loss) -->
        <div class="modal-overlay ${this.isEditModalOpen ? 'active' : ''}" id="edit-profile-modal">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="font-heading" style="font-size: 18px; margin: 0; color: #11161B;">Edit Personal & Fitness Profile</h3>
              <button class="modal-close-btn" onclick="window.FitPic.Views.ProfileView.closeEditModal()">
                ${icons.x(16, "currentColor")}
              </button>
            </div>

            <form onsubmit="window.FitPic.Views.ProfileView.saveProfileFromForm(event)">
              <div class="input-group">
                <label class="input-label" for="edit-name">Full Name</label>
                <input type="text" id="edit-name" class="input-field" value="${profile.name || ''}" required>
              </div>

              <div class="input-group">
                <label class="input-label" for="edit-email">Student Email</label>
                <input type="email" id="edit-email" class="input-field" value="${profile.email || ''}" required>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="input-group">
                  <label class="input-label" for="edit-age">Age</label>
                  <input type="number" id="edit-age" class="input-field" min="14" max="80" value="${profile.age}" required>
                </div>
                <!-- GENDER SELECTOR WITH TRANSGENDER OPTION -->
                <div class="input-group">
                  <label class="input-label" for="edit-gender">Gender</label>
                  <select id="edit-gender" class="input-field">
                    <option value="male" ${profile.gender === 'male' ? 'selected' : ''}>Male</option>
                    <option value="female" ${profile.gender === 'female' ? 'selected' : ''}>Female</option>
                    <option value="transgender" ${profile.gender === 'transgender' ? 'selected' : ''}>Transgender (Inclusive)</option>
                  </select>
                </div>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="input-group">
                  <label class="input-label" for="edit-height">Height (cm)</label>
                  <input type="number" id="edit-height" class="input-field" min="100" max="230" value="${profile.height}" required>
                </div>
                <div class="input-group">
                  <label class="input-label" for="edit-weight">Current Weight (kg)</label>
                  <input type="number" id="edit-weight" class="input-field" min="30" max="200" step="0.5" value="${profile.weight}" required>
                </div>
              </div>

              <!-- Target Weight for Weight Loss -->
              <div class="input-group">
                <label class="input-label" for="edit-target-weight">Target Weight Goal (kg)</label>
                <input type="number" id="edit-target-weight" class="input-field" min="30" max="200" step="0.5" value="${profile.targetWeight || 65}">
              </div>

              <!-- FITNESS GOAL SELECTOR WITH WEIGHT LOSS -->
              <div class="input-group">
                <label class="input-label" for="edit-goal">Primary Fitness Goal</label>
                <select id="edit-goal" class="input-field">
                  <option value="lose" ${profile.goal === 'lose' ? 'selected' : ''}>🔥 Weight Loss & Fat Burn (Calorie Deficit)</option>
                  <option value="recomp" ${profile.goal === 'recomp' ? 'selected' : ''}>⚡ Body Recomposition (Build & Tone)</option>
                  <option value="gain" ${profile.goal === 'gain' ? 'selected' : ''}>💪 Muscle Gain & Size (Calorie Surplus)</option>
                  <option value="maintain" ${profile.goal === 'maintain' ? 'selected' : ''}>🌿 Weight Management (Healthy Maintenance)</option>
                </select>
              </div>

              <div class="input-group">
                <label class="input-label" for="edit-activity">Activity Level</label>
                <select id="edit-activity" class="input-field">
                  <option value="sedentary" ${profile.activityLevel === 'sedentary' ? 'selected' : ''}>Sedentary (Little exercise)</option>
                  <option value="light" ${profile.activityLevel === 'light' ? 'selected' : ''}>Light (1-3 workouts/week)</option>
                  <option value="moderate" ${profile.activityLevel === 'moderate' ? 'selected' : ''}>Moderate (3-5 workouts/week)</option>
                  <option value="active" ${profile.activityLevel === 'active' ? 'selected' : ''}>Very Active (6-7 intense sessions)</option>
                </select>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="input-group">
                  <label class="input-label" for="edit-diet">Dietary Habit</label>
                  <select id="edit-diet" class="input-field">
                    <option value="veg" ${profile.dietPref === 'veg' ? 'selected' : ''}>Vegetarian</option>
                    <option value="nonveg" ${profile.dietPref === 'nonveg' ? 'selected' : ''}>Non-Vegetarian</option>
                  </select>
                </div>
                <div class="input-group">
                  <label class="input-label" for="edit-level">Fitness Experience</label>
                  <select id="edit-level" class="input-field">
                    <option value="beginner" ${profile.fitnessLevel === 'beginner' ? 'selected' : ''}>Beginner</option>
                    <option value="intermediate" ${profile.fitnessLevel === 'intermediate' ? 'selected' : ''}>Intermediate</option>
                    <option value="advanced" ${profile.fitnessLevel === 'advanced' ? 'selected' : ''}>Advanced</option>
                  </select>
                </div>
              </div>

              <div style="display: flex; gap: 10px; margin-top: 16px;">
                <button type="button" class="btn btn-secondary" style="flex: 1;" onclick="window.FitPic.Views.ProfileView.closeEditModal()">
                  Cancel
                </button>
                <button type="submit" class="btn btn-primary" style="flex: 2;">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      `;
    }
  }

  window.FitPic.Views.ProfileView = new ProfileView();
})();
