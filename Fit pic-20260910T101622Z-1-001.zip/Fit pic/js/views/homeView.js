/**
 * FIT PIC — HOME DASHBOARD VIEW
 * Complete overview connecting Profile, User Avatar, Diet, Dumbbell Workouts,
 * AI Analysis, Weight Loss Tracking, and Coaches Maya & Shannu.
 */
window.FitPic = window.FitPic || {};
window.FitPic.Views = window.FitPic.Views || {};

(function() {
  function getGreeting() {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  }

  const MOTIVATIONAL_TIPS = [
    "“Small daily improvements over time lead to stunning results. Stay consistent!”",
    "“Fuel your brain and body. Proper nutrition turns hard study hours into high energy.”",
    "“Consistency over perfection. Even a 20-minute dumbbell session beats zero workout!”",
    "“Hydrate, lift with good technique, and rest well. Your future self is thanking you!”"
  ];

  class HomeView {
    constructor() {
      this.container = null;
    }

    init(containerEl) {
      this.container = containerEl;
      this.render();
      window.FitPic.State.subscribe("profileUpdate", () => this.render());
      window.FitPic.State.subscribe("workoutProgressUpdate", () => this.render());
      window.FitPic.State.subscribe("goalChange", () => this.render());
      window.FitPic.State.subscribe("profileAvatarUpdate", () => this.render());
    }

    selectCoachAndChat(coachId) {
      window.FitPic.State.setSelectedCoach(coachId);
      window.FitPic.App.navigate("coach");
    }

    render() {
      if (!this.container) return;

      const state = window.FitPic.State.getState();
      const profile = state.profile;
      const todayIndex = state.selectedDayIndex;
      const dayMeal = window.FitPic.DietService.generateDayMealPlan(profile, todayIndex);
      const dayWorkout = window.FitPic.WorkoutService.getDayWorkout(profile, todayIndex);
      const completedCount = Object.values(state.workoutProgress).filter(Boolean).length;
      const completedToday = !!state.workoutProgress[todayIndex];
      const icons = window.FitPic.Icons;
      const randomTip = MOTIVATIONAL_TIPS[todayIndex % MOTIVATIONAL_TIPS.length];
      const isWeightLoss = profile.goal === "lose";

      this.container.innerHTML = `
        <!-- Floating Dumbbell Decorative Background -->
        <div class="bg-floating-dumbbell" style="top: 80px; right: 18px;">
          ${icons.dumbbell(28, "#5EBE1A")}
        </div>

        <!-- Greeting & Profile Avatar Card -->
        <div class="card card-gradient-green" style="margin-bottom: 18px; position: relative;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="flex: 1; padding-right: 12px;">
              <p style="font-size: 13px; font-weight: 700; color: var(--color-primary-deep); margin-bottom: 2px; text-transform: uppercase; letter-spacing: 0.05em;">
                ${getGreeting()} 👋
              </p>
              <h1 class="font-heading" style="font-size: 23px; line-height: 1.2; margin: 0 0 6px; color: #11161B;">
                ${profile.name || "Student Athlete"}
              </h1>
              <div style="display: flex; flex-wrap: wrap; gap: 6px; align-items: center;">
                <span class="chip chip-blue" style="font-size: 11px;">
                  ${icons.target(12, "#5EBE1A")} ${dayMeal.targets.goalObj.label}
                </span>
                ${isWeightLoss ? `
                  <span class="chip chip-green" style="font-size: 11px;">
                    ${icons.flame(12, "var(--color-primary-deep)")} -450 kcal Deficit
                  </span>
                ` : ''}
              </div>
            </div>

            <!-- Clickable User Profile Avatar -->
            <div onclick="window.FitPic.App.navigate('profile')" style="cursor: pointer; position: relative;" title="Manage Profile & Photo">
              ${icons.userAvatar(56, profile.avatar, true)}
              <div style="position: absolute; bottom: -2px; right: -2px; width: 18px; height: 18px; border-radius: 50%; background: #5EBE1A; border: 2px solid #FFFFFF; display: flex; align-items: center; justify-content: center;">
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                </svg>
              </div>
            </div>
          </div>

          <!-- Quick Metrics Bar -->
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-top: 16px;">
            <div style="background: #FFFFFF; border-radius: var(--radius-md); padding: 10px 12px; border: 1px solid var(--border-light); text-align: center; box-shadow: var(--shadow-xs);">
              <p style="font-size: 10px; font-weight: 700; color: var(--text-muted); margin-bottom: 2px; text-transform: uppercase;">Workouts</p>
              <p class="font-heading" style="font-size: 17px; margin: 0; color: #11161B;">${completedCount}/7 done</p>
            </div>
            <div style="background: #FFFFFF; border-radius: var(--radius-md); padding: 10px 12px; border: 1px solid var(--border-light); text-align: center; box-shadow: var(--shadow-xs);">
              <p style="font-size: 10px; font-weight: 700; color: var(--text-muted); margin-bottom: 2px; text-transform: uppercase;">Daily Fuel</p>
              <p class="font-heading" style="font-size: 17px; margin: 0; color: #5EBE1A;">${dayMeal.targets.targetCalories} kcal</p>
            </div>
            <div style="background: #FFFFFF; border-radius: var(--radius-md); padding: 10px 12px; border: 1px solid var(--border-light); text-align: center; box-shadow: var(--shadow-xs);">
              <p style="font-size: 10px; font-weight: 700; color: var(--text-muted); margin-bottom: 2px; text-transform: uppercase;">Streak</p>
              <p class="font-heading" style="font-size: 17px; margin: 0; color: #5EBE1A;">${state.streakDays} days 🔥</p>
            </div>
          </div>
        </div>

        <!-- DEDICATED WEIGHT LOSS TRACKER WIDGET (When Goal is Weight Loss) -->
        ${isWeightLoss ? `
          <div class="weight-loss-widget">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 18px;">🔥</span>
                <div>
                  <h4 class="font-heading" style="font-size: 15px; margin: 0; color: #FFFFFF;">Weight Loss & Fat Burn Target</h4>
                  <p style="font-size: 11px; color: #A8C4A0; margin: 0;">Target Deficit: 450 kcal/day</p>
                </div>
              </div>
              <span class="chip chip-green" style="font-size: 10.5px;">Active Cut</span>
            </div>
            <div class="deficit-bar-bg">
              <div class="deficit-bar-fill" style="width: 72%;"></div>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 11.5px; color: #C0D6BC; margin-top: 4px;">
              <span>Current: <strong>${profile.weight} kg</strong></span>
              <span>Target: <strong>${profile.targetWeight || 65} kg</strong></span>
              <span style="color: #5EBE1A; font-weight: 700;">-7 kg to go</span>
            </div>
          </div>
        ` : ''}

        <!-- FEATURED DUAL COACHES SHOWCASE (MAYA & SHANNU) -->
        <div class="home-coaches-card">
          <div class="home-coaches-header">
            <div>
              <span style="font-size: 10.5px; font-weight: 800; color: #5EBE1A; text-transform: uppercase; letter-spacing: 0.08em; display: flex; align-items: center; gap: 4px;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#5EBE1A" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
                AI Smart Coaches
              </span>
              <h3 class="font-heading" style="font-size: 18px; margin: 2px 0 0; color: #FFFFFF;">Meet Maya & Shannu</h3>
            </div>
            <button class="btn btn-sm btn-primary" onclick="window.FitPic.App.navigate('coach')" style="font-size: 11.5px; padding: 6px 12px; border-radius: var(--radius-full);">
              Open Chat Room ${icons.chevronRight(12, "#FFFFFF")}
            </button>
          </div>

          <div class="home-coaches-grid">
            <!-- Coach Maya Column -->
            <div class="home-coach-column" onclick="window.FitPic.Views.HomeView.selectCoachAndChat('maya')">
              <div class="home-coach-img-box">
                <img src="assets/maya.png" alt="Coach Maya">
              </div>
              <div class="home-coach-name">Coach Maya</div>
              <div class="home-coach-role">Nutrition & Fat Loss</div>
              <p style="font-size: 10.5px; color: #C6D3BF; margin: 6px 0 0; line-height: 1.3;">
                “Mindful nutrition & steady fat loss wins the long race!”
              </p>
              <button class="btn btn-sm btn-secondary" style="margin-top: 8px; font-size: 10.5px; padding: 4px 10px; width: 100%;">
                Ask Maya 🌿
              </button>
            </div>

            <!-- Coach Shannu Column -->
            <div class="home-coach-column" onclick="window.FitPic.Views.HomeView.selectCoachAndChat('shannu')">
              <div class="home-coach-img-box">
                <img src="assets/shannu.png" alt="Coach Shannu">
              </div>
              <div class="home-coach-name">Coach Shannu</div>
              <div class="home-coach-role">Strength & Dumbbells</div>
              <p style="font-size: 10.5px; color: #C6D3BF; margin: 6px 0 0; line-height: 1.3;">
                “Lock in strict dumbbell form and crush every single rep!”
              </p>
              <button class="btn btn-sm btn-secondary" style="margin-top: 8px; font-size: 10.5px; padding: 4px 10px; width: 100%;">
                Ask Shannu 💪
              </button>
            </div>
          </div>
        </div>

        <!-- HERO FEATURE: AI ANALYSIS CALL TO ACTION -->
        <div class="hero-ai-banner" onclick="window.FitPic.App.navigate('analysis')" style="cursor: pointer;">
          <div class="hero-ai-tag">
            ${icons.sparkles(13, "#5EBE1A")} AI Hero Feature
          </div>
          <h2 class="hero-ai-title">AI Workout & Form Analysis</h2>
          <p class="hero-ai-desc">
            Use your camera, upload exercise footage, or paste a video URL to get automated real-time biomechanics feedback and rep counts.
          </p>
          <button class="btn btn-primary" style="padding: 10px 18px; font-size: 13.5px; border-radius: var(--radius-full); pointer-events: none;">
            ${icons.camera(16, "#FFFFFF")} Launch AI Analysis ${icons.chevronRight(14, "#FFFFFF")}
          </button>
        </div>

        <!-- Today's Workout Preview Card with Dumbbell Visuals -->
        <div class="card" style="margin-bottom: 14px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <div style="width: 38px; height: 38px; border-radius: var(--radius-md); background: #11161B; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 10px rgba(94, 190, 26, 0.4); border: 1.5px solid #5EBE1A;">
                <svg class="dumbbell-pump-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#5EBE1A" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                  <path d="m6.5 6.5 11 11"></path>
                  <path d="m21 21-1-1a2 2 0 0 0-2.83 0l-1.17 1.17a2 2 0 0 1-2.83 0L3.17 11.17a2 2 0 0 1 0-2.83L4.34 7.17a2 2 0 0 0 0-2.83L3.34 3.34a2 2 0 0 1 2.83 0l1 1a2 2 0 0 0 2.83 0l1.17-1.17a2 2 0 0 1 2.83 0l10 10a2 2 0 0 1 0 2.83l-1.17 1.17a2 2 0 0 0 0 2.83Z"></path>
                </svg>
              </div>
              <div>
                <span style="font-size: 11px; font-weight: 800; color: #5EBE1A; text-transform: uppercase; letter-spacing: 0.05em;">Today's Workout</span>
                <h3 class="font-heading" style="font-size: 16px; margin: 0; color: #11161B;">${dayWorkout.focus}</h3>
              </div>
            </div>
            ${completedToday 
              ? `<span class="chip chip-green">${icons.check(11, "var(--color-primary-deep)")} Completed</span>` 
              : `<span class="chip chip-blue">${dayWorkout.durationMinutes} min</span>`
            }
          </div>

          <p style="font-size: 12.5px; color: var(--text-secondary); margin-bottom: 12px; line-height: 1.4;">
            ${dayWorkout.isRest 
              ? "Active recovery day. Take a relaxing walk or do gentle mobility to rebuild your body."
              : `${dayWorkout.exercises.length} dumbbell & bodyweight movements scheduled • Warm-up & cool-down included`}
          </p>

          <button class="btn btn-secondary btn-block" style="font-size: 13px; padding: 10px;" onclick="window.FitPic.App.navigate('workout')">
            Open Dumbbell Workout Routine ${icons.chevronRight(14, "var(--text-secondary)")}
          </button>
        </div>

        <!-- Today's Meal Preview Card -->
        <div class="card" style="margin-bottom: 14px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <div style="width: 36px; height: 36px; border-radius: var(--radius-md); background: var(--color-primary-soft); display: flex; align-items: center; justify-content: center; color: var(--color-primary-deep);">
                ${icons.utensils(18, "var(--color-primary-deep)")}
              </div>
              <div>
                <span style="font-size: 11px; font-weight: 800; color: var(--color-primary-deep); text-transform: uppercase; letter-spacing: 0.05em;">Featured Meal (Lunch)</span>
                <h3 class="font-heading" style="font-size: 15px; margin: 0;">${dayMeal.meals.lunch.name}</h3>
              </div>
            </div>
            <span class="chip chip-green">${dayMeal.meals.lunch.kcal} kcal</span>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary); background: var(--bg-surface-secondary); padding: 8px 12px; border-radius: var(--radius-sm); margin-bottom: 12px;">
            <span>Protein: <strong>${dayMeal.meals.lunch.protein}g</strong></span>
            <span>Carbs: <strong>${dayMeal.meals.lunch.carbs}g</strong></span>
            <span>Fat: <strong>${dayMeal.meals.lunch.fat}g</strong></span>
          </div>

          <button class="btn btn-secondary btn-block" style="font-size: 13px; padding: 10px;" onclick="window.FitPic.App.navigate('diet')">
            View Full 7-Day Diet Plan ${icons.chevronRight(14, "var(--text-secondary)")}
          </button>
        </div>

        <!-- Student Motivational Quote -->
        <div style="padding: 12px 14px; background: var(--bg-surface-secondary); border-radius: var(--radius-md); text-align: center; border: 1px solid var(--border-light);">
          <p style="font-size: 12.5px; font-style: italic; color: var(--text-secondary); margin: 0;">
            ${randomTip}
          </p>
        </div>
      `;
    }
  }

  window.FitPic.Views.HomeView = new HomeView();
})();
