/**
 * FIT PIC — WORKOUT VIEW
 * Displays 7-day personalized dumbbell workout schedule synced with Profile and Diet goals.
 * Includes interactive exercise check-offs, warm-up/cool-down routines, dumbbell cues, and weekly progress.
 */
window.FitPic = window.FitPic || {};
window.FitPic.Views = window.FitPic.Views || {};

(function() {
  const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  class WorkoutView {
    constructor() {
      this.container = null;
    }

    init(containerEl) {
      this.container = containerEl;
      this.render();
      window.FitPic.State.subscribe("profileUpdate", () => this.render());
      window.FitPic.State.subscribe("dayChange", () => this.render());
      window.FitPic.State.subscribe("workoutProgressUpdate", () => this.render());
      window.FitPic.State.subscribe("exerciseCheckUpdate", () => this.render());
    }

    render() {
      if (!this.container) return;

      const state = window.FitPic.State.getState();
      const profile = state.profile;
      const todayIndex = state.selectedDayIndex;
      const workoutService = window.FitPic.WorkoutService;
      const icons = window.FitPic.Icons;

      const weekProgram = workoutService.getWorkoutPlan(profile);
      const currentDay = weekProgram[todayIndex];
      const completedToday = !!state.workoutProgress[todayIndex];
      const completedCount = Object.values(state.workoutProgress).filter(Boolean).length;
      const completionPercent = Math.round((completedCount / 7) * 100);

      this.container.innerHTML = `
        <div class="section-header">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h2 class="section-title">Dumbbell Workout Routine</h2>
              <p class="section-desc">Synced with your <strong>${profile.goal.toUpperCase()}</strong> goal. Switch goals in Diet anytime.</p>
            </div>
            <span class="dumbbell-badge">
              <svg class="dumbbell-pump-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5EBE1A" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                <path d="m6.5 6.5 11 11"></path>
                <path d="m21 21-1-1a2 2 0 0 0-2.83 0l-1.17 1.17a2 2 0 0 1-2.83 0L3.17 11.17a2 2 0 0 1 0-2.83L4.34 7.17a2 2 0 0 0 0-2.83L3.34 3.34a2 2 0 0 1 2.83 0l1 1a2 2 0 0 0 2.83 0l1.17-1.17a2 2 0 0 1 2.83 0l10 10a2 2 0 0 1 0 2.83l-1.17 1.17a2 2 0 0 0 0 2.83Z"></path>
              </svg>
              Dumbbell Routine
            </span>
          </div>
        </div>

        <!-- Weekly Progress Card -->
        <div class="card card-gradient-green" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <div>
              <span style="font-size: 11px; font-weight: 700; color: var(--color-primary-deep); text-transform: uppercase;">Weekly Consistency</span>
              <h3 class="font-heading" style="font-size: 20px; margin: 2px 0 0; color: #11161B;">${completedCount} of 7 Workouts Completed</h3>
            </div>
            <span class="chip chip-green">${completionPercent}% Done</span>
          </div>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill green" style="width: ${completionPercent}%;"></div>
          </div>
          <p style="font-size: 11.5px; color: var(--text-secondary); margin: 6px 0 0;">
            ${completedCount >= 4 ? "🔥 Excellent momentum! Keep pushing through the rest of the week." : "Consistency is king. Complete each session at your own pace."}
          </p>
        </div>

        <!-- 7-Day Day Selector Strip -->
        <div style="margin-bottom: 14px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-size: 12px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Weekly Schedule</span>
            <div style="display: flex; align-items: center; gap: 4px;">
              <span style="font-size: 11px; color: var(--text-muted);">Fitness Level:</span>
              <select class="input-field" style="width: auto; padding: 4px 26px 4px 8px; font-size: 11px; border-radius: var(--radius-sm);"
                      onchange="window.FitPic.State.updateProfile({ fitnessLevel: this.value })">
                <option value="beginner" ${profile.fitnessLevel === 'beginner' ? 'selected' : ''}>Beginner</option>
                <option value="intermediate" ${profile.fitnessLevel === 'intermediate' ? 'selected' : ''}>Intermediate</option>
                <option value="advanced" ${profile.fitnessLevel === 'advanced' ? 'selected' : ''}>Advanced</option>
              </select>
            </div>
          </div>

          <div class="day-selector-strip">
            ${weekProgram.map((day, idx) => {
              const isDone = !!state.workoutProgress[idx];
              const isSelected = idx === todayIndex;
              return `
                <button onclick="window.FitPic.State.setSelectedDay(${idx})"
                        class="day-pill ${isSelected ? 'active' : ''} ${isDone ? 'completed' : ''}">
                  <span class="day-pill-name">${day.dayName.slice(0, 3)}</span>
                  <span class="day-pill-status">
                    ${isDone ? icons.check(11, '#FFFFFF') : (idx + 1)}
                  </span>
                </button>
              `;
            }).join("")}
          </div>
        </div>

        <!-- Today's Session Card -->
        <div class="card" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
            <div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span class="chip chip-blue" style="font-size: 10.5px;">${DAY_NAMES[todayIndex]}</span>
                ${currentDay.isRest ? `<span class="chip chip-green">Recovery Day</span>` : `<span class="chip chip-green">${currentDay.intensity}</span>`}
              </div>
              <h3 class="font-heading" style="font-size: 18px; margin: 6px 0 2px; color: #11161B;">${currentDay.focus}</h3>
            </div>
            ${!currentDay.isRest ? `
              <div style="display: flex; align-items: center; gap: 4px; font-size: 12.5px; font-weight: 700; color: #11161B; background: var(--color-primary-soft); padding: 5px 10px; border-radius: var(--radius-full); border: 1px solid var(--color-primary-light);">
                ${icons.clock(13, "var(--color-primary-deep)")} ${currentDay.durationMinutes} min
              </div>
            ` : ''}
          </div>

          <!-- Mark Today Complete Button -->
          <button onclick="window.FitPic.State.toggleWorkoutCompletion(${todayIndex})"
                  class="btn ${completedToday ? 'btn-green' : 'btn-primary'} btn-block"
                  style="margin-bottom: 16px; padding: 12px;">
            ${completedToday 
              ? `${icons.checkCircle(18, "#FFFFFF")} Workout Marked Complete! (Tap to undo)`
              : `<span class="animated-dumbbell-wrapper" style="margin-right:6px;">${icons.dumbbell(18, "#FFFFFF")}</span> Mark Today's Workout Complete`}
          </button>

          <!-- Quick Coach Help Bar -->
          <div style="display: flex; gap: 8px; margin-bottom: 14px;">
            <button class="btn btn-sm btn-secondary" style="flex: 1; font-size: 11.5px; padding: 7px;" onclick="window.FitPic.Views.CoachView.switchCoach('shannu'); window.FitPic.App.navigate('coach');">
              Ask Shannu Form Tip 💪
            </button>
            <button class="btn btn-sm btn-secondary" style="flex: 1; font-size: 11.5px; padding: 7px;" onclick="window.FitPic.Views.CoachView.switchCoach('maya'); window.FitPic.App.navigate('coach');">
              Ask Maya Recovery 🌿
            </button>
          </div>

          ${currentDay.isRest ? `
            <div style="background: var(--color-primary-soft); border: 1px solid var(--color-primary-light); border-radius: var(--radius-md); padding: 14px; margin-bottom: 14px;">
              <h4 class="font-heading" style="font-size: 14px; color: var(--color-primary-deep); margin: 0 0 4px;">Active Recovery Guidance</h4>
              <p style="font-size: 12.5px; color: var(--text-secondary); line-height: 1.5; margin: 0;">
                Recovery days allow micro-tears in muscle fibers to synthesize into denser muscle tissue. Prioritize light mobility, deep breathing, adequate protein intake, and 7-8 hours of sleep.
              </p>
            </div>
          ` : ''}

          <!-- Warm-up Accordion -->
          ${currentDay.warmup && currentDay.warmup.length > 0 ? `
            <div style="margin-bottom: 14px; background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md);">
              <span style="font-size: 11.5px; font-weight: 700; color: var(--text-primary); text-transform: uppercase; display: block; margin-bottom: 6px;">
                🔥 Warm-Up Sequence (3-4 mins)
              </span>
              <ul style="margin: 0; padding-left: 18px; font-size: 12px; color: var(--text-secondary);">
                ${currentDay.warmup.map(w => `<li style="margin-bottom: 3px;">${w}</li>`).join("")}
              </ul>
            </div>
          ` : ''}

          <!-- Main Exercises Checklist with Dumbbells -->
          <span style="display: block; font-size: 12px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 8px;">
            Main Exercises Checklist
          </span>
          <div style="display: flex; flex-direction: column; gap: 10px;">
            ${currentDay.exercises.map((ex, exIdx) => {
              const checkKey = `${todayIndex}-${exIdx}`;
              const isChecked = !!state.exerciseChecks[checkKey];
              return `
                <div style="padding: 12px; border-radius: var(--radius-md); border: 1.5px solid ${isChecked ? 'var(--color-primary)' : 'var(--border-light)'}; background: ${isChecked ? 'var(--color-primary-soft)' : '#FFFFFF'}; transition: all var(--trans-fast);">
                  <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <div style="display: flex; gap: 10px; align-items: flex-start; flex: 1;">
                      <button onclick="window.FitPic.State.toggleExerciseCheck(${todayIndex}, ${exIdx})"
                              style="width: 24px; height: 24px; border-radius: 6px; border: 2px solid ${isChecked ? 'var(--color-primary)' : 'var(--border-subtle)'}; background: ${isChecked ? 'var(--color-primary)' : '#FFFFFF'}; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px;">
                        ${isChecked ? icons.check(14, '#FFFFFF') : ''}
                      </button>
                      <div>
                        <h4 class="font-heading" style="font-size: 14.5px; margin: 0; text-decoration: ${isChecked ? 'line-through' : 'none'}; color: ${isChecked ? 'var(--color-primary-deep)' : 'var(--text-primary)'};">
                          ${ex.name}
                        </h4>
                        <div style="display: flex; gap: 8px; font-size: 11.5px; color: var(--text-secondary); margin-top: 4px;">
                          <span><strong>${ex.sets}</strong></span>
                          <span>•</span>
                          <span><strong>${ex.reps}</strong></span>
                          <span>•</span>
                          <span>Rest: ${ex.rest}</span>
                        </div>
                      </div>
                    </div>
                    <span class="chip ${ex.difficulty === 'High Burn' || ex.difficulty === 'Challenging' ? 'chip-blue' : 'chip-green'}" style="font-size: 10px;">
                      ${ex.difficulty}
                    </span>
                  </div>

                  <!-- Exercise Tip -->
                  <div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--border-light); font-size: 11.5px; color: var(--text-secondary); display: flex; align-items: flex-start; gap: 6px;">
                    <span style="color: var(--color-primary); flex-shrink: 0;">💡</span>
                    <span><strong>Coach Tip:</strong> ${ex.tip}</span>
                  </div>
                </div>
              `;
            }).join("")}
          </div>

          <!-- Cool-down -->
          ${currentDay.cooldown && currentDay.cooldown.length > 0 ? `
            <div style="margin-top: 14px; background: var(--bg-surface-secondary); padding: 10px 12px; border-radius: var(--radius-md);">
              <span style="font-size: 11.5px; font-weight: 700; color: var(--text-primary); text-transform: uppercase; display: block; margin-bottom: 6px;">
                ❄️ Cool-down & Joint Mobility (2-3 mins)
              </span>
              <ul style="margin: 0; padding-left: 18px; font-size: 12px; color: var(--text-secondary);">
                ${currentDay.cooldown.map(c => `<li style="margin-bottom: 3px;">${c}</li>`).join("")}
              </ul>
            </div>
          ` : ''}
        </div>
      `;
    }
  }

  window.FitPic.Views.WorkoutView = new WorkoutView();
})();
