/**
 * FIT PIC — AI ANALYSIS SERVICE (HERO DIFFERENTIATING FEATURE)
 * Handles Camera Input (live stream, permissions, fallbacks), Media Upload,
 * and Social Media / Video Link Analysis. Features multi-stage computer vision
 * pipeline simulation and detailed biomechanical reports.
 */
window.FitPic = window.FitPic || {};

(function() {
  // Realistic exercise knowledge bases for mock & vision pipeline
  const EXERCISE_ANALYSIS_MODELS = {
    squat: {
      exerciseName: "Deep Bodyweight / Goblet Squat",
      primaryMuscles: "Quadriceps, Glutes, Core Stabilizers",
      repsDetected: 12,
      cleanReps: 10,
      cadenceSec: "2.8s / rep",
      depthAngle: "96° (Below parallel - Excellent)",
      spineNeutrality: "92% Neutral alignment maintained",
      kneeTracking: "Good lateral stability (minor inward drift on reps 11-12)",
      intensityRPE: "RPE 8.0 / Challenging",
      caloriesBurnedEst: "48 kcal",
      keyObservations: "Consistent hip-hinge initiation with strong heel contact throughout the eccentric phase. Depth consistently achieved past 90 degrees with active core bracing.",
      safetyTips: [
        "Maintain chest angle high: avoid excessive forward torso flexion when ascending from the bottom.",
        "Push knees outward over toes to avoid knee valgus during fatigue on final reps.",
        "Ensure steady inhalation on descent and explosive exhalation through pursed lips on ascent."
      ],
      improvementAreas: [
        "Add a 1-second pause at maximum depth on your first 4 repetitions to build eccentric glute control.",
        "Work on ankle dorsiflexion mobility before squatting to optimize upright posture."
      ],
      confidence: 94,
      dataQuality: "Optimal (High frame clarity, clear joint visibility)"
    },

    pushup: {
      exerciseName: "Standard Strict Push-up",
      primaryMuscles: "Pectoralis Major, Anterior Deltoids, Triceps, Core",
      repsDetected: 14,
      cleanReps: 13,
      cadenceSec: "2.2s / rep",
      depthAngle: "45° Elbow flexion (Chest 2 inches from floor)",
      spineNeutrality: "96% Strict plank line preserved",
      kneeTracking: "N/A (Rigid lower body tension)",
      intensityRPE: "RPE 7.5 / Moderate-High",
      caloriesBurnedEst: "36 kcal",
      keyObservations: "Outstanding core stiffness with zero lumbar sagging. Elbows properly tucked at approximately 45 degrees, protecting rotator cuffs and maximizing pectoral contraction.",
      safetyTips: [
        "Maintain neutral cervical spine: gaze approximately 8 inches ahead of hands rather than looking straight down.",
        "Spread fingers wide and grip floor to distribute wrist loading evenly.",
        "Avoid shrugging shoulders toward ears; keep scapula depressed."
      ],
      improvementAreas: [
        "Slow down eccentric lowering to a 3-second tempo to trigger deeper mechanical hypertrophy.",
        "Elevate feet on a 6-inch step for advanced upper-chest progression."
      ],
      confidence: 96,
      dataQuality: "Optimal (Clear sagittal angle and lighting)"
    },

    deadlift: {
      exerciseName: "Dumbbell / Barbell Romanian Deadlift",
      primaryMuscles: "Hamstrings, Gluteus Maximus, Erector Spinae",
      repsDetected: 10,
      cleanReps: 9,
      cadenceSec: "3.2s / rep",
      depthAngle: "Mid-shin hinge with soft knees",
      spineNeutrality: "94% Neutral spinal curve maintained",
      kneeTracking: "Vertical shins preserved",
      intensityRPE: "RPE 8.5 / High",
      caloriesBurnedEst: "52 kcal",
      keyObservations: "Superb hip-hinge execution with hips driving rearward. Bar path traveled vertically close to shins, eliminating excessive shear force on lumbar discs.",
      safetyTips: [
        "Keep lats engaged like squeezing an orange in your armpits to prevent thoracic rounding.",
        "Drive through the mid-foot and squeeze glutes forward at lockout without leaning back.",
        "Never jerk weight off the floor; maintain smooth tension throughout."
      ],
      improvementAreas: [
        "Pause for half a second at bottom stretch to maximize hamstring eccentric elongation.",
        "Consider using lifting straps or chalk if grip fatigue limits posterior loading."
      ],
      confidence: 93,
      dataQuality: "Good (Consistent lateral camera perspective)"
    },

    hiit: {
      exerciseName: "Dynamic Functional HIIT Circuit",
      primaryMuscles: "Cardiovascular, Deltoids, Core, Quadriceps",
      repsDetected: 28,
      cleanReps: 26,
      cadenceSec: "High tempo (1.4s / cycle)",
      depthAngle: "Dynamic multi-planar range",
      spineNeutrality: "88% Athletic ready posture",
      kneeTracking: "Soft knee landings observed",
      intensityRPE: "RPE 9.0 / High Aerobic",
      caloriesBurnedEst: "74 kcal",
      keyObservations: "High explosive power output with quick ground-contact time. Heart rate elevated into aerobic zone with consistent pacing across rounds.",
      safetyTips: [
        "Land softly on the balls of your feet to cushion joint impact.",
        "Control breathing rhythm: synchronize exhales with the concentric power phase.",
        "Stay hydrated: sip water with electrolytes between intervals."
      ],
      improvementAreas: [
        "Maintain equal knee flexion on lateral transitions.",
        "Deepen breath intake between rounds to speed up heart rate recovery."
      ],
      confidence: 91,
      dataQuality: "Good (Rapid multi-directional movement tracked)"
    }
  };

  class AIService {
    constructor() {
      this.stream = null;
    }

    // Camera Stream Management
    async startCamera(videoEl) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Device camera API not supported in this browser environment.");
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
          audio: false
        });
        this.stream = stream;
        if (videoEl) {
          videoEl.srcObject = stream;
          await videoEl.play().catch(() => {});
        }
        return stream;
      } catch (err) {
        console.warn("Camera access failed or denied:", err);
        throw err;
      }
    }

    stopCamera() {
      if (this.stream) {
        this.stream.getTracks().forEach(track => track.stop());
        this.stream = null;
      }
    }

    captureFrame(videoEl, canvasEl) {
      if (!videoEl || !canvasEl) return null;
      const ctx = canvasEl.getContext("2d");
      canvasEl.width = videoEl.videoWidth || 480;
      canvasEl.height = videoEl.videoHeight || 360;
      ctx.drawImage(videoEl, 0, 0, canvasEl.width, canvasEl.height);
      return canvasEl.toDataURL("image/jpeg", 0.85);
    }

    // Sample video URL presets
    getSampleVideoLinks() {
      return [
        {
          title: "Squat Depth & Form Check",
          platform: "YouTube",
          url: "https://www.youtube.com/watch?v=bEv6CCg2BC8",
          type: "squat",
          desc: "Perfect technique analysis for barbell/bodyweight squats"
        },
        {
          title: "Strict Push-Up Biomechanics",
          platform: "Instagram Reels",
          url: "https://www.instagram.com/reel/pushup_mastery_demo",
          type: "pushup",
          desc: "Torso alignment and elbow angle evaluation"
        },
        {
          title: "Romanian Deadlift Posterior Chain",
          platform: "TikTok",
          url: "https://www.tiktok.com/@fitness/video/deadlift_technique",
          type: "deadlift",
          desc: "Hamstring hinge and spine neutrality check"
        },
        {
          title: "HIIT & Conditioning Circuit",
          platform: "Vimeo / MP4",
          url: "https://vimeo.com/workout_hiit_sample",
          type: "hiit",
          desc: "Cadence, repetition tempo and intensity estimation"
        }
      ];
    }

    detectExerciseTypeFromInput(inputStr) {
      const lower = (inputStr || "").toLowerCase();
      if (lower.includes("push") || lower.includes("chest") || lower.includes("bench")) return "pushup";
      if (lower.includes("deadlift") || lower.includes("rdl") || lower.includes("hamstring")) return "deadlift";
      if (lower.includes("hiit") || lower.includes("cardio") || lower.includes("burpee")) return "hiit";
      return "squat"; // default
    }

    /**
     * Executes the multi-stage AI scanning simulation
     * onStepCallback(stepNumber, totalSteps, stepMessage)
     */
    async runAnalysisPipeline(inputSource, onStepCallback) {
      const steps = [
        { num: 1, text: "Initializing Fit Pic Neural Vision Engine & pose detector..." },
        { num: 2, text: "Tracking 33 skeletal landmarks (shoulders, hips, knees, ankles)..." },
        { num: 3, text: "Measuring joint angles, bar trajectory & range of motion (ROM)..." },
        { num: 4, text: "Calculating repetition cadence, tempo & sticking-point zones..." },
        { num: 5, text: "Synthesizing posture, safety & customized nutrition recommendations..." }
      ];

      for (let i = 0; i < steps.length; i++) {
        if (onStepCallback) {
          onStepCallback(steps[i].num, steps.length, steps[i].text);
        }
        // Realistic processing timing
        await new Promise(resolve => setTimeout(resolve, 550));
      }

      // Generate context-aware report
      const modelKey = this.detectExerciseTypeFromInput(inputSource.label || inputSource.url || inputSource.filename || "squat");
      const model = EXERCISE_ANALYSIS_MODELS[modelKey] || EXERCISE_ANALYSIS_MODELS.squat;

      const profile = window.FitPic.State.getProfile();
      const dietTargets = window.FitPic.DietService.calculateTargets(profile);

      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

      return {
        id: "analysis_" + Date.now(),
        timestamp: `${dateStr} at ${timestamp}`,
        inputMethod: inputSource.type, // 'camera', 'upload', 'link'
        inputSourceLabel: inputSource.label || inputSource.filename || inputSource.url || "Live Workout Stream",
        exerciseName: model.exerciseName,
        primaryMuscles: model.primaryMuscles,
        repsDetected: model.repsDetected,
        cleanReps: model.cleanReps,
        cadenceSec: model.cadenceSec,
        depthAngle: model.depthAngle,
        spineNeutrality: model.spineNeutrality,
        kneeTracking: model.kneeTracking,
        intensityRPE: model.intensityRPE,
        caloriesBurnedEst: model.caloriesBurnedEst,
        keyObservations: model.keyObservations,
        safetyTips: model.safetyTips,
        improvementAreas: model.improvementAreas,
        confidence: model.confidence,
        dataQuality: model.dataQuality,
        suggestedGoal: profile.goal === "recomp" ? "Body Recomposition" : profile.goal === "gain" ? "Weight Gain" : "Weight Management",
        dietRecommendations: [
          `Post-workout window: Target ~${Math.round(profile.weight * 0.35)}g of high-quality protein (paneer bhurji, boiled eggs, or Greek yogurt/sprouts) within 90 minutes.`,
          `Daily target reminder: Aim for ${dietTargets.targetCalories} kcal and ${dietTargets.proteinGrams}g protein to match this training stimulus.`,
          "Electrolyte balance: Drink at least 500ml water infused with a pinch of rock salt and lemon after intense sets."
        ],
        workoutRecommendations: [
          `Incorporate 3 sets of ${model.exerciseName.split(" ")[0]} variations twice weekly to solidify neuromuscular patterns.`,
          `Warm-up priority: 3 minutes of targeted dynamic hip & shoulder mobility before loading heavy sets.`,
          `Progressive overload: Add 1 rep or 1.5kg weight once you can perform all sets at clean technique.`
        ],
        progressInsight: `Great execution! Your joint stability is tracking at ${model.confidence}% fidelity. Compared to your weekly schedule (${Object.values(window.FitPic.State.getState().workoutProgress).filter(Boolean).length}/7 completed), you are consistently progressing toward your ${profile.goal.toUpperCase()} milestone.`
      };
    }
  }

  window.FitPic.AIService = new AIService();
})();
