/**
 * FIT PIC — DIET & NUTRITION SERVICE
 * Calculates BMI, TDEE (inclusive of Male, Female, and Transgender), Caloric & Macronutrient targets,
 * and generates 7-day Indian-friendly meal plans including specialized Weight Loss / Fat Burn plans.
 */
window.FitPic = window.FitPic || {};

(function() {
  const GOALS = [
    {
      id: "lose",
      label: "Weight Loss & Fat Burn",
      subtitle: "Accelerate fat burn, lean definition & metabolic health",
      color: "green",
      badgeText: "Fat Loss & Cut",
      calorieDelta: -450,
      proteinMultiplier: 2.1, // High protein to preserve muscle in deficit
      carbRatio: 0.38,
      fatRatio: 0.24,
      description: "Targeted moderate caloric deficit paired with high satiety Indian proteins to melt body fat while safeguarding muscle tone."
    },
    {
      id: "recomp",
      label: "Body Recomposition",
      subtitle: "Lose fat & build athletic muscle simultaneously",
      color: "blue",
      badgeText: "Tone & Recomp",
      calorieDelta: -150,
      proteinMultiplier: 2.0,
      carbRatio: 0.45,
      fatRatio: 0.25,
      description: "Mild deficit or maintenance with elevated protein timing to shed fat while progressively packing on lean athletic muscle."
    },
    {
      id: "gain",
      label: "Muscle Gain & Size",
      subtitle: "Build lean mass, raw strength & athletic power",
      color: "orange",
      badgeText: "Size & Strength",
      calorieDelta: 350,
      proteinMultiplier: 1.8,
      carbRatio: 0.52,
      fatRatio: 0.25,
      description: "Clean caloric surplus with nutrient-dense Indian staples to fuel muscle hypertrophy and progressive dumbbell overload."
    },
    {
      id: "maintain",
      label: "Weight Management",
      subtitle: "Maintain current weight & sustain daily energy",
      color: "green",
      badgeText: "Healthy Weight",
      calorieDelta: 0,
      proteinMultiplier: 1.4,
      carbRatio: 0.50,
      fatRatio: 0.25,
      description: "Balanced daily energy intake matching your natural burn rate to preserve lean mass and support steady student study energy."
    }
  ];

  const ACTIVITY_MULTIPLIERS = {
    sedentary: { label: "Sedentary", desc: "Little to no formal exercise", mult: 1.2 },
    light: { label: "Lightly Active", desc: "1-3 light workout sessions/week", mult: 1.375 },
    moderate: { label: "Moderately Active", desc: "3-5 moderate workouts/week", mult: 1.55 },
    active: { label: "Very Active", desc: "6-7 intense workouts/week", mult: 1.725 }
  };

  const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  // Authentic, nutrient-dense Indian Food Database
  const INDIAN_FOOD_DB = {
    veg: {
      breakfast: [
        { name: "Vegetable Poha with roasted peanuts & lemon", kcal: 290, protein: 8, carbs: 48, fat: 8 },
        { name: "Moong Dal Chilla (2 pcs) with fresh mint chutney", kcal: 270, protein: 15, carbs: 38, fat: 6 },
        { name: "Steamed Idlis (3 pcs) with vegetable sambar & coconut podi", kcal: 310, protein: 9, carbs: 54, fat: 5 },
        { name: "Vegetable Upma with roasted cashews & fresh curd", kcal: 300, protein: 9, carbs: 50, fat: 7 },
        { name: "Besan Cheela with paneer stuffing & tomato relish", kcal: 330, protein: 16, carbs: 36, fat: 12 },
        { name: "Warm Oats Porridge with banana, chia seeds & almonds", kcal: 320, protein: 11, carbs: 52, fat: 8 },
        { name: "Methi Thepla (2 pcs) with spiced curd & mint chutney", kcal: 280, protein: 10, carbs: 44, fat: 7 }
      ],
      midMorning: [
        { name: "Seasonal fruit bowl (papaya, guava & pomegranate)", kcal: 95, protein: 2, carbs: 22, fat: 0 },
        { name: "Roasted Chana (1 cup) with chaat masala", kcal: 130, protein: 8, carbs: 20, fat: 2 },
        { name: "Chilled Buttermilk (chaas) with cumin & coriander", kcal: 65, protein: 3, carbs: 6, fat: 2 },
        { name: "Handful of California almonds (8) & walnuts (4)", kcal: 155, protein: 5, carbs: 6, fat: 14 },
        { name: "Sprouted Moong Chaat with lemon & pomegranate", kcal: 135, protein: 9, carbs: 22, fat: 1 },
        { name: "Fresh Tender Coconut Water with pulp", kcal: 70, protein: 1, carbs: 15, fat: 0 },
        { name: "Roasted Makhana with mild rock salt & turmeric", kcal: 110, protein: 4, carbs: 20, fat: 2 }
      ],
      lunch: [
        { name: "Steamed Basmati Rice, Yellow Dal Tadka, Mixed Veg Sabzi & Curd", kcal: 530, protein: 19, carbs: 84, fat: 12 },
        { name: "2 Multigrain Roti, Fresh Paneer Bhurji & Tomato Cucumber Salad", kcal: 540, protein: 24, carbs: 58, fat: 20 },
        { name: "Slow-cooked Rajma Masala with Jeera Rice & Onion Raita", kcal: 560, protein: 21, carbs: 88, fat: 13 },
        { name: "Amritsari Chole with 2 Whole Wheat Rotis & Kachumber Salad", kcal: 520, protein: 18, carbs: 78, fat: 14 },
        { name: "South Indian Curd Rice with Tadka & Poriyal beans", kcal: 480, protein: 14, carbs: 76, fat: 12 },
        { name: "2 Phulkas, Palak Paneer, Toor Dal & Beetroot Salad", kcal: 550, protein: 25, carbs: 62, fat: 21 },
        { name: "Vegetable Pulao with Kadhi Pakora & roasted papad", kcal: 510, protein: 16, carbs: 80, fat: 14 }
      ],
      eveningSnack: [
        { name: "Sprouts Bhel with onion, tomato & tangy tamarind dip", kcal: 145, protein: 8, carbs: 26, fat: 2 },
        { name: "Green Tea with a bowl of roasted makhana (foxnuts)", kcal: 120, protein: 4, carbs: 22, fat: 2 },
        { name: "Grilled low-fat Paneer Cubes (60g) with chaat spices", kcal: 175, protein: 14, carbs: 4, fat: 11 },
        { name: "Mixed Fruit Chaat with black salt & lemon juice", kcal: 105, protein: 2, carbs: 24, fat: 0 },
        { name: "Boiled sweet corn with lemon and black pepper", kcal: 130, protein: 4, carbs: 27, fat: 1 },
        { name: "Roasted peanuts (handful) with jaggery piece", kcal: 160, protein: 6, carbs: 16, fat: 9 },
        { name: "Masala Chai (low sugar) with 2 multi-grain biscuits", kcal: 130, protein: 3, carbs: 22, fat: 4 }
      ],
      dinner: [
        { name: "2 Multigrain Phulkas, Yellow Moong Dal & Bhindi Masala", kcal: 460, protein: 18, carbs: 68, fat: 11 },
        { name: "Vegetable Khichdi made with brown rice, moong & spiced dahi", kcal: 430, protein: 16, carbs: 70, fat: 9 },
        { name: "Paneer Tikka with 1 Missi Roti & fresh green salad", kcal: 480, protein: 25, carbs: 48, fat: 19 },
        { name: "Soya Chunks Curry (high protein) with 2 Rotis & salad", kcal: 490, protein: 29, carbs: 58, fat: 14 },
        { name: "Vegetable Daliya (cracked wheat) with roasted flax seeds", kcal: 390, protein: 14, carbs: 64, fat: 8 },
        { name: "2 Roti, Lauki Kofta Curry & Cucumber Mint Raita", kcal: 440, protein: 15, carbs: 66, fat: 12 },
        { name: "Moong Dal Sprouts Pulao with Spiced Buttermilk", kcal: 420, protein: 19, carbs: 64, fat: 9 }
      ]
    },
    nonveg: {
      breakfast: [
        { name: "3-Egg White Omelet with onions, tomatoes & 2 brown toasts", kcal: 310, protein: 22, carbs: 32, fat: 9 },
        { name: "2 Boiled Eggs with Vegetable Poha & roasted peanuts", kcal: 340, protein: 18, carbs: 42, fat: 11 },
        { name: "Scrambled Eggs (2 whole) on whole wheat toast with sliced avocado", kcal: 360, protein: 20, carbs: 28, fat: 17 },
        { name: "Egg Bhurji with 2 warm Phulkas & coriander chutney", kcal: 350, protein: 21, carbs: 38, fat: 12 },
        { name: "Chicken Keema Paratha (1 thin) with mint raita", kcal: 370, protein: 24, carbs: 36, fat: 14 },
        { name: "Boiled Eggs (2) with Steamed Idlis (2) & hot sambar", kcal: 320, protein: 17, carbs: 42, fat: 8 },
        { name: "Oats Porridge with 1 scoop Whey Protein & chopped almonds", kcal: 340, protein: 28, carbs: 38, fat: 7 }
      ],
      midMorning: [
        { name: "2 Boiled Egg Whites with chaat masala", kcal: 35, protein: 8, carbs: 1, fat: 0 },
        { name: "Seasonal fruit bowl (papaya & guava) with chia seeds", kcal: 95, protein: 2, carbs: 22, fat: 1 },
        { name: "Chilled Buttermilk (chaas) with roasted cumin", kcal: 65, protein: 3, carbs: 6, fat: 2 },
        { name: "Handful of California almonds (8) & walnuts (4)", kcal: 155, protein: 5, carbs: 6, fat: 14 },
        { name: "Sprouted Moong Chaat with lemon", kcal: 135, protein: 9, carbs: 22, fat: 1 },
        { name: "Tender Coconut Water", kcal: 70, protein: 1, carbs: 15, fat: 0 },
        { name: "Roasted Makhana bowl", kcal: 110, protein: 4, carbs: 20, fat: 2 }
      ],
      lunch: [
        { name: "Grilled Chicken Breast (150g), Brown Rice, Dal & Cucumber Salad", kcal: 540, protein: 42, carbs: 62, fat: 10 },
        { name: "Home-style Chicken Curry with 2 Whole Wheat Rotis & Onion Salad", kcal: 530, protein: 36, carbs: 54, fat: 14 },
        { name: "Fish Curry (Rohu/Surmai) with Steamed Rice & Cabbage Poriyal", kcal: 490, protein: 34, carbs: 64, fat: 10 },
        { name: "Egg Curry (3 eggs) with Jeera Rice & Beetroot Salad", kcal: 520, protein: 25, carbs: 68, fat: 16 },
        { name: "2 Multigrain Rotis, Chicken Tikka (140g) & Mint Kachumber", kcal: 530, protein: 38, carbs: 50, fat: 15 },
        { name: "Rice, Boiled Egg Curry & Sauteed Spinach Poriyal", kcal: 510, protein: 26, carbs: 66, fat: 14 },
        { name: "Grilled Chicken Breast with Mashed Potatoes & Green Beans", kcal: 510, protein: 42, carbs: 48, fat: 12 }
      ],
      eveningSnack: [
        { name: "3 Boiled Egg Whites with crushed black pepper & lemon", kcal: 55, protein: 12, carbs: 1, fat: 0 },
        { name: "Grilled Chicken Skewer strips (80g) with mint chutney", kcal: 160, protein: 22, carbs: 3, fat: 6 },
        { name: "Green Tea with roasted makhana", kcal: 120, protein: 4, carbs: 22, fat: 2 },
        { name: "Fruit Chaat with black salt", kcal: 105, protein: 2, carbs: 24, fat: 0 },
        { name: "Sprouts Bhel with pomegranate", kcal: 145, protein: 8, carbs: 26, fat: 2 },
        { name: "Boiled sweet corn chaat", kcal: 130, protein: 4, carbs: 27, fat: 1 },
        { name: "Masala Chai with multigrain toast", kcal: 130, protein: 3, carbs: 22, fat: 4 }
      ],
      dinner: [
        { name: "Tandoori Spiced Grilled Chicken Breast (150g) with Sauteed Veggies", kcal: 430, protein: 44, carbs: 18, fat: 13 },
        { name: "2 Whole Wheat Rotis, Chicken Masala Gravy & Salad", kcal: 480, protein: 34, carbs: 52, fat: 14 },
        { name: "Grilled Fish Fillet (140g) with 1 Missi Roti & Kachumber", kcal: 440, protein: 35, carbs: 40, fat: 12 },
        { name: "Egg Curry (2 eggs) with fragrant Jeera Rice & Salad", kcal: 460, protein: 24, carbs: 56, fat: 15 },
        { name: "Clear Chicken Vegetable Soup with Grilled Chicken Toastie", kcal: 410, protein: 32, carbs: 42, fat: 11 },
        { name: "2 Rotis, Egg Bhurji & Yellow Moong Dal", kcal: 450, protein: 26, carbs: 54, fat: 14 },
        { name: "Grilled Lemon Herb Chicken with Brown Rice & Stir-fry", kcal: 470, protein: 38, carbs: 54, fat: 12 }
      ]
    }
  };

  class DietService {
    getGoals() {
      return GOALS;
    }

    calculateBMI(heightCm, weightKg) {
      if (!heightCm || !weightKg || heightCm <= 0 || weightKg <= 0) {
        return { value: 0, category: "Unknown", color: "gray", explanation: "Please enter height and weight to calculate BMI." };
      }
      const heightM = heightCm / 100;
      const bmi = weightKg / (heightM * heightM);
      const rounded = Math.round(bmi * 10) / 10;

      let category = "Healthy weight";
      let color = "green";
      let explanation = "Your weight falls in the standard healthy weight range for adults.";
      let suggestedGoal = "maintain";

      if (bmi < 18.5) {
        category = "Underweight";
        color = "blue";
        explanation = "You may benefit from a mild calorie surplus with nutrient-rich foods to build strength and lean mass.";
        suggestedGoal = "gain";
      } else if (bmi >= 25 && bmi < 29.9) {
        category = "Overweight";
        color = "orange";
        explanation = "A structured calorie deficit paired with regular resistance training will help shed excess body fat while staying strong.";
        suggestedGoal = "lose";
      } else if (bmi >= 30) {
        category = "Obese range";
        color = "orange";
        explanation = "We recommend consistent, gradual weight loss through calorie deficits, walking, and wholesome nutrition.";
        suggestedGoal = "lose";
      }

      return {
        value: rounded,
        category,
        color,
        explanation: `${explanation} (Note: BMI is an overall guideline. Body composition and muscle mass also play significant roles.)`,
        suggestedGoal
      };
    }

    calculateTDEE(profile) {
      const { age, height, weight, gender, activityLevel } = profile;
      // Mifflin-St Jeor Equation with inclusive Transgender support
      // Female: -161, Male: +5, Transgender: balanced metabolic median (-78)
      let s = 5;
      if (gender === "female") {
        s = -161;
      } else if (gender === "transgender") {
        s = -78;
      }

      const bmr = 10 * Number(weight) + 6.25 * Number(height) - 5 * Number(age) + s;
      const act = ACTIVITY_MULTIPLIERS[activityLevel] || ACTIVITY_MULTIPLIERS.moderate;
      return Math.round(bmr * act.mult);
    }

    calculateTargets(profile) {
      const tdee = this.calculateTDEE(profile);
      const goalObj = GOALS.find(g => g.id === profile.goal) || GOALS[0]; // default weight loss
      const targetCalories = Math.max(1300, tdee + goalObj.calorieDelta);

      // Protein target based on body weight
      const proteinGrams = Math.round(profile.weight * goalObj.proteinMultiplier);
      const proteinKcal = proteinGrams * 4;

      // Fat target (~25% of calories)
      const fatKcal = Math.round(targetCalories * goalObj.fatRatio);
      const fatGrams = Math.round(fatKcal / 9);

      // Remaining calories for carbohydrates
      const carbKcal = Math.max(0, targetCalories - (proteinKcal + fatKcal));
      const carbGrams = Math.round(carbKcal / 4);

      return {
        tdee,
        targetCalories,
        proteinGrams,
        carbGrams,
        fatGrams,
        goalObj
      };
    }

    generateDayMealPlan(profile, dayIndex) {
      const pref = profile.dietPref === "nonveg" ? "nonveg" : "veg";
      const db = INDIAN_FOOD_DB[pref];
      const targets = this.calculateTargets(profile);

      // Rotation index to ensure fresh variety each day
      const bIndex = dayIndex % db.breakfast.length;
      const mmIndex = (dayIndex + 1) % db.midMorning.length;
      const lIndex = (dayIndex + 2) % db.lunch.length;
      const esIndex = (dayIndex + 3) % db.eveningSnack.length;
      const dIndex = (dayIndex + 4) % db.dinner.length;

      const breakfast = db.breakfast[bIndex];
      const midMorning = db.midMorning[mmIndex];
      const lunch = db.lunch[lIndex];
      const eveningSnack = db.eveningSnack[esIndex];
      const dinner = db.dinner[dIndex];

      const totalKcal = breakfast.kcal + midMorning.kcal + lunch.kcal + eveningSnack.kcal + dinner.kcal;
      const totalProtein = breakfast.protein + midMorning.protein + lunch.protein + eveningSnack.protein + dinner.protein;
      const totalCarbs = breakfast.carbs + midMorning.carbs + lunch.carbs + eveningSnack.carbs + dinner.carbs;
      const totalFat = breakfast.fat + midMorning.fat + lunch.fat + eveningSnack.fat + dinner.fat;

      return {
        dayName: DAY_NAMES[dayIndex],
        dayIndex,
        targets,
        totals: {
          kcal: totalKcal,
          protein: totalProtein,
          carbs: totalCarbs,
          fat: totalFat
        },
        meals: {
          breakfast: { label: "Breakfast", icon: "utensils", color: "orange", ...breakfast },
          midMorning: { label: "Mid-Morning Snack", icon: "leaf", color: "green", ...midMorning },
          lunch: { label: "Lunch", icon: "utensils", color: "blue", ...lunch },
          eveningSnack: { label: "Evening Snack", icon: "flame", color: "green", ...eveningSnack },
          dinner: { label: "Dinner", icon: "utensils", color: "orange", ...dinner }
        }
      };
    }

    generate7DayPlan(profile) {
      const days = [];
      for (let i = 0; i < 7; i++) {
        days.push(this.generateDayMealPlan(profile, i));
      }
      return days;
    }
  }

  window.FitPic.DietService = new DietService();
})();
