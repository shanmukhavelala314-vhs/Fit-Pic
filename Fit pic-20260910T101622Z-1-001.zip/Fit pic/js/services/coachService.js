/**
 * FIT PIC — AI SMART COACH SERVICE
 * Dedicated interactive coaches: Coach Maya & Coach Shannu.
 * Context-aware guidance, animated gesture reactions, weight loss advice,
 * inclusive Transgender athletic support, and progressive dumbbell coaching.
 */
window.FitPic = window.FitPic || {};

(function() {
  const COACH_PROFILES = {
    shannu: {
      id: "shannu",
      name: "Coach Shannu",
      title: "Performance & Strength Mentor",
      gender: "male",
      accentColor: "green",
      badgeColor: "chip-green",
      avatarImg: "assets/shannu.png",
      greeting: "Fired up and ready to roll! I'm Coach Shannu. Let's lock in strict dumbbell form, push progressive overload, and build unstoppable student strength!",
      bio: "High-intensity athletic strength coach wearing the iconic Fit Pic crewneck. Expert in dumbbell biomechanics, explosive reps, and iron discipline.",
      signature: "— Coach Shannu 🔥💪",
      voiceStyle: "High energy, motivating, tactical and direct."
    },
    maya: {
      id: "maya",
      name: "Coach Maya",
      title: "Holistic Nutrition & Fat Loss Coach",
      gender: "female",
      accentColor: "green",
      badgeColor: "chip-green",
      avatarImg: "assets/maya.png",
      greeting: "Welcome! I'm Coach Maya. True fitness begins with loving your journey, clean nutrition, and smart fat-loss pacing. Let's make today mindful, vibrant, and powerful!",
      bio: "Mindful student wellness and fat-loss specialist. Focused on Indian meal planning, sustainable calorie deficits, mobility flow, and recovery.",
      signature: "— Coach Maya 🌿✨",
      voiceStyle: "Empathetic, scientifically grounded, encouraging and warm."
    }
  };

  const QUICK_PROMPTS = [
    { label: "🔥 Fat Loss & Weight Tips", query: "What are the best tips to accelerate my weight loss and fat burn?" },
    { label: "🏋️ Today's Dumbbell Workout", query: "What is today's workout and how should I execute the dumbbell movements?" },
    { label: "🥗 What should I eat today?", query: "What should I eat today to hit my calorie and protein targets?" },
    { label: "⚡ How is my progress tracking?", query: "How is my workout consistency and progress tracking this week?" },
    { label: "🎯 Explain my AI Analysis", query: "Can you explain my recent AI Analysis results and what I should improve?" },
    { label: "💪 Give me motivation!", query: "I need some motivation to stay consistent today as a student!" },
    { label: "💤 Why is rest vital?", query: "Why is rest and sleep just as important as lifting heavy?" }
  ];

  class CoachService {
    getCoach(coachId) {
      const valid = coachId === "maya" ? "maya" : "shannu";
      return COACH_PROFILES[valid];
    }

    getAllCoaches() {
      return Object.values(COACH_PROFILES);
    }

    getQuickPrompts() {
      return QUICK_PROMPTS;
    }

    /**
     * Interactive Coach Gesture Reaction Responses
     */
    async getGestureReaction(coachId, gestureType) {
      await new Promise(resolve => setTimeout(resolve, 350));
      const coach = this.getCoach(coachId);
      const state = window.FitPic.State.getState();
      const name = state.profile.name || "friend";

      switch (gestureType) {
        case "wave":
          if (coachId === "shannu") {
            return `*Waves enthusiastically with a grin* 👋 "Yo ${name}! Ready to dominate today's workout? Grab those dumbbells and let's get after it!"`;
          } else {
            return `*Warmly waves with a bright smile* 👋 "Hello ${name}! I'm so glad to see you today. Remember to drink a tall glass of water and take three deep breaths before we dive in!"`;
          }

        case "flex":
          if (coachId === "shannu") {
            return `*Flexes both biceps with intensity* 💪 "Check the form! Biceps, triceps, core locked tight! You've got untapped power in you, ${name}. Don't leave reps on the table!"`;
          } else {
            return `*Strikes a confident athletic stance* ✨ "Strength isn't just physical—it's your mental resilience showing up every single day. Look how far you've come already!"`;
          }

        case "tip":
          if (coachId === "shannu") {
            return `*Points with focused coaching eye* 🎯 "Pro Dumbbell Tip: Control the eccentric (lowering) phase for 2 full seconds! That eccentric stretch creates 60% of muscle adaptation. Slow down the drop!"`;
          } else {
            return `*Gestures mindfully* 🥗 "Nutrition Secret: Eating 25-30g of protein at breakfast prevents late-night sugar cravings on campus. Add boiled eggs or paneer/soya cheela to start strong!"`;
          }

        case "push":
          if (coachId === "shannu") {
            return `*Pumps fists in the air* 🔥 "100% effort! Today's burn is tomorrow's trophy. One more rep, one more set—you against your old self!"`;
          } else {
            return `*Claps encouragingly* 🌟 "Listen to your body, push past the mental doubt, and trust the process. You are completely capable of achieving this weight goal!"`;
          }

        default:
          return `*Nods attentively* "I'm right here in your corner. What are we tackling next?"`;
      }
    }

    /**
     * Context-aware conversational response generator
     */
    async getCoachResponse(coachId, userText) {
      // Simulate natural typing/thinking latency
      await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 400));

      const coach = this.getCoach(coachId);
      const state = window.FitPic.State.getState();
      const profile = state.profile;
      const todayIndex = state.selectedDayIndex;
      const dayMeal = window.FitPic.DietService.generateDayMealPlan(profile, todayIndex);
      const dayWorkout = window.FitPic.WorkoutService.getDayWorkout(profile, todayIndex);
      const completedCount = Object.values(state.workoutProgress).filter(Boolean).length;
      const latestAnalysis = state.latestAnalysis;

      const lower = userText.toLowerCase().trim();

      // 1. Safety / Medical Guardrails Check
      if (
        lower.includes("chest pain") || lower.includes("sharp pain") || lower.includes("dizzy") ||
        lower.includes("vomit") || lower.includes("cure diabetes") || lower.includes("heart attack") ||
        lower.includes("injured") || lower.includes("doctor") || lower.includes("blood") || lower.includes("fracture")
      ) {
        return (
          `⚠️ **Important Health Notice:**\n` +
          `Your safety is our absolute first priority, ${profile.name || "friend"}. What you're describing sounds like a symptom that needs medical evaluation.\n\n` +
          `Fit Pic provides general wellness education only. Please pause any strenuous training and consult a licensed healthcare professional, campus clinic, or doctor immediately.`
        );
      }

      // 2. Weight Loss & Fat Burn Queries
      if (lower.includes("weight loss") || lower.includes("lose weight") || lower.includes("fat burn") || lower.includes("cut") || lower.includes("deficit") || lower.includes("belly")) {
        const targetKcal = dayMeal.targets.targetCalories;
        const deficit = Math.abs(dayMeal.targets.goalObj.calorieDelta);
        if (coachId === "maya") {
          return `For effective **Weight Loss**, consistency in your **${deficit} kcal deficit** is key! Your target is **${targetKcal} kcal/day** with high protein (${dayMeal.targets.proteinGrams}g) to keep you full and preserve lean tissue. Combine your 7-day Indian meal plan with 8,000–10,000 campus steps daily and 3L of water. You'll see remarkable results week by week! 🌿`;
        } else {
          return `Fat loss isn't just starving—it's metabolic acceleration! We keep calories at **${targetKcal} kcal** so you burn fat for fuel while keeping those dumbbells heavy to protect every ounce of muscle. Hit today's HIIT intervals with full intensity, ${profile.name}! 🔥`;
        }
      }

      // 3. Today's Workout & Dumbbell Routine Query
      if (lower.includes("workout") || lower.includes("exercise") || lower.includes("dumbbell") || lower.includes("routine")) {
        if (dayWorkout.isRest) {
          if (coachId === "shannu") {
            return `Today is scheduled as an **Active Recovery day** for you, ${profile.name}! Your body rebuilds muscle tissue while resting. Go for a 20-minute campus walk, do some light mobility, and stay hydrated. Tomorrow we pick up the dumbbells and hit it hard!`;
          } else {
            return `Today is a gentle **Rest & Recovery day**, ${profile.name}. Recovery is where the magic happens! Focus on mindful stretching, gentle yoga, and getting 8 hours of restorative sleep to recharge your nervous system.`;
          }
        } else {
          const exNames = dayWorkout.exercises.map(e => e.name).join(", ");
          if (coachId === "shannu") {
            return `Today is **${dayWorkout.focus}**! You've got ${dayWorkout.exercises.length} movements lined up: ${exNames}. Estimated duration is ${dayWorkout.durationMinutes} minutes at ${dayWorkout.intensity}. Grip those dumbbells with conviction, control your breathing, and crush every set!`;
          } else {
            return `Today's session is **${dayWorkout.focus}** (~${dayWorkout.durationMinutes} mins). Focus on clean form and steady breathing across your exercises: ${exNames}. Warm up thoroughly for 3 minutes before grabbing weights!`;
          }
        }
      }

      // 4. Today's Diet / Nutrition Query
      if (lower.includes("eat") || lower.includes("food") || lower.includes("meal") || lower.includes("diet") || lower.includes("protein") || lower.includes("calorie")) {
        const lunch = dayMeal.meals.lunch.name;
        const targetKcal = dayMeal.targets.targetCalories;
        const targetProtein = dayMeal.targets.proteinGrams;
        const dietPref = profile.dietPref === "veg" ? "Vegetarian" : "Non-vegetarian";

        if (coachId === "shannu") {
          return `For your **${profile.goal.toUpperCase()}** target, your daily fuel is **${targetKcal} kcal** with **${targetProtein}g of protein**! Today's ${dietPref} menu highlights **${lunch}** for lunch. Make sure you don't skip your evening protein snack to power your recovery!`;
        } else {
          return `Your daily nourishment target is **${targetKcal} kcal** with **${targetProtein}g of protein** (${dietPref}). For lunch today, enjoy **${lunch}**. Stay mindful of drinking 2.5–3 liters of water and enjoy seasonal fruits for essential micronutrients and gut health!`;
        }
      }

      // 5. Gender / Identity / Inclusivity queries
      if (lower.includes("transgender") || lower.includes("gender") || lower.includes("inclusive")) {
        return (
          `At Fit Pic, we celebrate and support all student athletes! 🏳️‍⚧️ Our algorithms calculate your metabolic targets with tailored balance to support your body's specific goals—whether that is building lean definition, shaping muscle, or maximizing stamina. Coach Maya and Coach Shannu are with you 100% of the way!`
        );
      }

      // 6. Progress Tracking Query
      if (lower.includes("progress") || lower.includes("track") || lower.includes("consistent") || lower.includes("streak")) {
        return `You have completed **${completedCount} of 7** scheduled workouts this week with a **${state.streakDays}-day streak** 🔥! As a student juggling classes and fitness, that consistency puts you in the top 10% of dedicated athletes. Keep showing up!`;
      }

      // 7. Student Motivation
      if (lower.includes("motivation") || lower.includes("tired") || lower.includes("lazy") || lower.includes("exam") || lower.includes("study")) {
        if (coachId === "shannu") {
          return `Listen up, ${profile.name}! Some days motivation won't be there—that's when **discipline** takes over. Even a focused 20-minute dumbbell blast will clear your brain fog, spike your endorphins, and make studying twice as productive. Let's lace up!`;
        } else {
          return `Take a gentle breath, ${profile.name}. Academic pressure is real, and feeling tired is completely normal. Remember: fitness isn't another chore—it's your dedicated gift to yourself to recharge your brain. Even 15 minutes of movement will lift your spirits! 🌿`;
        }
      }

      // Default contextual advice
      if (coachId === "shannu") {
        return `Got it, ${profile.name}! Whatever your questions—from dialing in your dumbbell technique to optimizing fat burn—I'm here. Let's make every rep count! ${coach.signature}`;
      } else {
        return `I hear you, ${profile.name}! Whether you want to fine-tune your meal swaps, accelerate healthy weight loss, or improve joint recovery, I'm right by your side. ${coach.signature}`;
      }
    }
  }

  window.FitPic.CoachService = new CoachService();
})();
