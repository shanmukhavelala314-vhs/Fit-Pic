/**
 * FIT PIC — WORKOUT SERVICE
 * Generates personalized 7-day workout routines based on fitness goal (including dedicated Weight Loss / Fat Burn),
 * experience level, and dumbbell equipment. Includes Warm-up, Main Exercises, Cool-down, and interactive tracking.
 */
window.FitPic = window.FitPic || {};

(function() {
  const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  const LEVEL_CONFIGS = {
    beginner: {
      label: "Beginner",
      sets: "2-3 sets",
      reps: "10-12 reps",
      rest: "60-75s rest",
      baseDuration: 30,
      intensity: "Moderate"
    },
    intermediate: {
      label: "Intermediate",
      sets: "3-4 sets",
      reps: "10-15 reps",
      rest: "45-60s rest",
      baseDuration: 42,
      intensity: "Challenging"
    },
    advanced: {
      label: "Advanced",
      sets: "4-5 sets",
      reps: "12-15 reps",
      rest: "30-45s rest",
      baseDuration: 52,
      intensity: "High Intensity"
    }
  };

  // 7-Day Workout Programs per Fitness Goal
  const WORKOUT_PROGRAMS = {
    // 1. DEDICATED WEIGHT LOSS & FAT BURN PROGRAM
    lose: [
      {
        dayIndex: 0,
        focus: "Full-Body Dumbbell Fat Burner & Metabolic Conditioning",
        isRest: false,
        warmup: ["Jumping jacks & arm circles (60s)", "Dynamic bodyweight squats (60s)", "High knees in place (60s)"],
        exercises: [
          { name: "Dumbbell Goblet Squat to Overhead Press", sets: "3-4", reps: "12-15 reps", rest: "45s", difficulty: "High Burn", tip: "Power out of the squat and drive dumbbells directly overhead to maximize calorie burn." },
          { name: "Alternating Dumbbell Renegade Rows", sets: "3-4", reps: "10 per arm", rest: "45s", difficulty: "Challenging", tip: "Lock your core tight in a plank and pull each dumbbell to your ribcage without swaying." },
          { name: "Dumbbell Romanian Deadlifts", sets: "3-4", reps: "12-14 reps", rest: "45s", difficulty: "Moderate", tip: "Hinge at the hips, keeping dumbbells close to your shins to target hamstrings and glutes." },
          { name: "Mountain Climbers (Metabolic Sprint)", sets: "3-4", reps: "40 secs", rest: "30s", difficulty: "High Burn", tip: "Fast cadence; keep hips low and drive knees rapidly toward your chest." },
          { name: "Dumbbell Farmer's Carry / March in Place", sets: "3", reps: "45 secs", rest: "30s", difficulty: "Moderate", tip: "Stand tall, pull shoulders back, brace your core, and maintain a steady march." }
        ],
        cooldown: ["Standing hamstring stretch (60s)", "Deep thoracic child's pose (90s)"]
      },
      {
        dayIndex: 1,
        focus: "HIIT Tabata Cardio & Core Shred",
        isRest: false,
        warmup: ["Torso rotations (60s)", "Ankle rolls & light shadow boxing (90s)"],
        exercises: [
          { name: "Dumbbell Burpee Deadlifts", sets: "4", reps: "10-12 reps", rest: "45s", difficulty: "High Burn", tip: "Drop into pushup position, jump feet in, and stand with dumbbells by your sides with flat back." },
          { name: "Bicycle Crunches to Flutter Kicks", sets: "3-4", reps: "20 reps each", rest: "30s", difficulty: "Challenging", tip: "Engage lower abs; do not strain the neck, touch opposite elbow to knee." },
          { name: "Dumbbell Shadow Jab-Cross Intervals", sets: "3", reps: "45 secs", rest: "30s", difficulty: "High Burn", tip: "Use light 1-3kg dumbbells, stay light on your toes, punch with crisp snap." },
          { name: "Plank Shoulder Taps", sets: "3", reps: "20 total taps", rest: "30s", difficulty: "Moderate", tip: "Maintain rigid core stability; minimize any rocking in the hips." }
        ],
        cooldown: ["Cobra abdominal stretch (60s)", "Seated forward fold (60s)"]
      },
      {
        dayIndex: 2,
        focus: "Active Recovery & Joint Mobility",
        isRest: true,
        warmup: ["Gentle neck & shoulder mobility (2 mins)"],
        exercises: [
          { name: "Cat-Cow Spine Flow", sets: "2", reps: "10 cycles", rest: "30s", difficulty: "Gentle", tip: "Inhale arching gently, exhale rounding spine smoothly." },
          { name: "Deep World's Greatest Stretch", sets: "2", reps: "5 per side", rest: "30s", difficulty: "Gentle", tip: "Open thoracic spine and sink hips deep into runner's lunge." },
          { name: "25-minute Brisk Fat-Burn Campus Walk", sets: "1", reps: "25 mins", rest: "-", difficulty: "Light", tip: "Steady state movement keeps the metabolism burning fat while clearing cortisol." }
        ],
        cooldown: ["Supine spinal twist breathing (2 mins)"]
      },
      {
        dayIndex: 3,
        focus: "Upper Body Definition & Dumbbell Sculpt",
        isRest: false,
        warmup: ["Band pull-aparts (60s)", "Incline push-ups warmup (10 reps)"],
        exercises: [
          { name: "Dumbbell Incline/Floor Chest Press", sets: "3-4", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Lower weights under 2-second control, press smoothly and squeeze chest." },
          { name: "Single-Arm Dumbbell Rows", sets: "3-4", reps: "12 per side", rest: "45s", difficulty: "Moderate", tip: "Pull elbow back towards your hip, pausing at peak contraction." },
          { name: "Dumbbell Arnold Shoulder Press", sets: "3-4", reps: "10-12 reps", rest: "45s", difficulty: "Challenging", tip: "Rotate palms outward as you press smoothly overhead." },
          { name: "Dumbbell Hammer Curls to Tricep Kickbacks", sets: "3", reps: "12 reps each", rest: "30s", difficulty: "Moderate", tip: "Sculpt tone in both biceps and triceps without swinging." }
        ],
        cooldown: ["Doorway chest stretch (60s)", "Tricep overhead stretch (60s)"]
      },
      {
        dayIndex: 4,
        focus: "Lower Body Glute & Leg Calorie Crusher",
        isRest: false,
        warmup: ["Glute bridge activation (15 reps)", "Walking lunges with reach (90s)"],
        exercises: [
          { name: "Walking Dumbbell Lunges", sets: "3-4", reps: "12 per leg", rest: "60s", difficulty: "High Burn", tip: "Keep torso upright, take balanced strides, lightly tap trailing knee." },
          { name: "Dumbbell Sumo Squats", sets: "3-4", reps: "14 reps", rest: "45s", difficulty: "Moderate", tip: "Wide stance, toes pointed 45 degrees, squeeze inner thighs and glutes at the top." },
          { name: "Dumbbell Step-Ups / High Step March", sets: "3", reps: "12 per leg", rest: "45s", difficulty: "Challenging", tip: "Push through the heel of the leading foot to engage the glute." },
          { name: "Wall Sit Hold with Dumbbell on Lap", sets: "3", reps: "45 secs", rest: "30s", difficulty: "High Burn", tip: "Thighs strictly parallel to ground, breathe deeply and stay composed." }
        ],
        cooldown: ["Standing quad stretch (60s)", "Pigeon pose hip stretch (90s)"]
      },
      {
        dayIndex: 5,
        focus: "Metabolic HIIT Finisher & Calorie Shred",
        isRest: false,
        warmup: ["Jumping jacks (60s)", "Butt kicks (60s)"],
        exercises: [
          { name: "Dumbbell Thrusters (Interval Cadence)", sets: "4", reps: "40s on / 20s off", rest: "45s", difficulty: "High Burn", tip: "Fast, rhythmic full-body squat-to-press to ignite post-workout oxygen consumption." },
          { name: "Speed Skater Lateral Hops", sets: "4", reps: "40s on / 20s off", rest: "30s", difficulty: "High Burn", tip: "Bound side to side, landing softly on the outside foot." },
          { name: "Dumbbell Russian Twists", sets: "3", reps: "24 total taps", rest: "30s", difficulty: "Moderate", tip: "Keep feet elevated and touch the dumbbell to either side with control." },
          { name: "Forearm Plank to Pike", sets: "3", reps: "45 sec hold", rest: "30s", difficulty: "Challenging", tip: "Brace glutes and abdominal wall firmly." }
        ],
        cooldown: ["Seated butterfly stretch (60s)", "Slow diaphragmatic walk (2 mins)"]
      },
      {
        dayIndex: 6,
        focus: "Rest, Active Mobility & Weekly Fat Loss Review",
        isRest: true,
        warmup: ["Full body gentle joint rolls (2 mins)"],
        exercises: [
          { name: "Mindful 20-minute Recovery Walk", sets: "1", reps: "20 mins", rest: "-", difficulty: "Light", tip: "Relaxation and steady low-impact movement accelerate muscle recovery." },
          { name: "Full Body Foam Rolling / Self-Massage", sets: "1", reps: "10 mins", rest: "-", difficulty: "Gentle", tip: "Release trigger points in calves, IT band, and upper back." }
        ],
        cooldown: ["Deep breathing relaxation (3 mins)"]
      }
    ],

    // 2. BODY RECOMPOSITION PROGRAM
    recomp: [
      {
        dayIndex: 0,
        focus: "Full Body Strength & Core Activation",
        isRest: false,
        warmup: ["Arm circles & dynamic chest hugs (60s)", "Bodyweight hip openers & air squats (90s)", "High knees & light jog in place (60s)"],
        exercises: [
          { name: "Goblet Squats (Dumbbell or Weighted)", sets: "3-4", reps: "12 reps", rest: "60s", difficulty: "Moderate", tip: "Keep chest tall, push knees out in line with toes, break parallel smoothly." },
          { name: "Push-ups (Strict tempo)", sets: "3-4", reps: "10-15 reps", rest: "45s", difficulty: "Moderate", tip: "Lock core, tuck elbows at 45 degrees, touch chest lightly to floor." },
          { name: "Dumbbell Bent-Over Rows", sets: "3-4", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Hinge hips back, keep spine neutral, squeeze shoulder blades together." },
          { name: "Forearm Plank to Pike", sets: "3", reps: "45 sec hold", rest: "30s", difficulty: "Challenging", tip: "Avoid sagging hips; brace glutes and abdominal wall firmly." }
        ],
        cooldown: ["Standing hamstring & calf stretch (60s)", "Cobra pose & child's pose breathing (90s)"]
      },
      {
        dayIndex: 1,
        focus: "High-Intensity Functional Conditioning (HIIT)",
        isRest: false,
        warmup: ["Jumping jacks & torso twists (60s)", "Ankle rolls & leg swings (60s)"],
        exercises: [
          { name: "Dumbbell Thrusters / Squat to Press", sets: "3-4", reps: "12 reps", rest: "45s", difficulty: "Challenging", tip: "Use the upward leg drive to power the weights overhead in one fluid motion." },
          { name: "Mountain Climbers (Fast cadence)", sets: "3-4", reps: "30 secs", rest: "30s", difficulty: "Challenging", tip: "Keep hips level with shoulders; drive knees rapidly toward chest." },
          { name: "Bicycle Crunches", sets: "3", reps: "20 total reps", rest: "30s", difficulty: "Moderate", tip: "Rotate from torso, not neck; touch opposite elbow to knee with control." },
          { name: "Burpees / Up-Downs", sets: "3", reps: "10 reps", rest: "60s", difficulty: "Challenging", tip: "Land softly on balls of feet and jump with arms extended high." }
        ],
        cooldown: ["Seated forward fold (60s)", "Deep diaphragmatic breathing walk (2 mins)"]
      },
      {
        dayIndex: 2,
        focus: "Active Recovery & Mobility Flow",
        isRest: true,
        warmup: ["Gentle neck & shoulder rolls (2 mins)"],
        exercises: [
          { name: "Cat-Cow Spine Flow", sets: "2", reps: "10 breath cycles", rest: "30s", difficulty: "Gentle", tip: "Inhale arching back, exhale rounding spine smoothly." },
          { name: "Deep World's Greatest Stretch", sets: "2", reps: "5 per side", rest: "30s", difficulty: "Gentle", tip: "Open thoracic cage and sink hips deep into lunge." },
          { name: "20-minute Outdoor Campus Walk", sets: "1", reps: "20 mins", rest: "-", difficulty: "Light", tip: "Promotes blood flow, reduces cortisol, and clears mental fatigue." }
        ],
        cooldown: ["Supine spinal twist hold (2 mins)"]
      },
      {
        dayIndex: 3,
        focus: "Upper Body Hypertrophy & Posture",
        isRest: false,
        warmup: ["Band pull-aparts or shoulder dislocates (90s)", "Incline push-ups warmup (10 reps)"],
        exercises: [
          { name: "Dumbbell Overhead Shoulder Press", sets: "3-4", reps: "10-12 reps", rest: "60s", difficulty: "Moderate", tip: "Avoid arching lower back; press straight up till bicep touches ear." },
          { name: "Single-Arm Dumbbell Row", sets: "3-4", reps: "12 per side", rest: "45s", difficulty: "Moderate", tip: "Pull elbow back towards hip crease, pause 1 second at top contraction." },
          { name: "Incline Push-ups or Floor Dumbbell Flyes", sets: "3", reps: "12-15 reps", rest: "45s", difficulty: "Moderate", tip: "Feel chest stretch in bottom position without straining shoulders." },
          { name: "Diamond Push-ups / Tricep Bench Dips", sets: "3", reps: "10-12 reps", rest: "45s", difficulty: "Challenging", tip: "Keep back close to bench; push strictly through triceps." }
        ],
        cooldown: ["Doorway chest stretch (60s)", "Cross-body shoulder stretch (60s)"]
      },
      {
        dayIndex: 4,
        focus: "Lower Body Power & Posterior Chain",
        isRest: false,
        warmup: ["Glute bridge activation (15 reps)", "Walking lunges with reach (90s)"],
        exercises: [
          { name: "Romanian Deadlifts (Dumbbells)", sets: "3-4", reps: "10-12 reps", rest: "60s", difficulty: "Challenging", tip: "Hinge at hips with soft knees; feel deep tension in hamstrings and glutes." },
          { name: "Walking Dumbbell Lunges", sets: "3-4", reps: "10 per leg", rest: "60s", difficulty: "Challenging", tip: "Keep torso upright; gently touch back knee to ground." },
          { name: "Dumbbell Bulgarian Split Squats", sets: "3", reps: "8-10 per leg", rest: "60s", difficulty: "High Intensity", tip: "Elevate rear foot on chair/bench; push through front heel with steady control." },
          { name: "Standing Calf Raises (Elevated ledge)", sets: "3-4", reps: "15-20 reps", rest: "30s", difficulty: "Moderate", tip: "Full stretch at bottom, squeeze peak contraction at top for 1 full second." }
        ],
        cooldown: ["Standing quadriceps stretch (60s)", "Seated figure-4 piriformis stretch (90s)"]
      },
      {
        dayIndex: 5,
        focus: "Athletic Conditioning & Core Finisher",
        isRest: false,
        warmup: ["Jumping jacks (60s)", "Hip rotations (60s)"],
        exercises: [
          { name: "Dumbbell Clean & Press", sets: "3", reps: "10 reps", rest: "45s", difficulty: "Challenging", tip: "Explode from hips and catch weights at shoulders before driving overhead." },
          { name: "Hollow Body Rock or Dead Bug", sets: "3", reps: "12-15 reps", rest: "30s", difficulty: "Moderate", tip: "Keep lumbar spine pressed flat against floor throughout the set." },
          { name: "Side Plank with Hip Dips", sets: "3", reps: "10 per side", rest: "30s", difficulty: "Moderate", tip: "Maintain rigid straight line from shoulders to ankles." },
          { name: "Tabata High Knees Finisher", sets: "4 rounds", reps: "20s on / 10s off", rest: "45s", difficulty: "High Intensity", tip: "Max effort sprint in place; lift knees above hip crease." }
        ],
        cooldown: ["Cat-cow relaxation (60s)", "Child's pose breathing (2 mins)"]
      },
      {
        dayIndex: 6,
        focus: "Rest, Nutrition Prep & Mindset Recharge",
        isRest: true,
        warmup: ["Slow neck circles and deep breathing (2 mins)"],
        exercises: [
          { name: "20-30 Minute Mindful Nature Walk", sets: "1", reps: "25 mins", rest: "-", difficulty: "Rest", tip: "Step outside campus, breathe fresh air, allow muscles to synthesize amino acids." },
          { name: "Full Body Foam Rolling & Mobility Check", sets: "1", reps: "10 mins", rest: "-", difficulty: "Gentle", tip: "Loosen tight quads, lats, and glutes ready for next week's progressive overload." }
        ],
        cooldown: ["Supine spinal twist breathing (2 mins)"]
      }
    ],

    // 3. WEIGHT GAIN / HYPERTROPHY PROGRAM
    gain: [
      {
        dayIndex: 0,
        focus: "Push Day: Chest, Shoulders & Triceps Mass",
        isRest: false,
        warmup: ["Arm circles", "Light push-ups"],
        exercises: [
          { name: "Dumbbell Floor Press (Heavy)", sets: "4", reps: "8-10 reps", rest: "75s", difficulty: "Heavy", tip: "Focus on slow negative and forceful lockout." },
          { name: "Dumbbell Overhead Shoulder Press", sets: "4", reps: "8-10 reps", rest: "60s", difficulty: "Challenging", tip: "Full overhead extension." },
          { name: "Incline Push-ups or Dumbbell Flyes", sets: "3", reps: "10-12 reps", rest: "45s", difficulty: "Moderate", tip: "Deep stretch across chest fibers." },
          { name: "Overhead Dumbbell Tricep Extension", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Keep elbows tucked in." }
        ],
        cooldown: ["Chest doorway stretch", "Shoulder cross stretch"]
      },
      {
        dayIndex: 1,
        focus: "Pull Day: Back, Rear Delts & Biceps",
        isRest: false,
        warmup: ["Cat-cow", "Shoulder rotations"],
        exercises: [
          { name: "Bent-Over Two-Arm Dumbbell Rows", sets: "4", reps: "8-10 reps", rest: "75s", difficulty: "Heavy", tip: "Squeeze lats hard at top." },
          { name: "Single-Arm Dumbbell Row", sets: "3", reps: "10 per arm", rest: "60s", difficulty: "Challenging", tip: "Pull with elbow, not bicep." },
          { name: "Standing Dumbbell Bicep Curls", sets: "3", reps: "10-12 reps", rest: "45s", difficulty: "Moderate", tip: "No swinging; strict curl." },
          { name: "Dumbbell Hammer Curls", sets: "3", reps: "10-12 reps", rest: "45s", difficulty: "Moderate", tip: "Build brachialis and forearm thickness." }
        ],
        cooldown: ["Lat stretch", "Wrist flexor stretch"]
      },
      {
        dayIndex: 2,
        focus: "Rest & Muscle Synthesis",
        isRest: true,
        warmup: ["Gentle stretch"],
        exercises: [
          { name: "Light 15-min campus stroll", sets: "1", reps: "15 mins", rest: "-", difficulty: "Light", tip: "Fuel up with high-protein meals; muscles grow while at rest." }
        ],
        cooldown: ["Hamstring stretch"]
      },
      {
        dayIndex: 3,
        focus: "Legs & Lower Body Mass",
        isRest: false,
        warmup: ["Air squats", "Hip openers"],
        exercises: [
          { name: "Dumbbell Goblet Squats (Heavy)", sets: "4", reps: "8-10 reps", rest: "75s", difficulty: "Heavy", tip: "Drive out of hole with explosive power." },
          { name: "Dumbbell Romanian Deadlifts", sets: "4", reps: "10 reps", rest: "60s", difficulty: "Challenging", tip: "Feel hamstring stretch." },
          { name: "Walking Lunges with Dumbbells", sets: "3", reps: "10 per leg", rest: "60s", difficulty: "Challenging", tip: "Build quad and glute sweep." },
          { name: "Standing Calf Raises with Dumbbells", sets: "4", reps: "15 reps", rest: "45s", difficulty: "Moderate", tip: "Full stretch at bottom." }
        ],
        cooldown: ["Quad stretch", "Hamstring stretch"]
      },
      {
        dayIndex: 4,
        focus: "Upper Body Hypertrophy Volume",
        isRest: false,
        warmup: ["Band pull-aparts"],
        exercises: [
          { name: "Dumbbell Arnold Press", sets: "3", reps: "10-12 reps", rest: "60s", difficulty: "Challenging", tip: "Hit all 3 shoulder heads." },
          { name: "Dumbbell Shrugs", sets: "4", reps: "12-15 reps", rest: "45s", difficulty: "Moderate", tip: "Pause 2 seconds at top." },
          { name: "Close-Grip Push-ups", sets: "3", reps: "12-15 reps", rest: "45s", difficulty: "Moderate", tip: "Target inner chest & triceps." },
          { name: "Dumbbell Concentration Curls", sets: "3", reps: "10 per arm", rest: "45s", difficulty: "Moderate", tip: "Isolate bicep peak." }
        ],
        cooldown: ["Upper body stretch"]
      },
      {
        dayIndex: 5,
        focus: "Core & Athletic Power",
        isRest: false,
        warmup: ["Torso twists"],
        exercises: [
          { name: "Weighted Hanging or Floor Knee Raises", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Curl pelvis upward." },
          { name: "Dumbbell Russian Twists", sets: "3", reps: "20 reps", rest: "30s", difficulty: "Moderate", tip: "Tight obliques." },
          { name: "Plank with Dumbbell Pull-Through", sets: "3", reps: "12 total", rest: "45s", difficulty: "Challenging", tip: "Resist anti-rotation." }
        ],
        cooldown: ["Child's pose"]
      },
      {
        dayIndex: 6,
        focus: "Rest & Nutrition Recharge",
        isRest: true,
        warmup: ["Breathing exercises"],
        exercises: [
          { name: "Rest & Recovery", sets: "1", reps: "Rest", rest: "-", difficulty: "Rest", tip: "Hit your caloric surplus today." }
        ],
        cooldown: ["Gentle stretch"]
      }
    ],

    // 4. WEIGHT MANAGEMENT & GENERAL FITNESS
    maintain: [
      {
        dayIndex: 0,
        focus: "Full Body Mobility & Calisthenics",
        isRest: false,
        warmup: ["Arm circles", "Hip circles"],
        exercises: [
          { name: "Bodyweight Air Squats", sets: "3", reps: "15 reps", rest: "45s", difficulty: "Moderate", tip: "Smooth controlled tempo." },
          { name: "Standard Push-ups", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Full range of motion." },
          { name: "Dumbbell Rows", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Solid postural strength." },
          { name: "Standard Plank Hold", sets: "3", reps: "45 sec hold", rest: "30s", difficulty: "Moderate", tip: "Total body tension." }
        ],
        cooldown: ["Full body stretch"]
      },
      {
        dayIndex: 1,
        focus: "Moderate Aerobic Cardio & Core",
        isRest: false,
        warmup: ["Jumping jacks"],
        exercises: [
          { name: "Brisk Jog / Fast Walk", sets: "1", reps: "20 mins", rest: "-", difficulty: "Moderate", tip: "Cardiovascular health." },
          { name: "Crunches & Bicycle Crunches", sets: "3", reps: "15 reps each", rest: "30s", difficulty: "Moderate", tip: "Controlled contraction." }
        ],
        cooldown: ["Calf and quad stretch"]
      },
      {
        dayIndex: 2,
        focus: "Active Recovery Day",
        isRest: true,
        warmup: ["Neck rolls"],
        exercises: [
          { name: "Restorative Yoga Flow", sets: "1", reps: "15 mins", rest: "-", difficulty: "Gentle", tip: "Decompress spine and joints." }
        ],
        cooldown: ["Deep breathing"]
      },
      {
        dayIndex: 3,
        focus: "Upper Body Balance & Dumbbells",
        isRest: false,
        warmup: ["Shoulder circles"],
        exercises: [
          { name: "Dumbbell Shoulder Press", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Clean posture." },
          { name: "Incline Push-ups", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Build upper chest." },
          { name: "Dumbbell Curls", sets: "3", reps: "12 reps", rest: "45s", difficulty: "Moderate", tip: "Controlled tempo." }
        ],
        cooldown: ["Chest and arm stretch"]
      },
      {
        dayIndex: 4,
        focus: "Lower Body Balance & Core",
        isRest: false,
        warmup: ["Leg swings", "Glute bridges"],
        exercises: [
          { name: "Alternating Reverse Lunges", sets: "3", reps: "10 per leg", rest: "45s", difficulty: "Moderate", tip: "Step back softly, keep knee aligned." },
          { name: "Glute Bridges (Weighted)", sets: "3", reps: "15 reps", rest: "30s", difficulty: "Moderate", tip: "Squeeze glutes firmly at top." },
          { name: "Wall Sit Hold", sets: "3", reps: "40 sec hold", rest: "30s", difficulty: "Moderate", tip: "Thighs parallel to floor." },
          { name: "Side Plank Hold", sets: "3", reps: "30s per side", rest: "30s", difficulty: "Moderate", tip: "Keep hips lifted high in straight line." }
        ],
        cooldown: ["Quadriceps stretch", "Pigeon pose"]
      },
      {
        dayIndex: 5,
        focus: "Interval Energy Burst (Cardio)",
        isRest: false,
        warmup: ["Jumping jacks", "Arm rolls"],
        exercises: [
          { name: "Jumping Jacks & High Knees Circuit", sets: "4", reps: "45s on / 15s off", rest: "30s", difficulty: "Moderate", tip: "Stay light on your feet." },
          { name: "Russian Twists", sets: "3", reps: "20 reps", rest: "30s", difficulty: "Moderate", tip: "Control every rotation." },
          { name: "Bird-Dog Core Stability", sets: "3", reps: "10 per side", rest: "30s", difficulty: "Gentle", tip: "Extend opposite arm and leg without arching lower back." }
        ],
        cooldown: ["Child's pose", "Hamstring stretch"]
      },
      {
        dayIndex: 6,
        focus: "Rest & Weekly Review",
        isRest: true,
        warmup: ["Gentle breathing"],
        exercises: [
          { name: "Rest & Recovery Walk", sets: "1", reps: "15-20 mins", rest: "-", difficulty: "Rest", tip: "Rest is where your body adapts, repairs, and becomes stronger." }
        ],
        cooldown: ["Full body gentle stretch"]
      }
    ]
  };

  class WorkoutService {
    getLevels() {
      return LEVEL_CONFIGS;
    }

    getWorkoutPlan(profile) {
      const goalKey = profile.goal || "lose";
      const program = WORKOUT_PROGRAMS[goalKey] || WORKOUT_PROGRAMS.lose || WORKOUT_PROGRAMS.recomp;
      const levelConfig = LEVEL_CONFIGS[profile.fitnessLevel] || LEVEL_CONFIGS.intermediate;

      return program.map(day => ({
        ...day,
        dayName: DAY_NAMES[day.dayIndex],
        durationMinutes: day.isRest ? 15 : levelConfig.baseDuration,
        intensity: day.isRest ? "Recovery" : levelConfig.intensity,
        exercises: day.exercises.map(ex => ({
          ...ex,
          sets: day.isRest ? ex.sets : (ex.sets || levelConfig.sets),
          reps: day.isRest ? ex.reps : (ex.reps || levelConfig.reps),
          rest: day.isRest ? ex.rest : (ex.rest || levelConfig.rest)
        }))
      }));
    }

    getDayWorkout(profile, dayIndex) {
      const week = this.getWorkoutPlan(profile);
      return week[dayIndex % 7];
    }
  }

  window.FitPic.WorkoutService = new WorkoutService();
})();
