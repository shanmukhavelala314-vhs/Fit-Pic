/**
 * FIT PIC — CENTRAL REACTIVE STATE STORE
 * Manages user profile, avatar, diet, workouts, AI analysis, and coach conversations.
 * Persists seamlessly to localStorage.
 */
window.FitPic = window.FitPic || {};

(function() {
  const STORAGE_KEY = "fitpic_app_state_v2";
  const OLD_STORAGE_KEY = "fitpic_app_state_v1";

  // Default Student Profile: Demo Ready with Maya & Shannu
  const DEFAULT_STATE = {
    profile: {
      name: "Alex",
      email: "alex@college.edu",
      age: 21,
      gender: "male", // "male", "female", "transgender"
      height: 174,    // cm
      weight: 72,     // kg
      targetWeight: 65, // kg (for weight loss goal)
      activityLevel: "moderate", // sedentary, light, moderate, active
      goal: "lose",              // "lose" (Weight Loss), "recomp", "gain", "maintain"
      dietPref: "veg",           // veg, nonveg
      fitnessLevel: "intermediate", // beginner, intermediate, advanced
      college: "Campus Tech University",
      avatar: null, // Custom base64 image dataURL or preset avatar identifier
      loggedIn: true
    },
    activeTab: "home",
    selectedDayIndex: new Date().getDay() === 0 ? 6 : new Date().getDay() - 1, // Monday = 0, ..., Sunday = 6
    workoutProgress: {
      0: true,  // Monday completed
      1: true,  // Tuesday completed
      2: false, // Wednesday
      3: false, // Thursday
      4: false, // Friday
      5: false, // Saturday
      6: false  // Sunday
    },
    exerciseChecks: {
      "0-0": true, "0-1": true, "0-2": true, "0-3": true,
      "1-0": true, "1-1": true, "1-2": true
    },
    totalWorkoutsCompleted: 14,
    streakDays: 5,
    selectedCoach: "shannu", // "shannu" or "maya"
    coachChats: {
      shannu: [
        {
          role: "assistant",
          text: "Hey! Coach Shannu here, in the zone and ready to roll. You're tracking high energy this week — 2 workouts locked in already! How are your reps feeling today?",
          time: "08:30 AM"
        }
      ],
      maya: [
        {
          role: "assistant",
          text: "Hello! Wonderful to have you here. I'm Coach Maya. Whether your focus is cutting fat, building endurance, or nourishing your body, consistency and mindful recovery will get you there. Let's make today empowering!",
          time: "08:30 AM"
        }
      ]
    },
    latestAnalysis: null,
    analysisHistory: []
  };

  class StateStore {
    constructor() {
      this.listeners = {};
      this.state = this.loadState();
    }

    loadState() {
      try {
        let saved = localStorage.getItem(STORAGE_KEY);
        // Migration from v1 if v2 doesn't exist yet
        if (!saved) {
          saved = localStorage.getItem(OLD_STORAGE_KEY);
        }
        if (saved) {
          const parsed = JSON.parse(saved);
          const merged = {
            ...DEFAULT_STATE,
            ...parsed,
            profile: { ...DEFAULT_STATE.profile, ...(parsed.profile || {}) },
            workoutProgress: { ...DEFAULT_STATE.workoutProgress, ...(parsed.workoutProgress || {}) },
            exerciseChecks: { ...DEFAULT_STATE.exerciseChecks, ...(parsed.exerciseChecks || {}) }
          };

          // Migrate coachId "shennu" -> "shannu"
          if (merged.selectedCoach === "shennu") {
            merged.selectedCoach = "shannu";
          }

          // Migrate coach chats
          merged.coachChats = merged.coachChats || {};
          if (merged.coachChats.shennu && !merged.coachChats.shannu) {
            merged.coachChats.shannu = merged.coachChats.shennu;
          }
          if (!merged.coachChats.shannu) {
            merged.coachChats.shannu = DEFAULT_STATE.coachChats.shannu;
          }
          if (!merged.coachChats.maya) {
            merged.coachChats.maya = DEFAULT_STATE.coachChats.maya;
          }

          return merged;
        }
      } catch (e) {
        console.warn("Could not load stored FitPic state, using defaults:", e);
      }
      return JSON.parse(JSON.stringify(DEFAULT_STATE));
    }

    saveState() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
      } catch (e) {
        console.warn("Could not save FitPic state to localStorage:", e);
      }
    }

    // PubSub Event Bus
    subscribe(event, callback) {
      if (!this.listeners[event]) {
        this.listeners[event] = [];
      }
      this.listeners[event].push(callback);
      return () => {
        this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
      };
    }

    notify(event, data) {
      if (this.listeners[event]) {
        this.listeners[event].forEach(cb => {
          try {
            cb(data, this.state);
          } catch (err) {
            console.error(`Error in subscriber for event ${event}:`, err);
          }
        });
      }
      // Also notify generic change listeners
      if (event !== "change" && this.listeners["change"]) {
        this.listeners["change"].forEach(cb => {
          try {
            cb(this.state, event);
          } catch (err) {
            console.error(`Error in change listener:`, err);
          }
        });
      }
    }

    // State Accessors
    getState() {
      return this.state;
    }

    getProfile() {
      return this.state.profile;
    }

    // State Mutations
    setTab(tab) {
      this.state.activeTab = tab;
      this.saveState();
      this.notify("tabChange", tab);
    }

    setSelectedDay(index) {
      this.state.selectedDayIndex = index;
      this.saveState();
      this.notify("dayChange", index);
    }

    updateProfile(updates) {
      this.state.profile = { ...this.state.profile, ...updates };
      this.saveState();
      this.notify("profileUpdate", this.state.profile);
    }

    setProfileAvatar(avatarUrl) {
      this.state.profile.avatar = avatarUrl;
      this.saveState();
      this.notify("profileAvatarUpdate", avatarUrl);
      this.notify("profileUpdate", this.state.profile);
    }

    setFitnessGoal(goal) {
      this.state.profile.goal = goal;
      this.saveState();
      this.notify("goalChange", goal);
      this.notify("profileUpdate", this.state.profile);
    }

    setDietPref(pref) {
      this.state.profile.dietPref = pref;
      this.saveState();
      this.notify("dietPrefChange", pref);
      this.notify("profileUpdate", this.state.profile);
    }

    toggleWorkoutCompletion(dayIndex) {
      const current = !!this.state.workoutProgress[dayIndex];
      this.state.workoutProgress[dayIndex] = !current;
      if (!current) {
        this.state.totalWorkoutsCompleted += 1;
        this.state.streakDays += 1;
      } else {
        this.state.totalWorkoutsCompleted = Math.max(0, this.state.totalWorkoutsCompleted - 1);
        this.state.streakDays = Math.max(0, this.state.streakDays - 1);
      }
      this.saveState();
      this.notify("workoutProgressUpdate", { dayIndex, status: !current });
    }

    toggleExerciseCheck(dayIndex, exIndex) {
      const key = `${dayIndex}-${exIndex}`;
      this.state.exerciseChecks[key] = !this.state.exerciseChecks[key];
      this.saveState();
      this.notify("exerciseCheckUpdate", { key, value: this.state.exerciseChecks[key] });
    }

    setSelectedCoach(coachId) {
      const valid = coachId === "maya" ? "maya" : "shannu";
      this.state.selectedCoach = valid;
      this.saveState();
      this.notify("coachChange", valid);
    }

    addChatMessage(coachId, message) {
      const valid = coachId === "maya" ? "maya" : "shannu";
      if (!this.state.coachChats[valid]) {
        this.state.coachChats[valid] = [];
      }
      this.state.coachChats[valid].push(message);
      this.saveState();
      this.notify("chatMessageAdded", { coachId: valid, message });
    }

    saveAnalysisReport(report) {
      this.state.latestAnalysis = report;
      this.state.analysisHistory.unshift(report);
      // Keep last 10
      if (this.state.analysisHistory.length > 10) {
        this.state.analysisHistory.pop();
      }
      this.saveState();
      this.notify("analysisComplete", report);
    }

    resetToDemoDefaults() {
      this.state = JSON.parse(JSON.stringify(DEFAULT_STATE));
      this.saveState();
      this.notify("stateReset", this.state);
      this.notify("profileUpdate", this.state.profile);
    }
  }

  window.FitPic.State = new StateStore();
})();
