/**
 * FIT PIC — MAIN APPLICATION CONTROLLER & ROUTER
 * Coordinates navigation, bottom tab bar, responsive layouts,
 * header user avatar updates, and resilient view lifecycle.
 */
window.FitPic = window.FitPic || {};

(function() {
  class AppController {
    constructor() {
      this.views = {};
      this.currentTab = "home";
    }

    init() {
      // Connect view containers
      this.views = {
        home: { el: document.getElementById("view-home"), instance: window.FitPic.Views.HomeView },
        diet: { el: document.getElementById("view-diet"), instance: window.FitPic.Views.DietView },
        workout: { el: document.getElementById("view-workout"), instance: window.FitPic.Views.WorkoutView },
        analysis: { el: document.getElementById("view-analysis"), instance: window.FitPic.Views.AnalysisView },
        coach: { el: document.getElementById("view-coach"), instance: window.FitPic.Views.CoachView },
        profile: { el: document.getElementById("view-profile"), instance: window.FitPic.Views.ProfileView }
      };

      // Initialize each view controller safely
      Object.keys(this.views).forEach(key => {
        try {
          if (this.views[key].el && this.views[key].instance && typeof this.views[key].instance.init === "function") {
            this.views[key].instance.init(this.views[key].el);
          }
        } catch (err) {
          console.error(`Error initializing view ${key}:`, err);
        }
      });

      // Subscribe to tab state changes
      window.FitPic.State.subscribe("tabChange", (tab) => {
        this.showView(tab);
      });

      // Subscribe to profile & avatar changes to keep header user avatar up-to-date
      this.updateHeaderAvatar();
      window.FitPic.State.subscribe("profileUpdate", () => this.updateHeaderAvatar());
      window.FitPic.State.subscribe("profileAvatarUpdate", () => this.updateHeaderAvatar());

      // Setup bottom nav click listeners
      this.setupBottomNav();

      // Read initial route from URL hash or default to home
      const hash = window.location.hash.replace("#", "");
      const initialTab = (hash && this.views[hash]) ? hash : (window.FitPic.State.getState().activeTab || "home");
      this.navigate(initialTab, false);

      // Handle browser back/forward buttons
      window.addEventListener("hashchange", () => {
        const h = window.location.hash.replace("#", "");
        if (h && this.views[h] && h !== this.currentTab) {
          this.navigate(h, false);
        }
      });

      // Quick keyboard navigation (1: Diet, 2: Workout, 3: AI Analysis, 4: Coach, 5: Profile, H: Home)
      window.addEventListener("keydown", (e) => {
        if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || e.target.tagName === "SELECT") {
          return;
        }
        if (e.key === "1") this.navigate("diet");
        if (e.key === "2") this.navigate("workout");
        if (e.key === "3") this.navigate("analysis");
        if (e.key === "4") this.navigate("coach");
        if (e.key === "5") this.navigate("profile");
        if (e.key === "h" || e.key === "H") this.navigate("home");
      });

      console.log("Fit Pic Application successfully initialized.");
    }

    updateHeaderAvatar() {
      const slot = document.getElementById("header-user-avatar-slot");
      if (!slot) return;
      const state = window.FitPic.State.getState();
      const avatar = state && state.profile && state.profile.avatar;
      const icons = window.FitPic.Icons;
      slot.innerHTML = icons.userAvatar(36, avatar, true);
    }

    setupBottomNav() {
      const navButtons = document.querySelectorAll(".bottom-nav .nav-item");
      navButtons.forEach(btn => {
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          const tabId = btn.getAttribute("data-tab");
          if (tabId) {
            this.navigate(tabId);
          }
        });
      });

      // Global delegation fallback for any element with data-tab
      document.addEventListener("click", (e) => {
        const targetTabEl = e.target.closest("[data-tab]");
        if (targetTabEl && !targetTabEl.classList.contains("nav-item")) {
          const tabId = targetTabEl.getAttribute("data-tab");
          if (tabId && this.views[tabId]) {
            e.preventDefault();
            this.navigate(tabId);
          }
        }
      });
    }

    navigate(tabId, updateHash = true) {
      if (!this.views[tabId]) {
        tabId = "home";
      }
      this.currentTab = tabId;
      window.FitPic.State.setTab(tabId);
      if (updateHash) {
        window.location.hash = tabId;
      }
      this.showView(tabId);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    showView(tabId) {
      // Toggle view containers
      Object.keys(this.views).forEach(key => {
        const item = this.views[key];
        if (item.el) {
          if (key === tabId) {
            item.el.classList.add("active");
            if (item.instance && typeof item.instance.render === "function") {
              try {
                item.instance.render();
              } catch (renderErr) {
                console.error(`Error rendering view ${key}:`, renderErr);
              }
            }
          } else {
            item.el.classList.remove("active");
          }
        }
      });

      // Update bottom nav active classes
      const navButtons = document.querySelectorAll(".bottom-nav .nav-item");
      navButtons.forEach(btn => {
        const btnTab = btn.getAttribute("data-tab");
        if (btnTab === tabId) {
          btn.classList.add("active");
        } else {
          btn.classList.remove("active");
        }
      });
    }
  }

  window.FitPic.App = new AppController();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      window.FitPic.App.init();
    });
  } else {
    window.FitPic.App.init();
  }
})();
