/**
 * FIT PIC — ICON SUITE, BRAND ASSETS & COACH AVATARS
 * Modern crisp SVG icons, character imagery & animated visual tokens.
 * Fully resilient with Proxy fallback to guarantee zero runtime missing-icon errors.
 */
window.FitPic = window.FitPic || {};

const baseIcons = {
  // Brand Logo with Heartbeat Pulse
  logo: (size = 24) => `
    <img src="assets/logo.jpg" alt="Fit Pic" style="width: ${size}px; height: ${size}px; border-radius: 50%; object-fit: cover; border: 1.5px solid #5EBE1A; box-shadow: 0 0 10px rgba(94, 190, 26, 0.4); display: block;" onerror="this.onerror=null; this.src=''; this.outerHTML='<span style=\\\'color:#5EBE1A;font-weight:900\\\'>FP</span>';">
  `,

  heartbeat: (width = 48, height = 18, color = "#5EBE1A") => `
    <svg width="${width}" height="${height}" viewBox="0 0 100 30" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M0 15H30L36 3L44 27L52 8L58 20L64 15H100" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  `,

  sparkles: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"></path>
      <path d="M5 3v4"></path>
      <path d="M19 17v4"></path>
      <path d="M3 5h4"></path>
      <path d="M17 19h4"></path>
    </svg>
  `,

  // Core Dumbbell Icon
  dumbbell: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m6.5 6.5 11 11"></path>
      <path d="m21 21-1-1a2 2 0 0 0-2.83 0l-1.17 1.17a2 2 0 0 1-2.83 0L3.17 11.17a2 2 0 0 1 0-2.83L4.34 7.17a2 2 0 0 0 0-2.83L3.34 3.34a2 2 0 0 1 2.83 0l1 1a2 2 0 0 0 2.83 0l1.17-1.17a2 2 0 0 1 2.83 0l10 10a2 2 0 0 1 0 2.83l-1.17 1.17a2 2 0 0 0 0 2.83Z"></path>
      <path d="m18 15 3 3"></path>
      <path d="m15 18 3 3"></path>
      <path d="m6 9-3-3"></path>
      <path d="m9 6-3-3"></path>
    </svg>
  `,

  // Animated Pumping Dumbbell Badge
  dumbbellPumping: (size = 24, color = "#5EBE1A") => `
    <span class="animated-dumbbell-wrapper" style="display:inline-flex; align-items:center; justify-content:center;">
      <svg class="dumbbell-pump-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
        <path d="m6.5 6.5 11 11"></path>
        <path d="m21 21-1-1a2 2 0 0 0-2.83 0l-1.17 1.17a2 2 0 0 1-2.83 0L3.17 11.17a2 2 0 0 1 0-2.83L4.34 7.17a2 2 0 0 0 0-2.83L3.34 3.34a2 2 0 0 1 2.83 0l1 1a2 2 0 0 0 2.83 0l1.17-1.17a2 2 0 0 1 2.83 0l10 10a2 2 0 0 1 0 2.83l-1.17 1.17a2 2 0 0 0 0 2.83Z"></path>
        <path d="m18 15 3 3"></path>
        <path d="m15 18 3 3"></path>
        <path d="m6 9-3-3"></path>
        <path d="m9 6-3-3"></path>
      </svg>
    </span>
  `,

  utensils: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M18 2v6a3 3 0 0 1-3 3 3 3 0 0 1-3-3V2"></path>
      <path d="M15 2v19"></path>
      <path d="M5 2v5a3 3 0 0 0 3 3h2v11"></path>
    </svg>
  `,

  leaf: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path>
      <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path>
    </svg>
  `,

  drumstick: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M15.4 15.6a7.875 7.875 0 1 0-8.8-8.8l-4.1 4.1a2 2 0 0 0 0 2.8l1.4 1.4a2 2 0 0 0 2.8 0l4.1-4.1a7.875 7.875 0 0 0 4.6 4.6Z"></path>
    </svg>
  `,

  info: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="12" y1="16" x2="12" y2="12"></line>
      <line x1="12" y1="8" x2="12.01" y2="8"></line>
    </svg>
  `,

  alertCircle: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="12" y1="8" x2="12" y2="12"></line>
      <line x1="12" y1="16" x2="12.01" y2="16"></line>
    </svg>
  `,

  award: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="8" r="7"></circle>
      <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
    </svg>
  `,

  refresh: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path>
    </svg>
  `,

  bot: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 8V4H8"></path>
      <rect width="16" height="12" x="4" y="8" rx="2"></rect>
      <path d="M2 14h2"></path>
      <path d="M20 14h2"></path>
      <path d="M15 13v2"></path>
      <path d="M9 13v2"></path>
    </svg>
  `,

  user: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
      <circle cx="12" cy="7" r="4"></circle>
    </svg>
  `,

  // User Profile Picture Component Helper (handles custom upload or fallback)
  userAvatar: (size = 40, avatarUrl = null, border = true) => {
    if (avatarUrl) {
      return `
        <div class="user-avatar-img-wrap" style="width: ${size}px; height: ${size}px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; ${border ? 'border: 2px solid #5EBE1A; box-shadow: 0 0 8px rgba(94, 190, 26, 0.35);' : ''} background: #11161B; flex-shrink: 0;">
          <img src="${avatarUrl}" alt="User Avatar" style="width: 100%; height: 100%; object-fit: cover; display: block;" onerror="this.onerror=null; this.src='';">
        </div>
      `;
    }
    return `
      <div class="user-avatar-img-wrap" style="width: ${size}px; height: ${size}px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; ${border ? 'border: 2px solid #5EBE1A; box-shadow: 0 0 8px rgba(94, 190, 26, 0.35);' : ''} background: #11161B; color: #5EBE1A; flex-shrink: 0;">
        <svg width="${size * 0.55}" height="${size * 0.55}" viewBox="0 0 24 24" fill="none" stroke="#5EBE1A" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
          <circle cx="12" cy="7" r="4"></circle>
        </svg>
      </div>
    `;
  },

  home: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
      <polyline points="9 22 9 12 15 12 15 22"></polyline>
    </svg>
  `,

  camera: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
      <circle cx="12" cy="13" r="3"></circle>
    </svg>
  `,

  upload: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="17 8 12 3 7 8"></polyline>
      <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
  `,

  link: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
    </svg>
  `,

  play: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="${color}" stroke="${color}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="5 3 19 12 5 21 5 3"></polygon>
    </svg>
  `,

  video: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="23 7 16 12 23 17 23 7"></polygon>
      <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
  `,

  messageCircle: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"></path>
    </svg>
  `,

  send: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m22 2-7 20-4-9-9-4Z"></path>
      <path d="M22 2 11 13"></path>
    </svg>
  `,

  check: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  `,

  checkCircle: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
      <polyline points="22 4 12 14.01 9 11.01"></polyline>
    </svg>
  `,

  x: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  `,

  close: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  `,

  chevronRight: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="9 18 15 12 9 6"></polyline>
    </svg>
  `,

  chevronLeft: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="15 18 9 12 15 6"></polyline>
    </svg>
  `,

  flame: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path>
    </svg>
  `,

  target: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <circle cx="12" cy="12" r="6"></circle>
      <circle cx="12" cy="12" r="2"></circle>
    </svg>
  `,

  activity: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
    </svg>
  `,

  shield: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
    </svg>
  `,

  clock: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <polyline points="12 6 12 12 16 14"></polyline>
    </svg>
  `,

  edit: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
    </svg>
  `,

  scale: (size = 20, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"></path>
      <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"></path>
      <path d="M7 21h10"></path>
      <path d="M12 3v18"></path>
      <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"></path>
    </svg>
  `,

  // Gender Icons
  genderMale: (size = 18, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="10" cy="14" r="5"></circle>
      <line x1="19" y1="5" x2="13.6" y2="10.4"></line>
      <polyline points="15 5 19 5 19 9"></polyline>
    </svg>
  `,

  genderFemale: (size = 18, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="9" r="5"></circle>
      <line x1="12" y1="14" x2="12" y2="21"></line>
      <line x1="9" y1="18" x2="15" y2="18"></line>
    </svg>
  `,

  genderTransgender: (size = 18, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="4"></circle>
      <line x1="12" y1="16" x2="12" y2="22"></line>
      <line x1="9" y1="19" x2="15" y2="19"></line>
      <line x1="19" y1="5" x2="14.8" y2="9.2"></line>
      <polyline points="15 5 19 5 19 9"></polyline>
      <line x1="5" y1="5" x2="9.2" y2="9.2"></line>
      <line x1="5" y1="5" x2="8" y2="5"></line>
      <line x1="5" y1="5" x2="5" y2="8"></line>
      <line x1="6.5" y1="7.5" x2="8.5" y2="5.5"></line>
    </svg>
  `,

  // Speech / Sound Wave for Animated Speaking Coach
  soundWaves: (size = 20, color = "#5EBE1A") => `
    <div class="coach-soundwaves" style="display:inline-flex; align-items:center; gap:2.5px; height:${size}px;">
      <span class="soundwave-bar bar-1" style="width:2.5px; background:${color}; border-radius:3px;"></span>
      <span class="soundwave-bar bar-2" style="width:2.5px; background:${color}; border-radius:3px;"></span>
      <span class="soundwave-bar bar-3" style="width:2.5px; background:${color}; border-radius:3px;"></span>
      <span class="soundwave-bar bar-4" style="width:2.5px; background:${color}; border-radius:3px;"></span>
    </div>
  `,

  // =========================================================================
  // COACH AVATARS & FULL PORTRAITS
  // =========================================================================
  avatarShannu: (size = 54) => `
    <div class="coach-avatar-wrapper shannu-avatar-wrap" style="width: ${size}px; height: ${size}px; border-radius: 50%; overflow: hidden; background: #11161B; border: 2px solid #5EBE1A; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 0 10px rgba(94, 190, 26, 0.4); flex-shrink: 0;">
      <img src="assets/shannu.png" alt="Coach Shannu" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; transform: scale(1.4) translateY(10%); display: block;" onerror="this.src=''; this.outerHTML='<span style=\\\'color:#5EBE1A;font-weight:800;font-size:${size*0.4}px\\\'>S</span>';">
    </div>
  `,

  avatarShennu: (size = 54) => baseIcons.avatarShannu(size),

  avatarMaya: (size = 54) => `
    <div class="coach-avatar-wrapper maya-avatar-wrap" style="width: ${size}px; height: ${size}px; border-radius: 50%; overflow: hidden; background: #11161B; border: 2px solid #5EBE1A; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 0 10px rgba(94, 190, 26, 0.4); flex-shrink: 0;">
      <img src="assets/maya.png" alt="Coach Maya" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; transform: scale(1.4) translateY(10%); display: block;" onerror="this.src=''; this.outerHTML='<span style=\\\'color:#5EBE1A;font-weight:800;font-size:${size*0.4}px\\\'>M</span>';">
    </div>
  `,

  coachPortrait: (coachId = "shannu", height = 240, extraClass = "") => {
    const isMaya = coachId === "maya";
    const src = isMaya ? "assets/maya.png" : "assets/shannu.png";
    const alt = isMaya ? "Coach Maya" : "Coach Shannu";
    return `
      <div class="coach-standee ${isMaya ? 'standee-maya' : 'standee-shannu'} ${extraClass}" style="height: ${height}px; position: relative; display: flex; align-items: flex-end; justify-content: center;">
        <img src="${src}" alt="${alt}" class="coach-standee-img" style="height: 100%; width: auto; max-width: 100%; object-fit: contain; filter: drop-shadow(0 10px 20px rgba(0, 0, 0, 0.25)); display: block;">
      </div>
    `;
  },

  // Cool preset user avatars
  presetAvatars: [
    { id: "preset1", name: "Gym Beast", icon: "🦁", color: "#5EBE1A", desc: "Pure Power & Drive" },
    { id: "preset2", name: "Neon Runner", icon: "⚡", color: "#6BD322", desc: "Speed & Stamina" },
    { id: "preset3", name: "Iron Titan", icon: "🏋️", color: "#4EA313", desc: "Heavy Lifter" },
    { id: "preset4", name: "Zen Warrior", icon: "🧘", color: "#3B8A0E", desc: "Mindful Muscle" },
    { id: "preset5", name: "Flame Athlete", icon: "🔥", color: "#77DE2E", desc: "Metabolic Fire" },
    { id: "preset6", name: "Cyber Boxer", icon: "🥊", color: "#5EBE1A", desc: "Combat Ready" }
  ]
};

// Safe Proxy wrapper: if any code ever calls an unlisted icon name, return a safe fallback SVG instead of throwing an error
window.FitPic.Icons = new Proxy(baseIcons, {
  get(target, prop) {
    if (prop in target) {
      return target[prop];
    }
    // Return a safe fallback icon generator
    return (size = 20, color = "currentColor") => `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
      </svg>
    `;
  }
});
