@echo off
title Fit Pic AI Fitness Companion
cd /d "%~dp0"
echo =======================================================
echo    FIT PIC - AI STUDENT FITNESS ^& NUTRITION COMPANION
echo =======================================================
echo.
echo Opening Fit Pic in your default web browser...
start http://localhost:8080/
echo.
echo If using local files directly:
echo file:///%~dp0index.html
echo.
echo Server active on:
echo   - http://localhost:8080/
echo   - http://127.0.0.1:8080/
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause

