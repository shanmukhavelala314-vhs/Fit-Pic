import React, { useState, useEffect, useCallback, useRef } from "react";
import {
    Home, Utensils, Dumbbell, Sparkles, MessageCircle, User,
    Flame, Activity, TrendingUp, Award, ChevronRight, ChevronLeft,
    Check, X, Upload, Send, Loader2, Droplet, Edit2, LogOut,
    Mail, Lock, AlertCircle, CheckCircle2, Leaf, Drumstick,
    Image as ImageIcon, RotateCcw, Clock, Zap
} from "lucide-react";

/* ----------------------------- persistence ------------------------------ */

function useStorage(key, initialValue) {
    const [value, setValue] = useState(initialValue);
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        let cancelled = false;
        (async () => {
            try {
                const res = await window.storage.get(key, false);
                if (!cancelled && res && res.value) setValue(JSON.parse(res.value));
            } catch (e) {
                /* no stored value yet - keep initial */
            }
            if (!cancelled) setLoaded(true);
        })();
        return () => { cancelled = true; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [key]);

    const update = useCallback((updater) => {
        setValue((prev) => {
            const next = typeof updater === "function" ? updater(prev) : updater;
            window.storage.set(key, JSON.stringify(next), false).catch(() => { });
            return next;
        });
    }, [key]);

    return [value, update, loaded];
}

/* --------------------------------- data ---------------------------------- */

const GOALS = [
    { id: "maintain", label: "Weight Management", sub: "Healthy weight", color: "green", icon: Leaf },
    { id: "gain", label: "Weight Gain", sub: "Build size & strength", color: "orange", icon: Flame },
    { id: "recomp", label: "Body Recomposition", sub: "Lose fat, build muscle", color: "blue", icon: Activity },
];

const ACTIVITY_LEVELS = [
    { id: "sedentary", label: "Sedentary", sub: "Little to no exercise", mult: 1.2 },
    { id: "light", label: "Lightly active", sub: "1-3 workouts/week", mult: 1.375 },
    { id: "moderate", label: "Moderately active", sub: "3-5 workouts/week", mult: 1.55 },
    { id: "active", label: "Very active", sub: "6-7 workouts/week", mult: 1.725 },
];

const DEFAULT_PROFILE = {
    name: "", age: 20, height: 170, weight: 65, gender: "male",
    activityLevel: "moderate", dietPref: "veg", goal: "maintain",
    fitnessLevel: "beginner", loggedIn: false, email: "",
};

const FOOD_DB = {
    veg: {
        breakfast: [
            { name: "Vegetable poha with peanuts", kcal: 280, protein: 7 },
            { name: "Moong dal chilla with mint chutney", kcal: 260, protein: 14 },
            { name: "Idli (3 pcs) with sambar", kcal: 300, protein: 9 },
            { name: "Vegetable upma with curd", kcal: 290, protein: 8 },
            { name: "Besan cheela with paneer stuffing", kcal: 310, protein: 15 },
            { name: "Oats porridge with banana and nuts", kcal: 320, protein: 10 },
            { name: "Stuffed paratha (aloo) with curd", kcal: 340, protein: 9 },
        ],
        midMorning: [
            { name: "A bowl of seasonal fruit", kcal: 90, protein: 1 },
            { name: "Roasted chana (1 handful)", kcal: 120, protein: 7 },
            { name: "Buttermilk (chaas)", kcal: 60, protein: 3 },
            { name: "Mixed nuts (almonds & walnuts)", kcal: 150, protein: 5 },
            { name: "Sprouts chaat", kcal: 130, protein: 8 },
        ],
        lunch: [
            { name: "Rice, dal, mixed veg sabzi, curd", kcal: 520, protein: 18 },
            { name: "2 roti, paneer bhurji, salad", kcal: 540, protein: 22 },
            { name: "Rajma rice with cucumber raita", kcal: 550, protein: 19 },
            { name: "Chole with 2 roti and salad", kcal: 530, protein: 17 },
            { name: "Curd rice with vegetable poriyal", kcal: 480, protein: 14 },
            { name: "2 roti, palak paneer, dal", kcal: 560, protein: 23 },
            { name: "Vegetable pulao with kadhi", kcal: 510, protein: 15 },
        ],
        eveningSnack: [
            { name: "Sprouts bhel", kcal: 150, protein: 8 },
            { name: "Green tea with roasted makhana", kcal: 130, protein: 4 },
            { name: "Paneer cubes, lightly grilled", kcal: 180, protein: 14 },
            { name: "Fruit chaat", kcal: 110, protein: 2 },
            { name: "Boiled corn chaat", kcal: 140, protein: 5 },
        ],
        dinner: [
            { name: "2 roti, dal tadka, sauteed vegetables", kcal: 460, protein: 17 },
            { name: "Vegetable khichdi with curd", kcal: 440, protein: 14 },
            { name: "Paneer tikka with 1 roti and salad", kcal: 470, protein: 24 },
            { name: "Mixed vegetable curry with brown rice", kcal: 450, protein: 12 },
            { name: "Soya chunk curry with 2 roti", kcal: 480, protein: 26 },
            { name: "Dal + jeera rice + salad", kcal: 440, protein: 15 },
            { name: "Vegetable soup with grilled paneer sandwich", kcal: 420, protein: 18 },
        ],
    },
    nonveg: {
        breakfast: [
            { name: "2 boiled eggs with whole-wheat toast", kcal: 300, protein: 18 },
            { name: "Egg bhurji with 1 roti", kcal: 320, protein: 19 },
            { name: "Vegetable omelette (2 eggs)", kcal: 280, protein: 17 },
            { name: "Chicken sausage with sauteed vegetables", kcal: 310, protein: 20 },
            { name: "Boiled eggs with vegetable poha", kcal: 340, protein: 16 },
            { name: "Oats porridge with a boiled egg on the side", kcal: 330, protein: 15 },
        ],
        midMorning: [
            { name: "A bowl of seasonal fruit", kcal: 90, protein: 1 },
            { name: "Boiled egg (1)", kcal: 78, protein: 6 },
            { name: "Buttermilk (chaas)", kcal: 60, protein: 3 },
            { name: "Mixed nuts (almonds & walnuts)", kcal: 150, protein: 5 },
            { name: "Roasted chana (1 handful)", kcal: 120, protein: 7 },
        ],
        lunch: [
            { name: "Rice, chicken curry, salad", kcal: 560, protein: 32 },
            { name: "2 roti, egg curry, dal", kcal: 550, protein: 26 },
            { name: "Fish curry with rice and vegetable sabzi", kcal: 540, protein: 30 },
            { name: "Chicken biryani with raita (moderate portion)", kcal: 580, protein: 28 },
            { name: "2 roti, chicken tikka, salad", kcal: 530, protein: 34 },
            { name: "Rice, egg curry, sauteed greens", kcal: 520, protein: 24 },
        ],
        eveningSnack: [
            { name: "Boiled egg whites (2-3)", kcal: 60, protein: 11 },
            { name: "Grilled chicken strips", kcal: 160, protein: 20 },
            { name: "Green tea with roasted makhana", kcal: 130, protein: 4 },
            { name: "Fruit chaat", kcal: 110, protein: 2 },
        ],
        dinner: [
            { name: "Grilled chicken breast with sauteed vegetables", kcal: 420, protein: 36 },
            { name: "2 roti, chicken curry, salad", kcal: 480, protein: 30 },
            { name: "Fish tikka with 1 roti and salad", kcal: 440, protein: 32 },
            { name: "Egg curry with jeera rice", kcal: 460, protein: 22 },
            { name: "Chicken soup with grilled sandwich", kcal: 420, protein: 24 },
            { name: "2 roti, egg bhurji, dal", kcal: 450, protein: 23 },
        ],
    },
};

const MEAL_SLOTS = [
    { key: "breakfast", label: "Breakfast", share: 0.25, color: "orange" },
    { key: "midMorning", label: "Mid-morning", share: 0.10, color: "green" },
    { key: "lunch", label: "Lunch", share: 0.30, color: "blue" },
    { key: "eveningSnack", label: "Evening snack", share: 0.10, color: "green" },
    { key: "dinner", label: "Dinner", share: 0.25, color: "orange" },
];

const WORKOUT_TEMPLATES = {
    maintain: [
        { focus: "Full body strength", exList: ["Bodyweight squats", "Push-ups", "Bent-over rows (bands/dumbbells)", "Plank hold"] },
        { focus: "Cardio & core", exList: ["Brisk walk / jog", "Mountain climbers", "Bicycle crunches", "Russian twists"] },
        { focus: "Active recovery", exList: ["Light stretching flow", "Cat-cow stretch", "Child's pose hold", "Deep breathing walk"], rest: true },
        { focus: "Upper body strength", exList: ["Incline push-ups", "Dumbbell shoulder press", "Seated rows", "Bicep curls"] },
        { focus: "Interval cardio", exList: ["Jumping jacks", "High knees", "Brisk walk intervals", "Cool-down stretch"] },
        { focus: "Lower body & core", exList: ["Lunges", "Glute bridges", "Wall sit", "Dead bug"] },
        { focus: "Rest day", exList: ["Gentle walk", "Full body stretch"], rest: true },
    ],
    gain: [
        { focus: "Push (chest, shoulders, triceps)", exList: ["Push-ups / bench press", "Dumbbell shoulder press", "Tricep dips", "Lateral raises"] },
        { focus: "Pull (back, biceps)", exList: ["Rows (band/dumbbell)", "Lat pulldown or pull-ups", "Bicep curls", "Face pulls"] },
        { focus: "Legs", exList: ["Squats", "Romanian deadlifts", "Walking lunges", "Calf raises"] },
        { focus: "Active recovery", exList: ["Light walk", "Mobility stretches"], rest: true },
        { focus: "Push (volume)", exList: ["Incline push-ups", "Dumbbell chest press", "Overhead press", "Skull crushers"] },
        { focus: "Pull & legs accessory", exList: ["Deadlifts (light-moderate)", "Seated rows", "Hamstring curls", "Shrugs"] },
        { focus: "Rest day", exList: ["Full rest or gentle walk"], rest: true },
    ],
    recomp: [
        { focus: "Full body strength", exList: ["Goblet squats", "Push-ups", "Dumbbell rows", "Plank"] },
        { focus: "HIIT cardio", exList: ["30s on / 30s off sprints", "Burpees", "Jump squats", "Cool-down walk"] },
        { focus: "Upper body strength", exList: ["Dumbbell bench press", "Rows", "Shoulder press", "Bicep/tricep superset"] },
        { focus: "Active recovery", exList: ["Mobility flow", "Light yoga"], rest: true },
        { focus: "Lower body strength", exList: ["Squats", "Lunges", "Deadlifts", "Calf raises"] },
        { focus: "Steady cardio & core", exList: ["30 min brisk walk / cycle", "Plank variations", "Bicycle crunches"] },
        { focus: "Rest day", exList: ["Stretching", "Gentle walk"], rest: true },
    ],
};

const LEVEL_SETTINGS = {
    beginner: { sets: "2-3 sets", reps: "10-12 reps", rest: "60-75s rest", duration: 30 },
    intermediate: { sets: "3-4 sets", reps: "10-15 reps", rest: "45-60s rest", duration: 40 },
    advanced: { sets: "4-5 sets", reps: "12-15 reps", rest: "30-45s rest", duration: 50 },
};

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

/* ------------------------------ calculations ----------------------------- */

function calcBMI(heightCm, weightKg) {
    const h = heightCm / 100;
    return weightKg / (h * h);
}

function bmiCategory(bmi) {
    if (bmi < 18.5) return { label: "Underweight", color: "blue", note: "You may benefit from a calorie surplus to reach a healthier weight range." };
    if (bmi < 25) return { label: "Healthy weight", color: "green", note: "Your weight is in the range generally considered healthy for most adults." };
    if (bmi < 30) return { label: "Overweight", color: "orange", note: "A modest calorie deficit and regular activity can help move toward a healthier range." };
    return { label: "Obese", color: "orange", note: "Consider speaking with a healthcare professional to build a safe, personalized plan." };
}

function calcTDEE(profile) {
    const { age, height, weight, gender, activityLevel } = profile;
    const bmr = gender === "female"
        ? 10 * weight + 6.25 * height - 5 * age - 161
        : 10 * weight + 6.25 * height - 5 * age + 5;
    const mult = (ACTIVITY_LEVELS.find(a => a.id === activityLevel) || ACTIVITY_LEVELS[1]).mult;
    return Math.round(bmr * mult);
}

function calcTargetCalories(profile) {
    const tdee = calcTDEE(profile);
    const bmi = calcBMI(profile.height, profile.weight);
    if (profile.goal === "gain") return tdee + 350;
    if (profile.goal === "recomp") return tdee - 150;
    return bmi >= 25 ? tdee - 400 : tdee;
}

function generateMealPlan(profile, dayIndex) {
    const targetCal = calcTargetCalories(profile);
    const db = FOOD_DB[profile.dietPref] || FOOD_DB.veg;
    const meals = {};
    let totalKcal = 0;
    let totalProtein = 0;
    MEAL_SLOTS.forEach((slot, i) => {
        const list = db[slot.key];
        const item = list[(dayIndex + i * 2) % list.length];
        meals[slot.key] = item;
        totalKcal += item.kcal;
        totalProtein += item.protein;
    });
    const proteinTarget = Math.round(profile.weight * (profile.goal === "gain" ? 1.8 : profile.goal === "recomp" ? 2.0 : 1.4));
    return { targetCal: Math.round(targetCal), actualKcal: totalKcal, totalProtein, proteinTarget, meals };
}

function generateWorkoutWeek(profile) {
    const template = WORKOUT_TEMPLATES[profile.goal] || WORKOUT_TEMPLATES.maintain;
    const level = LEVEL_SETTINGS[profile.fitnessLevel] || LEVEL_SETTINGS.beginner;
    return template.map((day, i) => ({
        dayName: DAY_NAMES[(i + 1) % 7],
        focus: day.focus,
        isRest: !!day.rest,
        duration: day.rest ? 15 : level.duration,
        exercises: day.exList.map((name) => ({
            name,
            sets: day.rest ? "-" : level.sets,
            reps: day.rest ? "-" : level.reps,
            rest: day.rest ? "-" : level.rest,
        })),
    }));
}

function greeting() {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
}

/* -------------------------------- Claude API ------------------------------ */

async function callClaude(messages, system, maxTokens = 1000) {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: "claude-sonnet-4-6",
            max_tokens: maxTokens,
            system,
            messages,
        }),
    });
    if (!response.ok) throw new Error("API request failed");
    const data = await response.json();
    const text = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join("\n").trim();
    return text;
}

function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result.split(",")[1]);
        reader.onerror = () => reject(new Error("Could not read file"));
        reader.readAsDataURL(file);
    });
}

/* --------------------------------- styles --------------------------------- */

const GlobalStyles = () => (
    <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap');
    .fp-root {
      --bg: #FCFBF8;
      --surface: #FFFFFF;
      --ink: #171A1F;
      --ink-muted: #6B7280;
      --line: #ECE9E2;
      --orange: #FF5A1F;
      --orange-soft: #FFEDE3;
      --orange-deep: #B33D10;
      --blue: #1D5C9E;
      --blue-soft: #E6F0F9;
      --blue-deep: #12406F;
      --green: #2F9E44;
      --green-soft: #E7F5EA;
      --green-deep: #1F7A32;
      font-family: 'Inter', sans-serif;
      color: var(--ink);
      background: var(--bg);
      min-height: 100vh;
      position: relative;
    }
    .fp-root * { box-sizing: border-box; }
    .fp-head { font-family: 'Baloo 2', sans-serif; }
    .fp-scroll { padding-bottom: 92px; }
    .fp-card {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: 20px;
    }
    .fp-btn {
      font-family: 'Inter', sans-serif;
      font-weight: 600;
      border-radius: 14px;
      border: none;
      cursor: pointer;
      transition: transform .15s ease, opacity .15s ease;
    }
    .fp-btn:active { transform: scale(0.97); }
    .fp-btn:disabled { opacity: 0.55; cursor: not-allowed; }
    .fp-input {
      font-family: 'Inter', sans-serif;
      border: 1.5px solid var(--line);
      border-radius: 12px;
      padding: 10px 12px;
      font-size: 14px;
      width: 100%;
      background: #fff;
      color: var(--ink);
    }
    .fp-input:focus { outline: none; border-color: var(--blue); }
    .fp-navbtn {
      display: flex; flex-direction: column; align-items: center; gap: 3px;
      background: none; border: none; cursor: pointer; padding: 6px 4px;
      color: var(--ink-muted); font-family: 'Inter', sans-serif; font-size: 11px; font-weight: 600;
      flex: 1;
    }
    .fp-navbtn.active { color: var(--orange); }
    @keyframes fp-pulse {
      0% { box-shadow: 0 0 0 0 rgba(255,90,31,0.35); }
      70% { box-shadow: 0 0 0 14px rgba(255,90,31,0); }
      100% { box-shadow: 0 0 0 0 rgba(255,90,31,0); }
    }
    .fp-ai-glow { animation: fp-pulse 2.4s infinite; }
    @media (prefers-reduced-motion: reduce) {
      .fp-ai-glow { animation: none; }
    }
    .fp-scrollbar-none::-webkit-scrollbar { display: none; }
  `}</style>
);

/* --------------------------------- shared bits ----------------------------- */

function Chip({ children, color = "ink" }) {
    const map = {
        orange: { bg: "var(--orange-soft)", fg: "var(--orange-deep)" },
        blue: { bg: "var(--blue-soft)", fg: "var(--blue-deep)" },
        green: { bg: "var(--green-soft)", fg: "var(--green-deep)" },
        ink: { bg: "#F1EFE8", fg: "var(--ink-muted)" },
    };
    const c = map[color] || map.ink;
    return (
        <span style={{ background: c.bg, color: c.fg, fontSize: 12, fontWeight: 600, padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" }}>
            {children}
        </span>
    );
}

function SectionTitle({ children, sub }) {
    return (
        <div style={{ marginBottom: 14 }}>
            <h2 className="fp-head" style={{ fontSize: 21, fontWeight: 700, margin: 0, color: "var(--ink)" }}>{children}</h2>
            {sub && <p style={{ fontSize: 13.5, color: "var(--ink-muted)", margin: "4px 0 0" }}>{sub}</p>}
        </div>
    );
}

function Disclaimer({ children }) {
    return (
        <div style={{ display: "flex", gap: 8, background: "#F1EFE8", borderRadius: 14, padding: "10px 12px", marginTop: 14 }}>
            <AlertCircle size={16} color="var(--ink-muted)" style={{ flexShrink: 0, marginTop: 1 }} />
            <p style={{ fontSize: 12.5, color: "var(--ink-muted)", margin: 0, lineHeight: 1.5 }}>{children}</p>
        </div>
    );
}

function EmptyState({ icon: Icon, title, body }) {
    return (
        <div style={{ textAlign: "center", padding: "48px 20px" }}>
            <div style={{ width: 56, height: 56, borderRadius: 16, background: "var(--orange-soft)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
                <Icon size={26} color="var(--orange-deep)" />
            </div>
            <p className="fp-head" style={{ fontWeight: 700, fontSize: 16, margin: "0 0 4px" }}>{title}</p>
            <p style={{ fontSize: 13.5, color: "var(--ink-muted)", margin: 0 }}>{body}</p>
        </div>
    );
}

/* ----------------------------------- Home --------------------------------- */

function HomeScreen({ profile, dayIndex, workoutProgress, setTab, setCoachOpen }) {
    const meal = generateMealPlan(profile, dayIndex);
    const week = generateWorkoutWeek(profile);
    const today = week[dayIndex];
    const completedCount = Object.values(workoutProgress || {}).filter(Boolean).length;

    return (
        <div style={{ padding: "20px 18px" }}>
            <div className="fp-card" style={{ padding: 20, background: "linear-gradient(135deg, var(--blue-soft), var(--surface) 60%)", marginBottom: 16 }}>
                <p style={{ fontSize: 13, color: "var(--ink-muted)", margin: "0 0 2px" }}>{greeting()}{profile.name ? `, ${profile.name}` : ""}</p>
                <h1 className="fp-head" style={{ fontSize: 24, fontWeight: 700, margin: 0 }}>Let's make today count.</h1>
                <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
                    <div style={{ flex: 1, background: "#fff", borderRadius: 14, padding: "10px 12px" }}>
                        <p style={{ fontSize: 11, color: "var(--ink-muted)", margin: 0, fontWeight: 600 }}>Weekly workouts</p>
                        <p className="fp-head" style={{ fontSize: 20, fontWeight: 700, margin: "2px 0 0" }}>{completedCount}/7</p>
                    </div>
                    <div style={{ flex: 1, background: "#fff", borderRadius: 14, padding: "10px 12px" }}>
                        <p style={{ fontSize: 11, color: "var(--ink-muted)", margin: 0, fontWeight: 600 }}>Daily target</p>
                        <p className="fp-head" style={{ fontSize: 20, fontWeight: 700, margin: "2px 0 0" }}>{meal.targetCal} kcal</p>
                    </div>
                </div>
            </div>

            <button
                onClick={() => setTab("analysis")}
                className="fp-btn fp-ai-glow"
                style={{ width: "100%", background: "var(--ink)", color: "#fff", padding: "16px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, borderRadius: 20 }}
            >
                <span style={{ display: "flex", alignItems: "center", gap: 10, textAlign: "left" }}>
                    <Sparkles size={22} color="#FFC7A8" />
                    <span>
                        <span className="fp-head" style={{ display: "block", fontSize: 16, fontWeight: 700 }}>AI Analysis</span>
                        <span style={{ display: "block", fontSize: 12, color: "#C9CCD3" }}>Get fresh insights on your progress</span>
                    </span>
                </span>
                <ChevronRight size={20} />
            </button>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
                <div className="fp-card" style={{ padding: 14 }} onClick={() => setTab("workout")}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                        <Dumbbell size={16} color="var(--blue)" />
                        <span style={{ fontSize: 12, fontWeight: 700, color: "var(--blue-deep)" }}>Today's workout</span>
                    </div>
                    <p className="fp-head" style={{ fontSize: 15, fontWeight: 700, margin: "0 0 2px" }}>{today.focus}</p>
                    <p style={{ fontSize: 12, color: "var(--ink-muted)", margin: 0 }}>{today.isRest ? "Recovery day" : `${today.duration} min • ${today.exercises.length} exercises`}</p>
                </div>
                <div className="fp-card" style={{ padding: 14 }} onClick={() => setTab("diet")}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                        <Utensils size={16} color="var(--orange)" />
                        <span style={{ fontSize: 12, fontWeight: 700, color: "var(--orange-deep)" }}>Today's meals</span>
                    </div>
                    <p className="fp-head" style={{ fontSize: 15, fontWeight: 700, margin: "0 0 2px" }}>{meal.meals.lunch.name}</p>
                    <p style={{ fontSize: 12, color: "var(--ink-muted)", margin: 0 }}>Lunch • {meal.meals.lunch.kcal} kcal</p>
                </div>
            </div>

            <button
                onClick={() => { setTab("coach"); }}
                className="fp-btn"
                style={{ width: "100%", background: "var(--green-soft)", color: "var(--green-deep)", padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}
            >
                <span style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <MessageCircle size={20} />
                    <span className="fp-head" style={{ fontWeight: 700, fontSize: 14.5 }}>Chat with your AI coach</span>
                </span>
                <ChevronRight size={18} />
            </button>
        </div>
    );
}

/* ----------------------------------- Diet --------------------------------- */

function DietScreen({ profile, updateProfile, dayIndex, setDayIndex }) {
    const [showSetup, setShowSetup] = useState(!profile.height || !profile.weight);
    const bmi = calcBMI(profile.height, profile.weight);
    const cat = bmiCategory(bmi);
    const plan = generateMealPlan(profile, dayIndex);

    return (
        <div style={{ padding: "20px 18px" }}>
            <SectionTitle sub="Your personalized daily nutrition, built around Indian staples.">Diet</SectionTitle>

            {showSetup ? (
                <BasicInfoForm profile={profile} updateProfile={updateProfile} onDone={() => setShowSetup(false)} />
            ) : (
                <>
                    <div className="fp-card" style={{ padding: 16, marginBottom: 14 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <div>
                                <p style={{ fontSize: 12, color: "var(--ink-muted)", margin: 0, fontWeight: 600 }}>Your BMI</p>
                                <p className="fp-head" style={{ fontSize: 26, fontWeight: 700, margin: "2px 0" }}>{bmi.toFixed(1)}</p>
                                <Chip color={cat.color}>{cat.label}</Chip>
                            </div>
                            <button onClick={() => setShowSetup(true)} className="fp-btn" style={{ background: "#F1EFE8", padding: "8px 10px", display: "flex", alignItems: "center", gap: 5, fontSize: 12.5 }}>
                                <Edit2 size={13} /> Edit
                            </button>
                        </div>
                        <p style={{ fontSize: 12.5, color: "var(--ink-muted)", marginTop: 10, lineHeight: 1.5 }}>{cat.note} BMI is a general screening measure based on height and weight — it doesn't account for muscle mass or body composition directly.</p>
                    </div>

                    <div className="fp-card" style={{ padding: 16, marginBottom: 14 }}>
                        <p style={{ fontSize: 13, fontWeight: 700, margin: "0 0 10px" }}>Fitness goal</p>
                        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                            {GOALS.map((g) => {
                                const Icon = g.icon;
                                const active = profile.goal === g.id;
                                return (
                                    <button key={g.id} onClick={() => updateProfile(p => ({ ...p, goal: g.id }))} className="fp-btn"
                                        style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: active ? `var(--${g.color}-soft)` : "#fff", border: active ? `1.5px solid var(--${g.color})` : "1.5px solid var(--line)", textAlign: "left" }}>
                                        <Icon size={18} color={active ? `var(--${g.color}-deep)` : "var(--ink-muted)"} />
                                        <span>
                                            <span style={{ display: "block", fontSize: 13.5, fontWeight: 700, color: active ? `var(--${g.color}-deep)` : "var(--ink)" }}>{g.label}</span>
                                            <span style={{ display: "block", fontSize: 11.5, color: "var(--ink-muted)" }}>{g.sub}</span>
                                        </span>
                                        {active && <Check size={16} color={`var(--${g.color}-deep)`} style={{ marginLeft: "auto" }} />}
                                    </button>
                                );
                            })}
                        </div>
                        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                            {["veg", "nonveg"].map((d) => (
                                <button key={d} onClick={() => updateProfile(p => ({ ...p, dietPref: d }))} className="fp-btn"
                                    style={{ flex: 1, padding: "9px", background: profile.dietPref === d ? "var(--orange-soft)" : "#F1EFE8", color: profile.dietPref === d ? "var(--orange-deep)" : "var(--ink-muted)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 12.5 }}>
                                    {d === "veg" ? <Leaf size={14} /> : <Drumstick size={14} />} {d === "veg" ? "Vegetarian" : "Non-vegetarian"}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                        <p style={{ fontSize: 13, fontWeight: 700, margin: 0 }}>{DAY_NAMES[dayIndex]}'s meal plan</p>
                        <div style={{ display: "flex", gap: 6 }}>
                            <button onClick={() => setDayIndex((dayIndex + 6) % 7)} className="fp-btn" style={{ background: "#F1EFE8", padding: 6 }}><ChevronLeft size={15} /></button>
                            <button onClick={() => setDayIndex((dayIndex + 1) % 7)} className="fp-btn" style={{ background: "#F1EFE8", padding: 6 }}><ChevronRight size={15} /></button>
                        </div>
                    </div>

                    <div className="fp-card" style={{ padding: 14, marginBottom: 14, display: "flex", gap: 14 }}>
                        <div style={{ flex: 1 }}>
                            <p style={{ fontSize: 11, color: "var(--ink-muted)", margin: 0, fontWeight: 600 }}>Calorie target</p>
                            <p className="fp-head" style={{ fontSize: 17, fontWeight: 700, margin: "2px 0 0" }}>{plan.targetCal} kcal</p>
                        </div>
                        <div style={{ flex: 1, borderLeft: "1px solid var(--line)", paddingLeft: 14 }}>
                            <p style={{ fontSize: 11, color: "var(--ink-muted)", margin: 0, fontWeight: 600 }}>Protein target</p>
                            <p className="fp-head" style={{ fontSize: 17, fontWeight: 700, margin: "2px 0 0" }}>{plan.proteinTarget} g</p>
                        </div>
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                        {MEAL_SLOTS.map((slot) => {
                            const item = plan.meals[slot.key];
                            return (
                                <div key={slot.key} className="fp-card" style={{ padding: "12px 14px", display: "flex", gap: 12, borderLeft: `4px solid var(--${slot.color})`, borderTopLeftRadius: 8, borderBottomLeftRadius: 8 }}>
                                    <div style={{ flex: 1 }}>
                                        <p style={{ fontSize: 11, fontWeight: 700, color: `var(--${slot.color}-deep)`, margin: "0 0 3px" }}>{slot.label}</p>
                                        <p style={{ fontSize: 14, fontWeight: 600, margin: 0 }}>{item.name}</p>
                                    </div>
                                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                                        <p style={{ fontSize: 13, fontWeight: 700, margin: 0 }}>{item.kcal} kcal</p>
                                        <p style={{ fontSize: 11, color: "var(--ink-muted)", margin: 0 }}>{item.protein}g protein</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    <Disclaimer>This meal plan offers general wellness guidance based on common Indian foods and isn't a substitute for advice from a registered dietitian or doctor, especially if you have a medical condition.</Disclaimer>
                </>
            )}
        </div>
    );
}

function BasicInfoForm({ profile, updateProfile, onDone }) {
    const [form, setForm] = useState(profile);
    return (
        <div className="fp-card" style={{ padding: 18 }}>
            <p style={{ fontSize: 13.5, fontWeight: 700, margin: "0 0 12px" }}>Tell us about yourself</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
                <Field label="Age">
                    <input type="number" className="fp-input" value={form.age} onChange={e => setForm(f => ({ ...f, age: +e.target.value }))} />
                </Field>
                <Field label="Gender">
                    <select className="fp-input" value={form.gender} onChange={e => setForm(f => ({ ...f, gender: e.target.value }))}>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </Field>
                <Field label="Height (cm)">
                    <input type="number" className="fp-input" value={form.height} onChange={e => setForm(f => ({ ...f, height: +e.target.value }))} />
                </Field>
                <Field label="Weight (kg)">
                    <input type="number" className="fp-input" value={form.weight} onChange={e => setForm(f => ({ ...f, weight: +e.target.value }))} />
                </Field>
            </div>
            <Field label="Activity level">
                <select className="fp-input" value={form.activityLevel} onChange={e => setForm(f => ({ ...f, activityLevel: e.target.value }))}>
                    {ACTIVITY_LEVELS.map(a => <option key={a.id} value={a.id}>{a.label} — {a.sub}</option>)}
                </select>
            </Field>
            <button className="fp-btn" style={{ width: "100%", background: "var(--orange)", color: "#fff", padding: 12, marginTop: 14 }}
                onClick={() => { updateProfile(p => ({ ...p, ...form })); onDone(); }}>
                Save and continue
            </button>
        </div>
    );
}

function Field({ label, children }) {
    return (
        <label style={{ display: "block" }}>
            <span style={{ fontSize: 11.5, color: "var(--ink-muted)", fontWeight: 600, display: "block", marginBottom: 4 }}>{label}</span>
            {children}
        </label>
    );
}

/* --------------------------------- Workout -------------------------------- */

function WorkoutScreen({ profile, updateProfile, dayIndex, setDayIndex, workoutProgress, updateWorkoutProgress }) {
    const week = generateWorkoutWeek(profile);
    const today = week[dayIndex];
    const completedToday = !!workoutProgress[dayIndex];
    const completedCount = Object.values(workoutProgress).filter(Boolean).length;

    return (
        <div style={{ padding: "20px 18px" }}>
            <SectionTitle sub="Synced with your Diet goal — switch goals in Diet to reshape this plan.">Workout</SectionTitle>

            <div className="fp-card" style={{ padding: 14, marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <p style={{ fontSize: 12.5, fontWeight: 700, margin: 0 }}>This week</p>
                    <span style={{ fontSize: 12, color: "var(--ink-muted)" }}>{completedCount}/7 done</span>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                    {week.map((d, i) => (
                        <button key={i} onClick={() => setDayIndex(i)} className="fp-btn"
                            style={{
                                flex: 1, height: 40, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center",
                                background: workoutProgress[i] ? "var(--green)" : i === dayIndex ? "var(--blue-soft)" : "#F1EFE8",
                                border: i === dayIndex ? "1.5px solid var(--blue)" : "none",
                            }}>
                            {workoutProgress[i] ? <Check size={15} color="#fff" /> : <span style={{ fontSize: 11, fontWeight: 700, color: "var(--ink-muted)" }}>{d.dayName.slice(0, 2)}</span>}
                        </button>
                    ))}
                </div>
            </div>

            <Field label="Fitness level">
                <select className="fp-input" value={profile.fitnessLevel} onChange={e => updateProfile(p => ({ ...p, fitnessLevel: e.target.value }))}>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                </select>
            </Field>

            <div className="fp-card" style={{ padding: 16, marginTop: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                    <div>
                        <p style={{ fontSize: 11.5, color: "var(--blue-deep)", fontWeight: 700, margin: 0 }}>{DAY_NAMES[dayIndex]}</p>
                        <p className="fp-head" style={{ fontSize: 18, fontWeight: 700, margin: "2px 0 0" }}>{today.focus}</p>
                    </div>
                    {!today.isRest && (
                        <span style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--ink-muted)" }}>
                            <Clock size={13} /> {today.duration} min
                        </span>
                    )}
                </div>

                {today.isRest ? (
                    <p style={{ fontSize: 13, color: "var(--ink-muted)", marginTop: 10 }}>A lighter day to help your body recover — gentle movement is great, hard training isn't needed.</p>
                ) : (
                    <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 8 }}>
                        {today.exercises.map((ex, i) => (
                            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 12px", background: "#F8F7F3", borderRadius: 12 }}>
                                <span style={{ fontSize: 13.5, fontWeight: 600 }}>{ex.name}</span>
                                <span style={{ fontSize: 11.5, color: "var(--ink-muted)", textAlign: "right" }}>{ex.sets} × {ex.reps}<br />{ex.rest}</span>
                            </div>
                        ))}
                    </div>
                )}

                <button
                    onClick={() => updateWorkoutProgress(p => ({ ...p, [dayIndex]: !p[dayIndex] }))}
                    className="fp-btn"
                    style={{ width: "100%", marginTop: 14, padding: 12, background: completedToday ? "var(--green-soft)" : "var(--ink)", color: completedToday ? "var(--green-deep)" : "#fff", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                    {completedToday ? <><CheckCircle2 size={16} /> Marked as done</> : <>Mark today's workout done</>}
                </button>
            </div>
        </div>
    );
}

/* ------------------------------- AI Analysis ------------------------------ */

function AIAnalysisScreen({ profile, dayIndex, workoutProgress }) {
    const [note, setNote] = useState("");
    const [image, setImage] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [result, setResult] = useState(null);
    const fileRef = useRef(null);

    const handleFile = async (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        setImagePreview(URL.createObjectURL(file));
        try {
            const b64 = await fileToBase64(file);
            setImage({ data: b64, mediaType: file.type || "image/jpeg" });
        } catch {
            setError("Couldn't read that image — try a different file.");
        }
    };

    const runAnalysis = async () => {
        setLoading(true);
        setError(null);
        setResult(null);
        const meal = generateMealPlan(profile, dayIndex);
        const completedCount = Object.values(workoutProgress).filter(Boolean).length;
        const bmi = calcBMI(profile.height, profile.weight).toFixed(1);

        const contextText = `User profile: age ${profile.age}, gender ${profile.gender}, height ${profile.height}cm, weight ${profile.weight}kg, BMI ${bmi}, activity level ${profile.activityLevel}, stated goal ${profile.goal}, diet preference ${profile.dietPref}, fitness level ${profile.fitnessLevel}. Workouts completed this week: ${completedCount}/7. Today's calorie target: ${meal.targetCal} kcal.
User's note about how they're feeling or progressing: "${note || "No note provided."}"
${image ? "The user also attached a photo for general visual context." : "No photo was attached."}

Respond ONLY with a strict JSON object (no markdown, no code fences, no preamble) with exactly these keys:
{"observations": "2-3 sentences of general, non-diagnostic observations", "suggestedGoal": "one of: Weight Management, Weight Gain, Body Recomposition, or 'Keep current goal' with a short reason", "dietTips": ["short tip 1", "short tip 2", "short tip 3"], "workoutTips": ["short tip 1", "short tip 2", "short tip 3"], "progressInsight": "1-2 encouraging sentences about their trajectory based on the data given"}`;

        const system = "You are a supportive fitness wellness assistant inside a student fitness app called Fit Pic. You NEVER provide medical diagnoses, never claim to determine someone's health status or body composition with certainty from an image, and never comment on a person's body in a way that could encourage unhealthy body image. If an image is provided, treat it only as general context (like clothing fit, posture, or energy) and explicitly avoid any definitive claims about body fat, muscle mass, or health from it. Keep tone warm, encouraging, and grounded in general wellness practice. Respond only with the exact JSON object requested, nothing else.";

        try {
            const content = [{ type: "text", text: contextText }];
            if (image) {
                content.unshift({ type: "image", source: { type: "base64", media_type: image.mediaType, data: image.data } });
            }
            const text = await callClaude([{ role: "user", content }], system, 800);
            const clean = text.replace(/```json|```/g, "").trim();
            const parsed = JSON.parse(clean);
            setResult(parsed);
        } catch (e) {
            setError("The AI analysis couldn't be completed right now. Please try again in a moment.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: "20px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                <div className="fp-ai-glow" style={{ width: 40, height: 40, borderRadius: 12, background: "var(--ink)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Sparkles size={20} color="#FFC7A8" />
                </div>
                <h2 className="fp-head" style={{ fontSize: 21, fontWeight: 700, margin: 0 }}>AI Analysis</h2>
            </div>
            <p style={{ fontSize: 13.5, color: "var(--ink-muted)", margin: "0 0 16px" }}>Share how you're feeling, or a photo for general context — get instant, personalized insight.</p>

            <div className="fp-card" style={{ padding: 16, marginBottom: 14 }}>
                <Field label="How are you feeling / progressing? (optional)">
                    <textarea className="fp-input" rows={3} placeholder="e.g. Feeling stronger this week, sleep has been inconsistent..." value={note} onChange={e => setNote(e.target.value)} style={{ resize: "vertical" }} />
                </Field>

                <div style={{ marginTop: 12 }}>
                    <span style={{ fontSize: 11.5, color: "var(--ink-muted)", fontWeight: 600, display: "block", marginBottom: 6 }}>Add a photo (optional)</span>
                    {imagePreview ? (
                        <div style={{ position: "relative", display: "inline-block" }}>
                            <img src={imagePreview} alt="Upload preview" style={{ width: 96, height: 96, objectFit: "cover", borderRadius: 14, border: "1px solid var(--line)" }} />
                            <button onClick={() => { setImage(null); setImagePreview(null); }} className="fp-btn" style={{ position: "absolute", top: -6, right: -6, background: "var(--ink)", color: "#fff", borderRadius: "50%", width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
                                <X size={12} />
                            </button>
                        </div>
                    ) : (
                        <button onClick={() => fileRef.current && fileRef.current.click()} className="fp-btn" style={{ background: "#F1EFE8", padding: "10px 14px", display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
                            <Upload size={15} /> Upload image
                        </button>
                    )}
                    <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
                </div>

                <button onClick={runAnalysis} disabled={loading} className="fp-btn" style={{ width: "100%", marginTop: 16, padding: 13, background: "var(--orange)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                    {loading ? <><Loader2 size={16} className="fp-spin" style={{ animation: "spin 1s linear infinite" }} /> Analyzing...</> : <><Sparkles size={16} /> Run AI Analysis</>}
                </button>
            </div>

            {error && (
                <div style={{ display: "flex", gap: 8, background: "#FCEBEB", borderRadius: 14, padding: "10px 12px", marginBottom: 14 }}>
                    <AlertCircle size={16} color="#A32D2D" style={{ flexShrink: 0, marginTop: 1 }} />
                    <p style={{ fontSize: 12.5, color: "#A32D2D", margin: 0 }}>{error}</p>
                </div>
            )}

            {result && (
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                    <ResultCard icon={Activity} color="blue" title="Observations">{result.observations}</ResultCard>
                    <ResultCard icon={TrendingUp} color="green" title="Suggested goal">{result.suggestedGoal}</ResultCard>
                    <ResultCard icon={Utensils} color="orange" title="Diet recommendations" list={result.dietTips} />
                    <ResultCard icon={Dumbbell} color="blue" title="Workout recommendations" list={result.workoutTips} />
                    <ResultCard icon={Award} color="green" title="Progress insight">{result.progressInsight}</ResultCard>
                </div>
            )}

            <Disclaimer>AI Analysis provides estimates for general wellness purposes only. It does not diagnose medical conditions or determine your health from a photo with certainty — check with a qualified professional for anything specific to your health.</Disclaimer>
        </div>
    );
}

function ResultCard({ icon: Icon, color, title, children, list }) {
    return (
        <div className="fp-card" style={{ padding: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ width: 28, height: 28, borderRadius: 9, background: `var(--${color}-soft)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Icon size={14} color={`var(--${color}-deep)`} />
                </div>
                <p style={{ fontSize: 13, fontWeight: 700, margin: 0 }}>{title}</p>
            </div>
            {list ? (
                <ul style={{ margin: 0, paddingLeft: 18 }}>
                    {list.map((t, i) => <li key={i} style={{ fontSize: 13, color: "var(--ink-muted)", marginBottom: 4 }}>{t}</li>)}
                </ul>
            ) : (
                <p style={{ fontSize: 13, color: "var(--ink-muted)", margin: 0, lineHeight: 1.5 }}>{children}</p>
            )}
        </div>
    );
}

/* ------------------------------- AI Smart Coach ---------------------------- */

const COACHES = {
    male: {
        name: "Coach Arjun", color: "blue",
        persona: "You are Coach Arjun, a friendly, motivating male AI fitness coach inside the Fit Pic app. You speak with warmth and energy, like a supportive gym buddy who knows his stuff.",
        avatar: (
            <svg viewBox="0 0 64 64" width="44" height="44">
                <circle cx="32" cy="32" r="32" fill="#E6F0F9" />
                <circle cx="32" cy="26" r="11" fill="#12406F" />
                <path d="M14 54c2-11 9-17 18-17s16 6 18 17" fill="#1D5C9E" />
                <rect x="24" y="41" width="16" height="8" rx="4" fill="#FF5A1F" />
            </svg>
        ),
    },
    female: {
        name: "Coach Meera", color: "green",
        persona: "You are Coach Meera, a friendly, motivating female AI fitness coach inside the Fit Pic app. You speak with warmth and encouragement, like a supportive friend who is also a knowledgeable trainer.",
        avatar: (
            <svg viewBox="0 0 64 64" width="44" height="44">
                <circle cx="32" cy="32" r="32" fill="#E7F5EA" />
                <circle cx="32" cy="26" r="11" fill="#1F7A32" />
                <path d="M13 55c2-12 9-18 19-18s17 6 19 18" fill="#2F9E44" />
                <path d="M20 20c2-6 8-10 12-10s10 4 12 10c-4-2-8-3-12-3s-8 1-12 3z" fill="#173404" />
                <rect x="23" y="42" width="18" height="8" rx="4" fill="#FF5A1F" />
            </svg>
        ),
    },
};

function CoachScreen({ profile, dayIndex, workoutProgress }) {
    const [coachId, setCoachId, coachLoaded] = useStorage("selected-coach", null);
    const [chats, setChats] = useStorage("coach-chats", { male: [], female: [] });
    const [input, setInput] = useState("");
    const [sending, setSending] = useState(false);
    const [error, setError] = useState(null);
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, [chats, coachId, sending]);

    if (!coachLoaded) return null;

    if (!coachId) {
        return (
            <div style={{ padding: "20px 18px" }}>
                <SectionTitle sub="Pick a coach to guide you — they'll use your Diet and Workout data to help.">AI Smart Coach</SectionTitle>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                    {Object.entries(COACHES).map(([id, c]) => (
                        <button key={id} onClick={() => setCoachId(id)} className="fp-btn fp-card" style={{ padding: 16, display: "flex", alignItems: "center", gap: 14, textAlign: "left" }}>
                            {c.avatar}
                            <span>
                                <span className="fp-head" style={{ display: "block", fontSize: 16, fontWeight: 700 }}>{c.name}</span>
                                <span style={{ display: "block", fontSize: 12.5, color: "var(--ink-muted)" }}>Tap to start chatting</span>
                            </span>
                            <ChevronRight size={18} style={{ marginLeft: "auto" }} />
                        </button>
                    ))}
                </div>
            </div>
        );
    }

    const coach = COACHES[coachId];
    const history = chats[coachId] || [];

    const send = async () => {
        const text = input.trim();
        if (!text || sending) return;
        setInput("");
        setError(null);
        const newHistory = [...history, { role: "user", text }];
        setChats(c => ({ ...c, [coachId]: newHistory }));
        setSending(true);

        const meal = generateMealPlan(profile, dayIndex);
        const completedCount = Object.values(workoutProgress).filter(Boolean).length;
        const system = `${coach.persona} Use the user's data when relevant: goal is ${profile.goal}, diet preference is ${profile.dietPref}, today's calorie target is ${meal.targetCal} kcal, fitness level is ${profile.fitnessLevel}, and they've completed ${completedCount}/7 workouts this week. Give workout guidance, explain exercises simply, share healthy eating reminders, encourage consistency, and offer daily motivation when relevant. Keep replies concise (2-5 sentences unless asked for detail). Never encourage unhealthy body image, extreme diets, or unsafe training. You are not a doctor and should suggest professional advice for medical concerns.`;

        try {
            const apiMessages = newHistory.map(m => ({ role: m.role, content: m.text }));
            const reply = await callClaude(apiMessages, system, 500);
            setChats(c => ({ ...c, [coachId]: [...newHistory, { role: "assistant", text: reply }] }));
        } catch (e) {
            setError("Couldn't reach your coach right now — please try again.");
        } finally {
            setSending(false);
        }
    };

    return (
        <div style={{ padding: "20px 18px", display: "flex", flexDirection: "column", height: "calc(100vh - 92px)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                {coach.avatar}
                <div>
                    <p className="fp-head" style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>{coach.name}</p>
                    <p style={{ fontSize: 11.5, color: "var(--ink-muted)", margin: 0 }}>Your AI fitness coach</p>
                </div>
                <button onClick={() => setCoachId(null)} className="fp-btn" style={{ marginLeft: "auto", background: "#F1EFE8", padding: "7px 10px", fontSize: 12 }}>Switch</button>
            </div>

            <div ref={scrollRef} className="fp-scrollbar-none" style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingBottom: 10 }}>
                {history.length === 0 && (
                    <EmptyState icon={MessageCircle} title="Say hello!" body={`Ask ${coach.name} about your workout, diet, or for a motivation boost.`} />
                )}
                {history.map((m, i) => (
                    <div key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "82%" }}>
                        <div style={{
                            background: m.role === "user" ? "var(--ink)" : `var(--${coach.color}-soft)`,
                            color: m.role === "user" ? "#fff" : "var(--ink)",
                            padding: "10px 14px", borderRadius: 16,
                            borderBottomRightRadius: m.role === "user" ? 4 : 16,
                            borderBottomLeftRadius: m.role === "user" ? 16 : 4,
                            fontSize: 13.5, lineHeight: 1.5,
                        }}>
                            {m.text}
                        </div>
                    </div>
                ))}
                {sending && (
                    <div style={{ alignSelf: "flex-start" }}>
                        <div style={{ background: `var(--${coach.color}-soft)`, padding: "10px 14px", borderRadius: 16, borderBottomLeftRadius: 4, display: "flex", gap: 4 }}>
                            <Loader2 size={14} style={{ animation: "spin 1s linear infinite" }} />
                        </div>
                    </div>
                )}
            </div>

            {error && <p style={{ fontSize: 12, color: "#A32D2D", margin: "4px 0" }}>{error}</p>}

            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <input className="fp-input" placeholder="Ask your coach anything..." value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => { if (e.key === "Enter") send(); }} />
                <button onClick={send} disabled={sending || !input.trim()} className="fp-btn" style={{ background: "var(--orange)", color: "#fff", width: 42, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Send size={16} />
                </button>
            </div>
        </div>
    );
}

/* --------------------------------- Profile -------------------------------- */

function ProfileScreen({ profile, updateProfile, workoutProgress }) {
    const [editing, setEditing] = useState(false);
    const [form, setForm] = useState(profile);
    const [authMode, setAuthMode] = useState("login");
    const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
    const completedCount = Object.values(workoutProgress).filter(Boolean).length;

    if (!profile.loggedIn) {
        return (
            <div style={{ padding: "20px 18px" }}>
                <SectionTitle>{authMode === "login" ? "Log in" : "Sign up"}</SectionTitle>
                <div className="fp-card" style={{ padding: 18 }}>
                    {authMode === "signup" && (
                        <div style={{ marginBottom: 10 }}>
                            <Field label="Name">
                                <input className="fp-input" value={authForm.name} onChange={e => setAuthForm(f => ({ ...f, name: e.target.value }))} />
                            </Field>
                        </div>
                    )}
                    <div style={{ marginBottom: 10 }}>
                        <Field label="Email">
                            <div style={{ position: "relative" }}>
                                <Mail size={14} style={{ position: "absolute", left: 10, top: 12, color: "var(--ink-muted)" }} />
                                <input className="fp-input" style={{ paddingLeft: 30 }} value={authForm.email} onChange={e => setAuthForm(f => ({ ...f, email: e.target.value }))} placeholder="name@college.edu" />
                            </div>
                        </Field>
                    </div>
                    <div style={{ marginBottom: 6 }}>
                        <Field label="Password">
                            <div style={{ position: "relative" }}>
                                <Lock size={14} style={{ position: "absolute", left: 10, top: 12, color: "var(--ink-muted)" }} />
                                <input type="password" className="fp-input" style={{ paddingLeft: 30 }} value={authForm.password} onChange={e => setAuthForm(f => ({ ...f, password: e.target.value }))} placeholder="••••••••" />
                            </div>
                        </Field>
                    </div>
                    <button className="fp-btn" style={{ width: "100%", background: "var(--ink)", color: "#fff", padding: 12, marginTop: 12 }}
                        onClick={() => updateProfile(p => ({ ...p, loggedIn: true, name: authForm.name || p.name || "there", email: authForm.email }))}>
                        {authMode === "login" ? "Log in" : "Create account"}
                    </button>
                    <button className="fp-btn" style={{ width: "100%", background: "none", color: "var(--ink-muted)", padding: 10, marginTop: 4, fontSize: 12.5 }}
                        onClick={() => setAuthMode(m => m === "login" ? "signup" : "login")}>
                        {authMode === "login" ? "New here? Sign up" : "Already have an account? Log in"}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div style={{ padding: "20px 18px" }}>
            <SectionTitle>Profile</SectionTitle>

            <div className="fp-card" style={{ padding: 18, marginBottom: 14 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                    <div style={{ width: 52, height: 52, borderRadius: "50%", background: "var(--orange-soft)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <User size={24} color="var(--orange-deep)" />
                    </div>
                    <div>
                        <p className="fp-head" style={{ fontSize: 17, fontWeight: 700, margin: 0 }}>{profile.name || "Fit Pic user"}</p>
                        <p style={{ fontSize: 12, color: "var(--ink-muted)", margin: 0 }}>{profile.email}</p>
                    </div>
                </div>

                {editing ? (
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                        <Field label="Name"><input className="fp-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></Field>
                        <Field label="Age"><input type="number" className="fp-input" value={form.age} onChange={e => setForm(f => ({ ...f, age: +e.target.value }))} /></Field>
                        <Field label="Height (cm)"><input type="number" className="fp-input" value={form.height} onChange={e => setForm(f => ({ ...f, height: +e.target.value }))} /></Field>
                        <Field label="Weight (kg)"><input type="number" className="fp-input" value={form.weight} onChange={e => setForm(f => ({ ...f, weight: +e.target.value }))} /></Field>
                        <div style={{ gridColumn: "1 / -1" }}>
                            <Field label="Activity level">
                                <select className="fp-input" value={form.activityLevel} onChange={e => setForm(f => ({ ...f, activityLevel: e.target.value }))}>
                                    {ACTIVITY_LEVELS.map(a => <option key={a.id} value={a.id}>{a.label}</option>)}
                                </select>
                            </Field>
                        </div>
                        <button style={{ gridColumn: "1 / -1" }} className="fp-btn" onClick={() => { updateProfile(p => ({ ...p, ...form })); setEditing(false); }}
                            type="button">
                            <span style={{ display: "block", width: "100%", background: "var(--orange)", color: "#fff", padding: 11, borderRadius: 12, textAlign: "center", fontWeight: 600, fontSize: 13.5 }}>Save changes</span>
                        </button>
                    </div>
                ) : (
                    <>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                            <StatRow label="Age" value={`${profile.age} yrs`} />
                            <StatRow label="Height" value={`${profile.height} cm`} />
                            <StatRow label="Weight" value={`${profile.weight} kg`} />
                            <StatRow label="Activity" value={(ACTIVITY_LEVELS.find(a => a.id === profile.activityLevel) || {}).label} />
                            <StatRow label="Goal" value={(GOALS.find(g => g.id === profile.goal) || {}).label} />
                            <StatRow label="Diet" value={profile.dietPref === "veg" ? "Vegetarian" : "Non-vegetarian"} />
                        </div>
                        <button className="fp-btn" style={{ width: "100%", background: "#F1EFE8", padding: 11, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 13 }} onClick={() => { setForm(profile); setEditing(true); }}>
                            <Edit2 size={14} /> Edit information
                        </button>
                    </>
                )}
            </div>

            <div className="fp-card" style={{ padding: 16, marginBottom: 14 }}>
                <p style={{ fontSize: 13, fontWeight: 700, margin: "0 0 10px" }}>Workout progress</p>
                <div style={{ display: "flex", gap: 14 }}>
                    <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8 }}>
                        <Award size={18} color="var(--blue-deep)" />
                        <div>
                            <p className="fp-head" style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>{completedCount}</p>
                            <p style={{ fontSize: 11, color: "var(--ink-muted)", margin: 0 }}>Completed this week</p>
                        </div>
                    </div>
                </div>
            </div>

            <button className="fp-btn" style={{ width: "100%", background: "#FCEBEB", color: "#A32D2D", padding: 12, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
                onClick={() => updateProfile(p => ({ ...p, loggedIn: false }))}>
                <LogOut size={15} /> Log out
            </button>
        </div>
    );
}

function StatRow({ label, value }) {
    return (
        <div style={{ background: "#F8F7F3", borderRadius: 12, padding: "9px 11px" }}>
            <p style={{ fontSize: 10.5, color: "var(--ink-muted)", margin: 0, fontWeight: 600 }}>{label}</p>
            <p style={{ fontSize: 13, fontWeight: 700, margin: "2px 0 0" }}>{value}</p>
        </div>
    );
}

/* ----------------------------------- App ----------------------------------- */

const NAV = [
    { id: "home", label: "Home", icon: Home },
    { id: "diet", label: "Diet", icon: Utensils },
    { id: "workout", label: "Workout", icon: Dumbbell },
    { id: "analysis", label: "AI Analysis", icon: Sparkles },
    { id: "coach", label: "Coach", icon: MessageCircle },
    { id: "profile", label: "Profile", icon: User },
];

export default function FitPicApp() {
    const [tab, setTab] = useState("home");
    const [profile, updateProfile, profileLoaded] = useStorage("profile", DEFAULT_PROFILE);
    const [workoutProgress, updateWorkoutProgress, wpLoaded] = useStorage("workout-progress-week", {});
    const dayIndex = new Date().getDay();
    const [selectedDay, setSelectedDay] = useState(dayIndex);

    if (!profileLoaded || !wpLoaded) {
        return (
            <div className="fp-root" style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 400 }}>
                <GlobalStyles />
                <Loader2 size={26} style={{ animation: "spin 1s linear infinite" }} color="var(--orange, #FF5A1F)" />
            </div>
        );
    }

    const bottomFive = NAV.filter(n => n.id !== "profile" || true);

    return (
        <div className="fp-root">
            <GlobalStyles />
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>

            <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "16px 18px 4px" }}>
                <div style={{ width: 30, height: 30, borderRadius: 9, background: "var(--orange)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Zap size={16} color="#fff" fill="#fff" />
                </div>
                <span className="fp-head" style={{ fontSize: 17, fontWeight: 700 }}>Fit Pic</span>
                <button onClick={() => setTab("profile")} style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer" }}>
                    <div style={{ width: 30, height: 30, borderRadius: "50%", background: "#F1EFE8", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <User size={15} color="var(--ink-muted)" />
                    </div>
                </button>
            </div>

            <div className="fp-scroll">
                {tab === "home" && <HomeScreen profile={profile} dayIndex={selectedDay} workoutProgress={workoutProgress} setTab={setTab} />}
                {tab === "diet" && <DietScreen profile={profile} updateProfile={updateProfile} dayIndex={selectedDay} setDayIndex={setSelectedDay} />}
                {tab === "workout" && <WorkoutScreen profile={profile} updateProfile={updateProfile} dayIndex={selectedDay} setDayIndex={setSelectedDay} workoutProgress={workoutProgress} updateWorkoutProgress={updateWorkoutProgress} />}
                {tab === "analysis" && <AIAnalysisScreen profile={profile} dayIndex={selectedDay} workoutProgress={workoutProgress} />}
                {tab === "coach" && <CoachScreen profile={profile} dayIndex={selectedDay} workoutProgress={workoutProgress} />}
                {tab === "profile" && <ProfileScreen profile={profile} updateProfile={updateProfile} workoutProgress={workoutProgress} />}
            </div>

            <nav style={{ position: "fixed", bottom: 0, left: 0, right: 0, maxWidth: 480, margin: "0 auto", background: "#fff", borderTop: "1px solid var(--line)", display: "flex", padding: "6px 4px 8px" }}>
                {bottomFive.filter(n => n.id !== "profile").map((n) => {
                    const Icon = n.icon;
                    const active = tab === n.id;
                    return (
                        <button key={n.id} onClick={() => setTab(n.id)} className={`fp-navbtn ${active ? "active" : ""}`}>
                            <Icon size={20} />
                            {n.label}
                        </button>
                    );
                })}
                <button onClick={() => setTab("profile")} className={`fp-navbtn ${tab === "profile" ? "active" : ""}`}>
                    <User size={20} />
                    Profile
                </button>
            </nav>
        </div>
    );
}